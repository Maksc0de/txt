import { useEffect, useMemo, useRef, useState } from 'react';
import { ArrowLeft, Crown, Heart, RefreshCw } from 'lucide-react';
import type { Character } from '../../types/game';
import { drawCharacterAvatar } from '../../utils/characterRenderer';
import { soundManager } from '../../audio/soundManager';
import { bossHealth, raidDamageBonus } from '../../game/raidRules';

// Локальный кооперативный Boss Raid: ТЫ + ДРУГ против одного босса.
// Полноценный аренный бой: у каждого героя отдельный джойстик, палитра
// ВСЕХ его способностей, снаряды, частицы, всплывающий урон и честный HP.

interface LocalFighter {
  id: string;
  char: Character;
  name: string;
  x: number; y: number; vx: number; vy: number;
  hp: number; maxHp: number;
  radius: number;
  inv: number;
  cd: number[];
  angle: number;
  hits: number;
  dmg: number;
}

interface Bolt { x: number; y: number; vx: number; vy: number; r: number; color: string; life: number; owner: number }
interface Fx { x: number; y: number; text: string; color: string; life: number }

interface Props {
  heroes: Character[];
  heroNames: string[];
  boss: Character;
  onWin?: () => void;
  onExit: () => void;
  onRematch?: () => void;
}

const HERO_COLORS = ['#baf66a', '#7fb7ff', '#e7a6ff'];

export function LocalBossRaid({ heroes: heroesIn, heroNames, boss: bossIn, onWin, onExit, onRematch }: Props) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const wrapRef = useRef<HTMLDivElement | null>(null);
  const teamRef = useRef<LocalFighter[]>([]);
  const bossRef = useRef<LocalFighter | null>(null);
  const moves = useRef<{ x: number; y: number }[]>(heroesIn.map(() => ({ x: 0, y: 0 })));
  const boltsRef = useRef<Bolt[]>([]);
  const fxRef = useRef<Fx[]>([]);
  const skills = useRef<Array<boolean[]>>(heroesIn.map(() => []));
  const [hpHud, setHpHud] = useState<{ bossHp: number; bossMax: number; team: number[] }>({ bossHp: 0, bossMax: 1, team: [] });
  const [banner, setBanner] = useState<{ text: string; color: string } | null>(null);
  const finished = useRef(false);
  const winRef = useRef(onWin);
  winRef.current = onWin;
  const [result, setResult] = useState<null | 'win' | 'lose'>(null);
  const bannerTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const heroes = useMemo(() => heroesIn, [heroesIn]);

  const showBanner = (text: string, color: string) => {
    setBanner({ text, color });
    if (bannerTimer.current) clearTimeout(bannerTimer.current);
    bannerTimer.current = setTimeout(() => setBanner(null), 1300);
  };

  // Палитра: все способности каждого героя (основная + extra).
  const palettes = useMemo(() => heroes.map(c => [c.ability, ...(c.extraAbilities || [])]), [heroes]);

  const castAbility = (heroIndex: number, abIndex: number) => {
    const f = teamRef.current[heroIndex];
    const b = bossRef.current;
    if (!f || !b || f.hp <= 0 || b.hp <= 0 || finished.current) return;
    if (f.cd[abIndex] > 0) return;
    const ab = palettes[heroIndex]?.[abIndex];
    if (!ab) return;
    // Ставим КД: -25% у мастеров-скорострелов.
    f.cd[abIndex] = ab.cooldown * 0.8;
    const ax = b.x - f.x, ay = b.y - f.y;
    const ad = Math.hypot(ax, ay) || 1;
    f.angle = Math.atan2(ay, ax);
    const baseDmg = Math.max(1, ab.damage || 1);
    // Рейдовый пробой урона видимый: полоса босса всегда настоящая.
    const dmg = baseDmg * raidDamageBonus(bossIn.id) * (1 + Math.min(0.5, f.char.maxHp / 220));
    soundManager.playHit(true);
    showBanner(ab.nameRu, ab.particleColor || HERO_COLORS[heroIndex]);

    const push = (kind: 'ring' | 'dash' | 'ray' | 'burst' | 'pull', power = 1) => {
      if (kind === 'dash') { f.vx = (ax / ad) * 500 * power; f.vy = (ay / ad) * 500 * power; f.inv = 0.5; }
      if (kind === 'pull') { b.vx -= (ax / ad) * 300 * power; b.vy -= (ay / ad) * 300 * power; }
      if (kind === 'ring' || kind === 'burst') {
        const n = kind === 'burst' ? 8 : 3;
        for (let i = 0; i < n; i++) {
          const a = kind === 'burst' ? (i / n) * Math.PI * 2 + Math.random() : f.angle + (i - 1) * 0.3;
          const sp = kind === 'burst' ? 420 : 620;
          boltsRef.current.push({ x: f.x, y: f.y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp, r: 8, color: ab.particleColor || HERO_COLORS[heroIndex], life: 1.6, owner: heroIndex });
        }
      }
      if (kind === 'ray') boltsRef.current.push({ x: f.x, y: f.y, vx: (ax / ad) * 780, vy: (ay / ad) * 780, r: 15, color: ab.particleColor || '#ffffff', life: 1.1, owner: heroIndex });
    };

    const t = ab.effectType;
    if (['dash_strike', 'slash_9999', 'speed_hack', 'kagune_frenzy', 'vent_ambush', 'tentacle_grasp'].includes(t)) push('dash', 1.3);
    else if (['repulsion_pulse', 'black_hole', 'hollow_purple', 'divine_smite', 'god_smite_rework', 'solar_flare', 'overkill_inferno'].includes(t)) push('ring', 1.1);
    else if (['sonic_boom', 'sniper_pierce', 'gaster_blaster', 'hadouken', 'sudo_rm', 'gojo_red', 'ultra_rainbow_blaster'].includes(t)) push('ray');
    else if (['mystery_chaos', 'rocket_barrage', 'knife_storm', 'burst'].includes(t)) push('burst');
    else push('ring', 0.8);

    b.hp = Math.max(0, b.hp - dmg);
    b.inv = 0.18;
    fxRef.current.push({ x: b.x, y: b.y - 30, text: `-${Math.round(dmg)}`, color: '#ffe8e8', life: 0.9 });
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    const wrap = wrapRef.current;
    if (!canvas || !wrap) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    let raf = 0;
    let last = performance.now();
    let resize = () => {
      const rect = wrap.getBoundingClientRect();
      canvas.width = rect.width || 600;
      canvas.height = rect.height || 600;
    };
    resize();
    window.addEventListener('resize', resize);

    const mk = (c: Character, name: string, x: number, y: number, hp: number, scale = 1): LocalFighter => ({
      id: Math.random().toString(36).slice(2), char: c, name, x, y, vx: 0, vy: 0,
      hp, maxHp: hp, radius: 34 * (c.isGiant ? Math.min(c.giantMultiplier || 1.5, 2) : 1) * scale, inv: 0, cd: [], angle: 0, hits: 0, dmg: 0,
    });

    const W = canvas.width, H = canvas.height;
    const bossHp = bossHealth(bossIn.id, heroes.length); // х1.9 в дуо
    bossRef.current = mk(bossIn, bossIn.name, W * 0.68, H * 0.5, bossHp, 1.8);
    const spots = [{ x: W * 0.22, y: H * 0.3 }, { x: W * 0.22, y: H * 0.7 }];
    teamRef.current = heroes.map((c, i) => {
      const f = mk(c, heroNames[i] || c.name, spots[i].x, spots[i].y, Math.min(60, Math.max(16, Math.round(c.maxHp * 2))));
      f.cd = (palettes[i] || []).map(() => 0);
      return f;
    });
    skills.current = palettes.map(() => []);
    setHpHud({ bossHp, bossMax: bossHp, team: teamRef.current.map(f => f.hp) });

    const loop = (t: number) => {
      const dt = Math.min((t - last) / 1000, 0.05);
      last = t;
      const w = canvas.width, h = canvas.height;
      ctx.clearRect(0, 0, w, h);
      ctx.fillStyle = '#0a0f16'; ctx.fillRect(0, 0, w, h);
      // сетка как в основной арене
      ctx.strokeStyle = 'rgba(255,255,255,.06)'; ctx.lineWidth = 1;
      ctx.beginPath();
      for (let x = 0; x < w; x += 40) { ctx.moveTo(x, 0); ctx.lineTo(x, h); }
      for (let y = 0; y < h; y += 40) { ctx.moveTo(0, y); ctx.lineTo(w, y); }
      ctx.stroke();
      ctx.strokeStyle = '#ffb86b66'; ctx.lineWidth = 4;
      ctx.strokeRect(4, 4, w - 8, h - 8);

      const b = bossRef.current!;
      const alive = teamRef.current.filter(f => f.hp > 0);

      teamRef.current.forEach((f, i) => {
        if (f.hp <= 0) return;
        const m = moves.current[i];
        f.cd = f.cd.map(c => Math.max(0, c - dt));
        if (m.x || m.y) {
          const mag = Math.hypot(m.x, m.y) || 1;
          f.vx += (m.x / mag) * 1900 * dt; f.vy += (m.y / mag) * 1900 * dt;
        } else { f.vx *= 0.8; f.vy *= 0.8; }
        const vel = Math.hypot(f.vx, f.vy);
        const maxV = (f.char.baseSpeed || 5) * 60;
        if (vel > maxV) { f.vx *= maxV / vel; f.vy *= maxV / vel; }
        // отскок от стен (как в основной игре)
        if (f.x < 30 + f.radius / 2) { f.x = 30 + f.radius / 2; f.vx = Math.abs(f.vx) * 0.9 + 20; }
        if (f.x > w - 30 - f.radius / 2) { f.x = w - 30 - f.radius / 2; f.vx = -Math.abs(f.vx) * 0.9 - 20; }
        if (f.y < 40 + f.radius / 2) { f.y = 40 + f.radius / 2; f.vy = Math.abs(f.vy) * 0.9 + 20; }
        if (f.y > h - 30 - f.radius / 2) { f.y = h - 30 - f.radius / 2; f.vy = -Math.abs(f.vy) * 0.9 - 20; }
        f.x += f.vx * dt; f.y += f.vy * dt;
        f.inv = Math.max(0, f.inv - dt);
        const adx = b.x - f.x, ady = b.y - f.y;
        f.angle = Math.atan2(ady, adx);
        // базовая авто-атака вблизи (урон от касания оружием)
        const touchR = f.radius + b.radius * 0.3 + 20;
        if (Math.hypot(adx, ady) < touchR && f.inv <= 0 && !finished.current) {
          f.inv = 0.6;
          const dmg = raidDamageBonus(bossIn.id) * 1.2;
          b.hp = Math.max(0, b.hp - dmg);
          b.inv = Math.max(b.inv, 0.1);
          f.hits++; f.dmg += dmg;
          fxRef.current.push({ x: b.x, y: b.y - 30, text: `-${Math.round(dmg)}`, color: '#ffd9c0', life: 0.7 });
          soundManager.playHit(true);
        }
      });

      // Босс атакует ближайшего живого героя.
      if (alive.length && !finished.current) {
        let target = alive[0];
        for (const f of alive) if (Math.hypot(b.x - f.x, b.y - f.y) < Math.hypot(b.x - target.x, b.y - target.y)) target = f;
        const tdx = target.x - b.x, tdy = target.y - b.y, td = Math.hypot(tdx, tdy) || 1;
        const bossSpeed = (bossIn.baseSpeed || 4.2) * 14;
        if (td > 90) { b.vx += (tdx / td) * bossSpeed * 6 * dt; b.vy += (tdy / td) * bossSpeed * 6 * dt; } else { b.vx *= 0.9; b.vy *= 0.9; }
        b.angle = Math.atan2(tdy, tdx);
        const bv = Math.hypot(b.vx, b.vy);
        if (bv > bossSpeed * 0.9) { b.vx *= (bossSpeed * 0.9) / bv; b.vy *= (bossSpeed * 0.9) / bv; }
        b.x += b.vx * dt; b.y += b.vy * dt;
        b.x = Math.max(150, Math.min(w - 150, b.x)); b.y = Math.max(120, Math.min(h - 120, b.y));
        b.inv = Math.max(0, b.inv - dt);
        if (td < b.radius * 0.7 + target.radius + 16 && target.inv <= 0 && b.inv <= 0) {
          b.inv = 0.6; target.hp = Math.max(0, target.hp - 1); target.inv = 0.7;
          fxRef.current.push({ x: target.x, y: target.y - 24, text: '-1', color: '#ff8a7a', life: 0.7 });
          soundManager.playHit(true);
        }
        if (Math.random() < dt * 0.55 && b.inv <= 0) {
          b.inv = 0.9;
          for (const f of alive) {
            if (Math.hypot(b.x - f.x, b.y - f.y) < 300) { f.hp = Math.max(0, f.hp - 1); f.inv = 0.5; fxRef.current.push({ x: f.x, y: f.y - 24, text: '-1', color: '#ffb086', life: 0.6 }); }
          }
          ctx.strokeStyle = '#ffb86655'; ctx.lineWidth = 6;
          ctx.beginPath(); ctx.arc(b.x, b.y, 120, 0, Math.PI * 2); ctx.stroke();
          soundManager.playHit(false);
        }
      }

      // Снаряды героев -> босс.
      for (let i = boltsRef.current.length - 1; i >= 0; i--) {
        const bolt = boltsRef.current[i];
        bolt.x += bolt.vx * dt; bolt.y += bolt.vy * dt;
        bolt.life -= dt;
        if (Math.hypot(bolt.x - b.x, bolt.y - b.y) < b.radius * 0.8 + bolt.r && !finished.current && b.inv <= 0) {
          const dmg = raidDamageBonus(bossIn.id);
          b.hp = Math.max(0, b.hp - dmg);
          b.inv = 0.2;
          fxRef.current.push({ x: bolt.x, y: bolt.y, text: `-${Math.round(dmg)}`, color: '#fff3d6', life: 0.7 });
          boltsRef.current.splice(i, 1);
          soundManager.playHit(true);
        } else if (bolt.x < -40 || bolt.y < -40 || bolt.x > w + 40 || bolt.y > h + 40 || bolt.life <= 0) boltsRef.current.splice(i, 1);
      }
      boltsRef.current.forEach(bl => { ctx.fillStyle = bl.color; ctx.shadowColor = bl.color; ctx.shadowBlur = 12; ctx.beginPath(); ctx.arc(bl.x, bl.y, bl.r, 0, Math.PI * 2); ctx.fill(); ctx.shadowBlur = 0; });

      // Партиклы-подсветка на героях.
      teamRef.current.forEach((f, i) => {
        if (f.hp <= 0) return;
        ctx.fillStyle = HERO_COLORS[i];
        ctx.globalAlpha = 0.25 + Math.sin(t / 120 + i) * 0.1;
        ctx.beginPath(); ctx.arc(f.x, f.y, f.radius + 8, 0, Math.PI * 2); ctx.fill();
        ctx.globalAlpha = 1;
      });

      // Рендер босса и героев.
      ctx.save(); ctx.translate(b.x, b.y); ctx.rotate(b.angle);
      drawCharacterAvatar(ctx, b.char, 0, 0, b.radius, 0, t / 600);
      ctx.restore();
      teamRef.current.forEach((f, i) => {
        if (f.hp <= 0) return;
        ctx.save(); ctx.translate(f.x, f.y); ctx.rotate(f.angle);
        drawCharacterAvatar(ctx, f.char, 0, 0, f.radius, 0, t / 500);
        ctx.restore();
        ctx.fillStyle = HERO_COLORS[i]; ctx.lineWidth = 2; ctx.globalAlpha = 0.55;
        ctx.beginPath(); ctx.arc(f.x, f.y, f.radius + 5, 0, Math.PI * 2); ctx.stroke(); ctx.globalAlpha = 1;
      });

      // Всплывающий урон.
      for (let i = fxRef.current.length - 1; i >= 0; i--) {
        const fxp = fxRef.current[i];
        fxp.y -= 26 * dt; fxp.life -= dt;
        ctx.globalAlpha = Math.max(0, Math.min(1, fxp.life * 2));
        ctx.fillStyle = fxp.color; ctx.font = '800 15px system-ui'; ctx.textAlign = 'center';
        ctx.fillText(fxp.text, fxp.x, fxp.y);
        ctx.globalAlpha = 1;
        if (fxp.life <= 0) fxRef.current.splice(i, 1);
      }

      setHpHud(prev => {
        const bh = Math.max(0, Math.ceil(b.hp));
        const team = teamRef.current.map(x => Math.max(0, Math.ceil(x.hp)));
        return prev.bossHp === bh && prev.team.every((v, k) => v === team[k]) ? prev : { bossHp: bh, bossMax: b.maxHp, team };
      });

      if (!finished.current) {
        if (b.hp <= 0) { finished.current = true; setResult('win'); soundManager.playVictory(); winRef.current?.(); }
        else if (alive.length === 0) { finished.current = true; setResult('lose'); soundManager.playDefeat(); }
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => { cancelAnimationFrame(raf); window.removeEventListener('resize', resize); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [heroes, bossIn]);

  return (
    <div className="w-full h-full bg-[#0b0f15] text-white flex flex-col overflow-hidden">
      <div className="flex items-center gap-3 px-3 py-2 bg-[#111720] border-b border-white/10 flex-shrink-0">
        <button onClick={onExit} className="w-9 h-9 flex items-center justify-center border border-white/15 rounded-lg text-slate-300 hover:text-white" aria-label="Выйти"><ArrowLeft size={18} /></button>
        <span className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-orange-300"><Crown size={16} /> Boss Raid · Ты + Друг</span>
        <span className="ml-auto flex items-center gap-2 text-xs text-slate-400"><Heart size={14} className="text-rose-400" /> {hpHud.team.join(' / ')}</span>
      </div>

      {/* HP босса */}
      <div className="px-4 pt-2 pb-1 flex-shrink-0">
        <div className="flex items-center gap-2">
          <span className="text-sm font-bold text-orange-200 truncate">{bossIn.name}</span>
          <div className="flex-1 h-4 bg-[#161c27] rounded overflow-hidden border border-orange-500/40">
            <div className="h-full bg-gradient-to-r from-orange-600 to-amber-400 transition-all duration-150" style={{ width: `${(hpHud.bossHp / hpHud.bossMax) * 100}%` }} />
          </div>
          <span className="text-xs text-orange-200 tabular-nums whitespace-nowrap">{hpHud.bossHp.toLocaleString()} / {hpHud.bossMax.toLocaleString()}</span>
        </div>
        <p className="text-[10px] text-slate-500 mt-1">Дуо: HP босса ×1.9 · полоса честная · Каждый бьёт отдельно</p>
      </div>

      {/* Баннер способности */}
      {banner && (
        <div className="pointer-events-none absolute top-16 left-1/2 -translate-x-1/2 z-30 bg-slate-950/85 border px-4 py-2 rounded-xl animate-pulse" style={{ borderColor: banner.color, color: banner.color }}>
          <span className="font-black uppercase tracking-wider text-xs">{banner.text}</span>
        </div>
      )}

      <div ref={wrapRef} className="relative flex-1 min-h-0">
        <canvas ref={canvasRef} className="w-full h-full" style={{ touchAction: 'none' }} />
        {result && (
          <div className="absolute inset-0 bg-black/70 flex items-center justify-center z-20">
            <div className="bg-[#141b26] border border-white/15 rounded-2xl p-6 text-center max-w-xs w-full">
              <div className="text-4xl mb-2">{result === 'win' ? '🏆' : '💀'}</div>
              <h3 className="text-xl font-black uppercase">{result === 'win' ? 'Босс повержен!' : 'Команда пала...'}</h3>
              <p className="text-xs text-slate-400 mt-2">{result === 'win' ? `Отличная командная работа против ${bossIn.name}!` : 'Смените тактику и попробуйте снова.'}</p>
              <div className="flex gap-2 mt-5">
                <button className="flex-1 py-2 rounded-xl bg-[#baf66a] text-black text-xs font-bold flex items-center justify-center gap-2" onClick={onRematch}><RefreshCw size={13} /> Реванш</button>
                <button className="flex-1 py-2 rounded-xl bg-slate-800 text-white text-xs font-bold" onClick={onExit}>В меню</button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Управление героев: джойстик + палитра всех способностей */}
      <div className="flex flex-wrap items-stretch gap-2 px-2 py-2 bg-[#111720] border-t border-white/10 flex-shrink-0">
        {heroes.map((_h, i) => (
          <div key={i} className="flex-1 min-w-[230px] bg-[#0b1018] border border-white/10 rounded-xl p-2 flex flex-col gap-1.5" style={{ borderColor: HERO_COLORS[i] + '66' }}>
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-md flex items-center justify-center text-xs font-black" style={{ background: HERO_COLORS[i], color: '#111' }}>{i + 1}</div>
              <div className="flex-1 min-w-0">
                <div className="text-[11px] font-bold truncate">{heroNames[i]}</div>
                <div className="text-[9px] text-slate-400">HP {hpHud.team[i] ?? '?'} · урон {Math.round(raidDamageBonus(bossIn.id))}/уд</div>
              </div>
            </div>
            {/* Палитра способностей: каждая отдельной кнопкой */}
            <div className="flex flex-wrap gap-1">
              {palettes[i]?.map((ab, abi) => {
                const cd = teamRef.current[i]?.cd[abi] ?? 0;
                const ready = cd <= 0 && teamRef.current[i]?.hp > 0 && !result;
                return (
                  <button
                    key={abi}
                    disabled={!ready}
                    onPointerDown={(e) => { e.preventDefault(); e.currentTarget.setPointerCapture(e.pointerId); if (ready) castAbility(i, abi); }}
                    className="flex-1 min-w-[68px] px-1 py-1.5 rounded-lg border text-center transition-all active:scale-95"
                    style={{ borderColor: (ab.particleColor || HERO_COLORS[i]) + '88', background: (ab.particleColor || HERO_COLORS[i]) + '14', opacity: ready ? 1 : 0.45 }}
                  >
                    <span className="block text-[6px] font-black uppercase leading-tight text-slate-200">{ab.nameRu}</span>
                    <span className="block text-[7px] mt-0.5" style={{ color: ab.particleColor || HERO_COLORS[i] }}>{ready ? `${ab.cooldown * 0.8}с` : `${cd.toFixed(1)}с`}</span>
                  </button>
                );
              })}
            </div>
            {/* Джойстик героя */}
            <div className="grid grid-cols-3 gap-0.5 mx-auto" style={{ touchAction: 'none' }}>
              <div /><DPadBtn dir="up" color={HERO_COLORS[i]} onHold={(v) => { moves.current[i].y = v ? -1 : 0; }} /><div />
              <DPadBtn dir="left" color={HERO_COLORS[i]} onHold={(v) => { moves.current[i].x = v ? -1 : 0; }} />
              <span className="text-[8px] font-black text-center self-center" style={{ color: HERO_COLORS[i] }}>{i + 1}</span>
              <DPadBtn dir="right" color={HERO_COLORS[i]} onHold={(v) => { moves.current[i].x = v ? 1 : 0; }} />
              <div /><DPadBtn dir="down" color={HERO_COLORS[i]} onHold={(v) => { moves.current[i].y = v ? 1 : 0; }} /><div />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function DPadBtn({ dir, color, onHold }: { dir: string; color: string; onHold: (v: boolean) => void }) {
  const glyph = dir === 'up' ? '▲' : dir === 'down' ? '▼' : dir === 'left' ? '◀' : '▶';
  return (
    <button
      style={{ touchAction: 'none', borderColor: color + '44', color }}
      className="w-8 h-8 bg-[#161d28] rounded border flex items-center justify-center text-xs active:bg-[#223042]"
      onPointerDown={(e) => { e.preventDefault(); e.currentTarget.setPointerCapture(e.pointerId); onHold(true); }}
      onPointerUp={() => onHold(false)} onPointerCancel={() => onHold(false)} onLostPointerCapture={() => onHold(false)}
      onContextMenu={(e) => e.preventDefault()}
    >{glyph}</button>
  );
}
