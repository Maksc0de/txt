import React, { useRef, useEffect, useState, useCallback } from 'react';
import { Character, FighterEntity, GameMode, GameSettings, Particle, FloatingText, PowerUpOrb, Projectile, Ability, EndlessSubmode } from '../../types/game';
import { drawCharacterAvatar } from '../../utils/characterRenderer';
import { ALL_CHARACTERS } from '../../data/characters';
import { soundManager } from '../../audio/soundManager';
import { bossHealth, raidDamageBonus } from '../../game/raidRules';

// 7 цветов кругов FINAL
const FINAL_CIRCLE_COLORS = ['#ef4444', '#f97316', '#facc15', '#22c55e', '#38bdf8', '#a855f7', '#ec4899'];

interface GameCanvasProps {
  playerChar: Character;
  botChar: Character;
  p2Char?: Character;
  gameMode: GameMode;
  /** Локальный дуо (2 игрока на одном устройстве): если true — оба HP = 1. */
  duoFinal?: boolean;
  settings: GameSettings;
  matchesPlayed: number;
  onMatchEnd: (winner: 'player' | 'bot' | 'p2', playerStats: { hits: number; damage: number; kills?: number; duration?: number }) => void;
  onPauseToggle?: () => void;
  isPaused?: boolean;
  /** Открытые ульты Годжо (3 квеста выполнены) */
  gojoAscended?: boolean;
  /** Мастери OVERKILL (1000 убийств / 99 побед / 1000 волн) */
  overkillMastery?: boolean;
  endlessSubmode?: EndlessSubmode;
  /** Включены ли мастери (можно отключить/включить). */
  enableLightingMastery?: boolean;
  enableHahahaMastery?: boolean;
  lightingMasteryUnlocked?: boolean;
  hahahaMasteryUnlocked?: boolean;
  /** Поток прогресса мастери к сохранению. */
  onMasteryProgress?: (p: { lightingAbilities?: number; lightingDistance?: number; lightingKills?: number; hahahaAbilities?: number; hahahaSurvive?: number; hahahaSecret?: number }) => void;
  /** Настройка мастери. */
  onSetMasteryToggle?: (key: 'lighting' | 'hahaha', value: boolean) => void;
}

export const GameCanvas: React.FC<GameCanvasProps> = ({
  playerChar,
  botChar,
  p2Char,
  gameMode,
  duoFinal = false,
  settings,
  matchesPlayed,
  onMatchEnd,
  isPaused = false,
  gojoAscended = false,
  overkillMastery = false,
  endlessSubmode = 'standard',
  enableLightingMastery = true,
  enableHahahaMastery = true,
  lightingMasteryUnlocked = false,
  hahahaMasteryUnlocked = false,
  onMasteryProgress,
  onSetMasteryToggle,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const pausedRef = useRef(isPaused);
  pausedRef.current = isPaused;
  const reportMatchRef = useRef(onMatchEnd);
  reportMatchRef.current = onMatchEnd;
  const endTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  // Накопители прогресса мастери и вспомогательные флаги эффектов.
  const masteryDocRef = useRef<{ abilities: number; distance: number; survived: number; hahahaSecret: number; kills: number }>({ abilities: 0, distance: 0, survived: 0, hahahaSecret: 0, kills: 0 });
  const lastPosRef = useRef<{ x: number; y: number } | null>(null);
  const speedGodRef = useRef<{ active: boolean; left: number }>({ active: false, left: 0 });
  const masteryProgressSent = useRef(false);
  // STELLAR: активный звездопад и визуальные разрезы арены (God of War / Раскол мира).
  const starfallRef = useRef<{ left: number; spawn: number; owner: string } | null>(null);
  const arenaCutsRef = useRef<Array<{ x: number; y: number; a: number; color: string; born: number }>>([]);
  // Стартовое время матча — защита от фарма (мгновенные победы не приносят наград).
  const matchStartRef = useRef(performance.now());
  const sendMastery = () => {
    if (masteryProgressSent.current) return;
    masteryProgressSent.current = true;
    const doc = masteryDocRef.current;
    onMasteryProgress?.({
      lightingAbilities: playerChar.id === 'lighting_secret' ? doc.abilities : 0,
      // Перевод мировых единиц в километры (примерный масштаб).
      lightingDistance: playerChar.id === 'lighting_secret' ? Math.round(doc.distance * 0.00001 * 10000) / 10000 : 0,
      lightingKills: playerChar.id === 'lighting_secret' ? doc.kills : 0,
      hahahaAbilities: playerChar.id === 'hahaha_troll' ? doc.abilities : 0,
      hahahaSurvive: playerChar.id === 'hahaha_troll' ? doc.survived : 0,
      hahahaSecret: playerChar.id === 'hahaha_troll' ? doc.hahahaSecret : 0,
    });
  };
  const sendMasteryRef = useRef(sendMastery);
  sendMasteryRef.current = sendMastery;
  const triggerSpeedGod = () => {
    if (playerChar.id !== 'lighting_secret' || !lightingMasteryUnlocked || !enableLightingMastery) return;
    if (speedGodRef.current.active) return;
    speedGodRef.current = { active: true, left: 7 };
    bannerRef.current = { text: 'SPEED GOD!', color: '#67e8f9', t: 1.9 };
    flashRef.current = { color: '#67e8f9', alpha: 0.4 };
    if (settings.screenShake) screenShakeRef.current = 12;
  };

  // Match state
  const [playerHp, setPlayerHp] = useState<number>(gameMode === 'final_health' ? 1 : playerChar.maxHp);
  const [botHp, setBotHp] = useState<number>(gameMode === 'final_health' ? 1 : botChar.maxHp);
  const [playerMaxHp, setPlayerMaxHp] = useState<number>(gameMode === 'final_health' ? 1 : playerChar.maxHp);
  const [botMaxHp, setBotMaxHp] = useState<number>(gameMode === 'final_health' ? 1 : botChar.maxHp);
  const [playerCooldown, setPlayerCooldown] = useState<number>(0);
  const [p2Cooldown, setP2Cooldown] = useState<number>(0);
  const [playerTransMeter, setPlayerTransMeter] = useState<number>(0);
  const [playerBuffs, setPlayerBuffs] = useState<{ hasShield: boolean; hasSpikes: boolean; speedBoost: boolean }>({
    hasShield: false,
    hasSpikes: false,
    speedBoost: false
  });

  // Input states
  const keysPressed = useRef<{ [key: string]: boolean }>({});
  const mobileInput = useRef<{ vx: number; vy: number; skill: boolean; dash: boolean }>({
    vx: 0,
    vy: 0,
    skill: false,
    dash: false
  });
  // Управление ВТОРОГО ИГРОКА на одном телефоне (верхняя часть экрана)
  const mobileInputP2 = useRef<{ vx: number; vy: number; skill: boolean; dash: boolean }>({
    vx: 0,
    vy: 0,
    skill: false,
    dash: false
  });

  // Dynamic Arena Sizing
  const currentArenaSize = useRef<{ width: number; height: number }>({ width: 560, height: 560 });

  // Match simulation refs
  const fighter1Ref = useRef<FighterEntity | null>(null);
  const fighter2Ref = useRef<FighterEntity | null>(null);
  const projectilesRef = useRef<Projectile[]>([]);
  const particlesRef = useRef<Particle[]>([]);
  const floatingTextsRef = useRef<FloatingText[]>([]);
  const orbsRef = useRef<PowerUpOrb[]>([]);
  const screenShakeRef = useRef<number>(0);
  const matchEndedRef = useRef<boolean>(false);
  const lastTimeRef = useRef<number>(performance.now());
  // Эпичная подача способностей: баннер по центру + вспышка экрана
  const bannerRef = useRef<{ text: string; color: string; t: number } | null>(null);
  const flashRef = useRef<{ color: string; alpha: number } | null>(null);
  // Кинематики: ритуал FINAL и HOLLOW PURPLE
  const cinematicRef = useRef<{ kind: 'final_ritual' | 'hollow_purple'; t: number; caster: FighterEntity; other: FighterEntity } | null>(null);
  // Бесконечная Бездна Годжо (домен)
  const domainRef = useRef<{ t: number; caster: FighterEntity; victim: FighterEntity; dmgTimer: number } | null>(null);
  // Clock Man: глобальная остановка времени для чужих снарядов.
  const timeStopRef = useRef<{ t: number; owner: FighterEntity['id'] } | null>(null);
  // Камера мира: нужна, когда арена (Гаргантюа) больше экрана.
  const cameraRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  // ULTRAKILL: шкала ярости, трансформация, кинематика и стирание при смерти.
  const ultraRef = useRef<{
    charge: number;
    awakened: boolean;
    shieldHp: number;
    shieldSpent: boolean;
    cine: number | null;
    death: number | null;
    slashes: Array<{ x: number; y: number; a: number }>;
  }>({ charge: 0, awakened: false, shieldHp: 0, shieldSpent: false, cine: null, death: null, slashes: [] });
  // Состояние пассивок (предыдущее HP/урон и таймеры).
  const passiveRef = useRef<{
    init: boolean;
    hp: Record<string, number>;
    dmg: Record<string, number>;
    godRegen: Record<string, number>;
  }>({ init: false, hp: {}, dmg: {}, godRegen: {} });
  const [ultraHud, setUltraHud] = useState<{ charge: number; awakened: boolean; shield: number }>({
    charge: 0,
    awakened: false,
    shield: 0
  });
  // ENDLESS: счётчик волн и убийств
  const endlessRef = useRef<{ kills: number; wave: number }>({ kills: 0, wave: 1 });
  const [endlessHud, setEndlessHud] = useState<{ kills: number; wave: number }>({ kills: 0, wave: 1 });
  // Название текущей способности для HUD (циклические)
  const [playerAbilityName, setPlayerAbilityName] = useState<string>(playerChar.ability.nameRu);
  const [p2AbilityName, setP2AbilityName] = useState<string>(botChar.ability.nameRu);
  // Палитра способностей игрока — все техники с кнопками на экране.
  const [palette, setPalette] = useState<Array<{ key: string; name: string; cd: number; locked: string; color: string }>>([]);
  const orbSpawnTimerRef = useRef<number>(0);
  // Секвенция второй жизни (Артём -> САХАРОК): таймер ритуала и фаза
  const secondLifeSeqRef = useRef<{ t: number; dying: FighterEntity; origRadius: number; clothColor: string } | null>(null);

  // Initialize Fighters
  const initFighters = useCallback((canvasWidth: number, canvasHeight: number) => {
    matchStartRef.current = performance.now(); // Старт секундомера матча.
    const isP1Giant = playerChar.isGiant;
    const isP2Giant = botChar.isGiant;
    const baseRadius = 32;

    // Локальный дуо: у обоих игроков HP по выбранному режиму (Final Health = 1).
    let maxHp1 = gameMode === 'final_health' || (gameMode === 'two_player' && duoFinal) ? 1 : playerChar.maxHp;
    let maxHp2 = gameMode === 'final_health' || (gameMode === 'two_player' && duoFinal) ? 1 : botChar.maxHp;

    // Рейдовый запас здоровья игрока: боссы остаются опасными, но бой можно выиграть.
    if (gameMode === 'boss_raid') {
      maxHp1 = Math.max(16, playerChar.maxHp * 2);
    }

    if (gameMode === 'boss_raid') maxHp2 = bossHealth(botChar.id, 1);

    const p1Radius = baseRadius * (isP1Giant ? playerChar.giantMultiplier || 1.5 : 1.0);
    const p2Radius = baseRadius * (isP2Giant ? botChar.giantMultiplier || 1.5 : 1.0);

    const centerX = canvasWidth / 2;
    const centerY = canvasHeight / 2;

    fighter1Ref.current = {
      id: 'player',
      // Копия персонажа — чтобы мутации (Сахарок и пр.) не портили глобальные данные
      character: { ...playerChar, ability: playerChar.ability ? { ...playerChar.ability } : undefined } as Character,
      x: centerX - 160,
      y: centerY,
      vx: (playerChar.baseSpeed + (playerChar.speedBonus || 0) * 0.1) * (playerChar.speedMultiplier || 1) * 0.8,
      vy: ((Math.random() - 0.5) * playerChar.baseSpeed) * (playerChar.speedMultiplier || 1) * 0.8,
      radius: p1Radius,
      angle: 0,
      weaponAngle: 0,
      hp: maxHp1,
      maxHp: maxHp1,
      hasSpikesBuff: false,
      spikesBuffTimer: 0,
      hasShield: false,
      shieldHitsRemaining: 0,
      speedBoostTimer: 0,
      freezeTimer: 0,
      invulnerableTimer: 0,
      abilityCooldownTimer: 0,
      abilityActiveTimer: 0,
      isTransformed: false,
      transformationMeter: 0,
      hitsDealt: 0,
      damageDealt: 0,
      kills: 0
    };

    fighter2Ref.current = {
      id: gameMode === 'two_player' ? 'p2' : 'bot',
      character: { ...(p2Char || botChar), ability: (p2Char || botChar).ability ? { ...(p2Char || botChar).ability! } : undefined } as Character,
      x: centerX + 160,
      y: centerY,
      vx: -(botChar.baseSpeed + (botChar.speedBonus || 0) * 0.1) * (botChar.speedMultiplier || 1) * 0.8,
      vy: ((Math.random() - 0.5) * botChar.baseSpeed) * (botChar.speedMultiplier || 1) * 0.8,
      radius: p2Radius,
      angle: Math.PI,
      weaponAngle: Math.PI,
      hp: maxHp2,
      maxHp: maxHp2,
      hasSpikesBuff: false,
      spikesBuffTimer: 0,
      hasShield: false,
      shieldHitsRemaining: 0,
      speedBoostTimer: 0,
      freezeTimer: 0,
      invulnerableTimer: 0,
      abilityCooldownTimer: 0,
      abilityActiveTimer: 0,
      isTransformed: false,
      transformationMeter: 0,
      hitsDealt: 0,
      damageDealt: 0,
      kills: 0
    };

    setPlayerHp(maxHp1);
    setBotHp(maxHp2);
    setPlayerMaxHp(maxHp1);
    setBotMaxHp(maxHp2);
    projectilesRef.current = [];
    particlesRef.current = [];
    floatingTextsRef.current = [];
    orbsRef.current = [];
    matchEndedRef.current = false;
  }, [playerChar, botChar, p2Char, gameMode]);

  // Handle Keyboard Inputs
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      keysPressed.current[e.code] = true;
      if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.code)) {
        e.preventDefault();
      }
    };
    const handleKeyUp = (e: KeyboardEvent) => {
      keysPressed.current[e.code] = false;
    };

    window.addEventListener('keydown', handleKeyDown, { passive: false });
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  // Spawn Particle Helper
  const createParticles = (
    x: number,
    y: number,
    color: string,
    count: number = 8,
    shape: 'circle' | 'spark' | 'ring' | 'star' = 'spark',
    speedMult: number = 1.0
  ) => {
    if (settings.particleDensity === 'low' && count > 4) count = 4;
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = (Math.random() * 4 + 2) * speedMult;
      particlesRef.current.push({
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        size: Math.random() * 4 + 2,
        color,
        alpha: 1.0,
        decay: Math.random() * 0.03 + 0.02,
        shape
      });
    }
  };

  // Floating text
  const addFloatingText = (x: number, y: number, text: string, color: string = '#ffffff', fontSize: number = 18) => {
    floatingTextsRef.current.push({
      id: Math.random().toString(),
      x,
      y,
      text,
      color,
      alpha: 1.0,
      vy: -1.5,
      fontSize
    });
  };

  // Цепочка способностей бойца (основная + extra, с учётом блокировок)
  const abilityListFor = useCallback((fighter: FighterEntity): Ability[] => {
    const c = fighter.character;
    const list: Ability[] = c.ability ? [c.ability] : [];
    if (c.extraAbilities) list.push(...c.extraAbilities);
    return list.filter(ab => {
      // Ульты Годжо требуют Пробуждения (3 квеста)
      if ((ab.id === 'hollow_purple' || ab.id === 'infinity_void') && !gojoAscended) return false;
      // Мастери OVERKILL
      if (ab.id === 'overkill_mastery' && !overkillMastery) return false;
      // FINAL: круговые атаки доступны только после ритуала
      if (c.id === 'final' && !fighter.finalCircles && (ab.id === 'circle_barrage' || ab.id === 'circle_nova')) return false;
      // FINAL: ритуал исчезает после исполнения
      if (c.id === 'final' && fighter.finalCircles && ab.id === 'final_ritual') return false;
      // ULTRAKILL: до пробуждения доступны 3 техники (+ ульта на 100% шкалы), после — набор меча.
      if (c.id === 'ultrakill') {
        const post = ['ultra_sword', 'ultra_rainbow_blaster', 'ultra_arena_cut'];
        if (ultraRef.current.awakened) return post.includes(ab.id);
        if (post.includes(ab.id)) return false;
        if (ab.id === 'ultra_ascend') return ultraRef.current.charge >= 100;
      }
      return true;
    });
  }, [gojoAscended, overkillMastery]);

  // Все техники игрока с признаками блокировки — для палитры кнопок на экране.
  const abilityOptionsFor = (fighter: FighterEntity): Array<{ key: string; name: string; cd: number; locked: string; color: string }> => {
    const c = fighter.character;
    const list = [c.ability, ...(c.extraAbilities || [])];
    return list.map(ab => {
      let locked = '';
      if ((ab.id === 'hollow_purple' || ab.id === 'infinity_void') && !gojoAscended) locked = 'Нужно пробуждение';
      else if (ab.id === 'overkill_mastery' && !overkillMastery) locked = 'Нужно мастери';
      else if (c.id === 'final') locked = !fighter.finalCircles && (ab.id === 'circle_barrage' || ab.id === 'circle_nova') ? 'После ритуала'
        : fighter.finalCircles && ab.id === 'final_ritual' ? 'Ритуал использован' : '';
      else if (c.id === 'ultrakill') {
        const post = ['ultra_sword', 'ultra_rainbow_blaster', 'ultra_arena_cut'];
        locked = ultraRef.current.awakened
          ? !post.includes(ab.id) ? 'Набор Семи Душ' : ''
          : post.includes(ab.id) ? 'После пробуждения' : ab.id === 'ultra_ascend' ? 'Ярость неполна' : '';
      }
      return { key: ab.id, name: ab.nameRu, cd: ab.cooldown, locked, color: ab.particleColor || c.glowColor };
    });
  };

  // Trigger Ability
  const triggerAbility = useCallback((fighter: FighterEntity, target: FighterEntity) => {
    if (fighter.abilityCooldownTimer > 0 || fighter.freezeTimer > 0) return;

    const abList = abilityListFor(fighter);
    if (abList.length === 0) return;
    fighter.abilitySlot = fighter.abilitySlot ?? 0;
    const ab = abList[fighter.abilitySlot % abList.length];
    // Циклируем способности для Годжо / FINAL
    fighter.abilitySlot = (fighter.abilitySlot + 1) % abList.length;

    // Мастери: -25% к перезарядке (Lighting), а также ускоряет смех hahaha при включённой мастери.
    const lightningCdBoost = fighter.character.id === 'lighting_secret' && lightingMasteryUnlocked && enableLightingMastery ? 0.75 : 1;
    const hahahaCdBoost = fighter.character.id === 'hahaha_troll' && hahahaMasteryUnlocked && enableHahahaMastery ? 0.75 : 1;
    fighter.abilityCooldownTimer = ab.cooldown * lightningCdBoost * hahahaCdBoost;
    fighter.abilityActiveTimer = ab.duration || 1.5;
    soundManager.playAbility(ab.effectType);
    // Счётчики мастери для бойца игрока.
    if (fighter.id === 'player') {
      masteryDocRef.current.abilities++;
      // Секретный 3-й квест hahaha: при использовании способности с шансом 0.5%
      // враг получает более долгий стан + 2 урона. Это и продвигает скрытый квест.
      if (fighter.character.id === 'hahaha_troll' && Math.random() < 0.005) {
        target.freezeTimer = Math.max(target.freezeTimer, 1.4);
        target.hp = Math.max(0, target.hp - 2);
        masteryDocRef.current.hahahaSecret++;
        addFloatingText(target.x, target.y - 34, 'LMAO... x2', '#f87171', 20);
      }
    }

    // ===== ЭПИЧНАЯ ПОДАЧА ЛЮБОЙ СПОСОБНОСТИ: баннер + вспышка экрана + кольцо =====
    bannerRef.current = { text: ab.nameRu, color: ab.particleColor || '#ffffff', t: 1.0 };
    flashRef.current = { color: ab.particleColor || '#ffffff', alpha: 0.16 };

    const targetHpBeforeAbility = target.hp;
    const dirX = target.x - fighter.x;
    const dirY = target.y - fighter.y;
    const dist = Math.hypot(dirX, dirY) || 1;
    const normX = dirX / dist;
    const normY = dirY / dist;
    // Служебный сдвиг начального угла для кольцевых залпов способностей
    const weaponOffset = Math.atan2(normY, normX);

    // Shake screen
    if (settings.screenShake) screenShakeRef.current = 10;

    // Ability specific logic
    switch (ab.effectType) {
      case 'dash_strike':
      case 'slash_9999':
      case 'speed_hack':
      case 'kagune_frenzy': {
        // High speed dash toward target
        fighter.vx = normX * 14;
        fighter.vy = normY * 14;
        fighter.invulnerableTimer = 0.5;
        createParticles(fighter.x, fighter.y, ab.particleColor || '#ef4444', 16, 'spark');
        addFloatingText(fighter.x, fighter.y - 20, ab.nameRu || 'РЫВОК!', ab.particleColor || '#ef4444', 20);
        break;
      }

      case 'sonic_boom':
      case 'sniper_pierce':
      case 'sudo_rm': {
        // Laser / piercing line projectile
        projectilesRef.current.push({
          id: Math.random().toString(),
          owner: fighter.id,
          x: fighter.x + normX * (fighter.radius + 15),
          y: fighter.y + normY * (fighter.radius + 15),
          vx: normX * 18,
          vy: normY * 18,
          radius: 12,
          damage: ab.damage || 2,
          color: ab.particleColor || '#00ffff',
          glowColor: ab.particleColor || '#00ffff',
          life: 0,
          maxLife: 60,
          type: 'laser',
          piercing: true
        });
        addFloatingText(fighter.x, fighter.y - 20, ab.nameRu, ab.particleColor || '#00ffff');
        break;
      }

      case 'hadouken':
      case 'rocket_barrage':
      case 'gaster_blaster':
      case 'tnt_block': {
        // Energy projectile / Blaster
        for (let i = -1; i <= 1; i++) {
          const spreadAngle = Math.atan2(normY, normX) + i * 0.25;
          projectilesRef.current.push({
            id: Math.random().toString(),
            owner: fighter.id,
            x: fighter.x + Math.cos(spreadAngle) * (fighter.radius + 10),
            y: fighter.y + Math.sin(spreadAngle) * (fighter.radius + 10),
            vx: Math.cos(spreadAngle) * 9,
            vy: Math.sin(spreadAngle) * 9,
            radius: 10,
            damage: ab.damage || 2,
            color: ab.particleColor || '#38bdf8',
            glowColor: ab.particleColor || '#38bdf8',
            life: 0,
            maxLife: 90,
            type: ab.effectType === 'tnt_block' ? 'tnt' : 'fireball',
            homing: ab.effectType === 'gaster_blaster'
          });
        }
        addFloatingText(fighter.x, fighter.y - 20, ab.nameRu, ab.particleColor || '#fbbf24');
        break;
      }

      case 'repulsion_pulse':
      case 'divine_smite':
      case 'overkill_inferno': {
        // Massive radial shockwave
        target.vx = normX * 12;
        target.vy = normY * 12;
        target.hp = Math.max(0, target.hp - (ab.damage || 2));
        createParticles(fighter.x, fighter.y, ab.particleColor || '#ff2200', 30, 'ring', 2.0);
        addFloatingText(target.x, target.y - 25, `-${ab.damage || 2} HP!`, '#ef4444', 24);
        soundManager.playHit(true);
        break;
      }

      // УОРДЕН-РЕМЕЙК: три расширяющихся сонар-кольца, урон зависит от близости к эпицентру + оглушение
      case 'sonic_ring': {
        for (let k = 0; k < 3; k++) {
          createParticles(fighter.x, fighter.y, ab.particleColor || '#00ffee', 1, 'ring', 1 + k);
        }
        const dmgRadius = fighter.radius * 6.5;
        if (dist < dmgRadius) {
          const proximity = 1 - dist / dmgRadius; // чем ближе, тем больнее
          const dmg = Math.max(1, Math.round((ab.damage || 2) * (0.6 + proximity)));
          target.hp = Math.max(0, target.hp - dmg);
          target.vx = normX * (7 + proximity * 8);
          target.vy = normY * (7 + proximity * 8);
          target.freezeTimer = 0.9 + proximity * 0.7; // рёв оглушает
          addFloatingText(target.x, target.y - 25, `-${dmg} ЗВУКОМ!`, '#00ffee', 22);
        }
        fighter.invulnerableTimer = 0.4;
        createParticles(fighter.x, fighter.y, ab.particleColor || '#00ffee', 22, 'spark');
        addFloatingText(fighter.x, fighter.y - 28, 'СОНАР ГЛУБИН!', ab.particleColor || '#00ffee', 22);
        soundManager.playHit(true);
        break;
      }

      // МАТЕМАТИЧКА: "К ДОСКЕ!" — стан + двойка
      case 'math_strike': {
        target.freezeTimer = 1.5;
        target.vx *= 0.05;
        target.vy *= 0.05;
        target.hp = Math.max(0, target.hp - (ab.damage || 2));
        createParticles(target.x, target.y, ab.particleColor || '#c084fc', 24, 'spark');
        addFloatingText(target.x, target.y - 30, 'ДВОЙКА! -2 HP', '#c084fc', 22);
        // дополнительные жесты учительницы
        addFloatingText(target.x, target.y - 52, 'К ДОСКЕ!!!', '#f5f3ff', 16);
        soundManager.playHit(true);
        break;
      }

      // GRUMBLE: щупальца тянут к себе + тройной удар
      case 'tentacle_grasp': {
        target.vx = -normX * 13;
        target.vy = -normY * 13;
        target.freezeTimer = 0.7;
        target.hp = Math.max(0, target.hp - (ab.damage || 3));
        createParticles(target.x, target.y, ab.particleColor || '#f97316', 28, 'spark');
        addFloatingText(target.x, target.y - 30, 'ЗАХВАТ ЩУПАЛЕЦ!', '#f97316', 22);
        addFloatingText(target.x, target.y - 52, `-${ab.damage || 3} HP!`, '#ef4444', 20);
        soundManager.playHit(true);
        break;
      }

      // ROBOT UPDATE EDITION: мощный плазменный шквал 8 зарядов + волна отбрасывания
      case 'plasma_overdrive': {
        // отброс противника
        target.vx = normX * 11;
        target.vy = normY * 11;
        const isOverkillMastery = ab.id === 'overkill_mastery';
        const shots = isOverkillMastery ? 12 : 8;
        if (isOverkillMastery) {
          // Режим перегрева: урон ×1.5 на 6 секунд
          fighter.damageMultiplier = Math.max(fighter.damageMultiplier || 1, 1.5);
          fighter.speedBoostTimer = 6;
          fighter.abilityActiveTimer = 6;
          setTimeout(() => {
            if (fighter.damageMultiplier === 1.5) fighter.damageMultiplier = 1;
          }, 6000);
          addFloatingText(fighter.x, fighter.y - 46, 'ПЕРЕГРЕВ! УРОН ×1.5', '#ffdd00', 20);
        }
        // шквал плазмы/лавы во все стороны
        for (let i = 0; i < shots; i++) {
          const a = (i * Math.PI * 2) / shots + weaponOffset;
          projectilesRef.current.push({
            id: Math.random().toString(),
            owner: fighter.id,
            x: fighter.x + Math.cos(a) * (fighter.radius + 12),
            y: fighter.y + Math.sin(a) * (fighter.radius + 12),
            vx: Math.cos(a) * 11,
            vy: Math.sin(a) * 11,
            radius: 11,
            damage: ab.damage || 3,
            color: ab.particleColor || '#22d3ee',
            glowColor: ab.particleColor || '#22d3ee',
            life: 0,
            maxLife: 70,
            type: 'fireball'
          });
        }
        createParticles(fighter.x, fighter.y, ab.particleColor || '#22d3ee', 30, 'ring', 2.0);
        addFloatingText(fighter.x, fighter.y - 30, 'ПЛАЗМЕННЫЙ ОВЕРДРАЙВ!', '#22d3ee', 22);
        soundManager.playHit(true);
        break;
        // weaponOffset — служебный сдвиг угла (определён ниже)
      }

      // CLOCK MAN: ОСТАНОВКА ВРЕМЕНИ НА 2.5 СЕКУНДЫ
      case 'time_freeze': {
        target.freezeTimer = 2.5;
        target.vx = 0;
        target.vy = 0;
        fighter.speedBoostTimer = 2.5;
        fighter.invulnerableTimer = 2.5;
        timeStopRef.current = { t: 2.5, owner: fighter.id };
        createParticles(target.x, target.y, ab.particleColor || '#fbbf24', 28, 'ring', 2.0);
        addFloatingText(fighter.x, fighter.y - 30, 'TIME STOP (2.5s)!', '#fbbf24', 24);
        soundManager.playAbility('mystery_chaos');
        flashRef.current = { color: '#fbbf24', alpha: 0.4 };
        break;
      }

      // KATANA USER: РАЗРЕЗ АРЕНЫ С БЫСТРЫМ КД 2.3с
      case 'katana_cut': {
        fighter.vx = normX * 18;
        fighter.vy = normY * 18;
        fighter.invulnerableTimer = 0.35;
        target.hp = Math.max(0, target.hp - (ab.damage || 2));
        target.vx = normX * 8;
        target.vy = normY * 8;
        for (let i = -8; i <= 8; i++) {
          const lx = fighter.x + normX * (i * 24);
          const ly = fighter.y + normY * (i * 24);
          createParticles(lx, ly, '#e11d48', 2, 'spark', 1.5);
        }
        createParticles(target.x, target.y, '#e11d48', 20, 'ring', 1.8);
        addFloatingText(fighter.x, fighter.y - 25, 'РАЗРЕЗ АРЕНЫ!', '#e11d48', 22);
        soundManager.playAbility('slash_9999');
        break;
      }

      // ERROR: РАЗРУШЕНИЕ РЕАЛЬНОСТИ 0xDEAD
      case 'error_corrupt': {
        target.freezeTimer = 1.2;
        target.hp = Math.max(0, target.hp - (ab.damage || 4));
        for (let b = 0; b < 8; b++) {
          const a = (b * Math.PI * 2) / 8 + weaponOffset;
          projectilesRef.current.push({
            id: Math.random().toString(),
            owner: fighter.id,
            x: fighter.x + Math.cos(a) * (fighter.radius + 15),
            y: fighter.y + Math.sin(a) * (fighter.radius + 15),
            vx: Math.cos(a) * 9,
            vy: Math.sin(a) * 9,
            radius: 9,
            damage: 1,
            color: '#ef4444',
            glowColor: '#ef4444',
            life: 0,
            maxLife: 100,
            type: 'bsod',
            homing: true
          });
        }
        createParticles(target.x, target.y, '#ef4444', 35, 'spark', 2.5);
        addFloatingText(target.x, target.y - 30, '0xDEAD CORRUPT -4 HP!', '#ef4444', 24);
        soundManager.playAbility('bsod_error');
        flashRef.current = { color: '#ef4444', alpha: 0.5 };
        if (settings.screenShake) screenShakeRef.current = 16;
        break;
      }

      // GOD: СВЯЩЕННЫЙ ГНЕВ НЕБЕС & ИСЦЕЛЕНИЕ
      case 'god_smite_rework': {
        fighter.hp = Math.min(fighter.maxHp, fighter.hp + 2);
        target.hp = Math.max(0, target.hp - (ab.damage || 4));
        target.freezeTimer = 1.0;
        target.vx = normX * 14;
        target.vy = normY * 14;
        createParticles(target.x, target.y, '#ffffff', 40, 'ring', 3.0);
        createParticles(fighter.x, fighter.y, '#fef08a', 25, 'spark', 2.0);
        addFloatingText(fighter.x, fighter.y - 30, '+2 HP ИСЦЕЛЕНИЕ!', '#22c55e', 20);
        addFloatingText(target.x, target.y - 45, '-4 СВЯЩЕННЫЙ ГНЕВ!', '#fef08a', 24);
        soundManager.playAbility('divine_smite');
        flashRef.current = { color: '#fef08a', alpha: 0.6 };
        if (settings.screenShake) screenShakeRef.current = 20;
        break;
      }

      // FLEX: ТИТАНИЧЕСКИЙ ГИГА-ФЛЕКС
      case 'flex_overpower': {
        target.hp = Math.max(0, target.hp - (ab.damage || 4));
        target.vx = normX * 18;
        target.vy = normY * 18;
        for (let w = 1; w <= 3; w++) {
          createParticles(fighter.x, fighter.y, '#10b981', 20, 'ring', w * 1.5);
        }
        addFloatingText(fighter.x, fighter.y - 30, 'ТИТАНИЧЕСКИЙ ГИГА-ФЛЕКС!', '#10b981', 24);
        addFloatingText(target.x, target.y - 50, '-4 УДАР!', '#ef4444', 22);
        soundManager.playAbility('repulsion_pulse');
        flashRef.current = { color: '#10b981', alpha: 0.4 };
        if (settings.screenShake) screenShakeRef.current = 22;
        break;
      }

      // ENDER DRAGON: рывок крыльями + портал Края + 10 самонаводящихся зарядов.
      case 'ender_cataclysm': {
        fighter.vx = normX * 16;
        fighter.vy = normY * 16;
        fighter.invulnerableTimer = 0.8;
        target.vx = normX * 11;
        target.vy = normY * 11;
        for (let i = 0; i < 10; i++) {
          const a = weaponOffset + ((i - 4.5) * 0.16);
          projectilesRef.current.push({
            id: Math.random().toString(), owner: fighter.id,
            x: fighter.x - normX * fighter.radius + Math.cos(a + Math.PI / 2) * (i - 4.5) * 9,
            y: fighter.y - normY * fighter.radius + Math.sin(a + Math.PI / 2) * (i - 4.5) * 9,
            vx: Math.cos(a) * 10, vy: Math.sin(a) * 10,
            radius: 9 + (i % 3), damage: 1,
            color: i % 2 ? '#d946ef' : '#7c3aed', glowColor: '#d946ef',
            life: 0, maxLife: 130, type: 'fireball', homing: true
          });
        }
        createParticles(fighter.x, fighter.y, '#d946ef', 40, 'ring', 2.8);
        addFloatingText(fighter.x, fighter.y - 42, 'КАТАКЛИЗМ КРАЯ!', '#f0abfc', 25);
        flashRef.current = { color: '#a855f7', alpha: 0.48 };
        if (settings.screenShake) screenShakeRef.current = 18;
        break;
      }

      // SANS: шесть видимых Гастер-Бластеров стреляют из разных сторон.
      case 'sans_blaster_wall': {
        for (let i = 0; i < 6; i++) {
          const a = (i * Math.PI * 2) / 6;
          const sx = target.x + Math.cos(a) * 210;
          const sy = target.y + Math.sin(a) * 210;
          const aim = Math.atan2(target.y - sy, target.x - sx);
          projectilesRef.current.push({
            id: Math.random().toString(), owner: fighter.id,
            x: sx, y: sy, vx: Math.cos(aim) * 18, vy: Math.sin(aim) * 18,
            radius: 13, damage: 1, color: '#dffaff', glowColor: '#38bdf8',
            life: 0, maxLife: 70, type: 'laser', piercing: true, delay: i * 5
          });
          createParticles(sx, sy, '#38bdf8', 8, 'ring', 1.6);
        }
        addFloatingText(target.x, target.y - 52, 'GASTER BLASTER WALL', '#38bdf8', 22);
        if (settings.screenShake) screenShakeRef.current = 14;
        break;
      }

      // SANS: костяная тюрьма сжимается вокруг цели.
      case 'sans_bone_zone': {
        for (let i = 0; i < 16; i++) {
          const a = (i * Math.PI * 2) / 16;
          const sx = target.x + Math.cos(a) * 190;
          const sy = target.y + Math.sin(a) * 190;
          projectilesRef.current.push({
            id: Math.random().toString(), owner: fighter.id,
            x: sx, y: sy, vx: -Math.cos(a) * 7, vy: -Math.sin(a) * 7,
            radius: 8, damage: 1, color: '#f8fafc', glowColor: '#7dd3fc',
            life: 0, maxLife: 90, type: 'bone', delay: (i % 4) * 4
          });
        }
        target.freezeTimer = Math.max(target.freezeTimer, 0.45);
        addFloatingText(target.x, target.y - 42, 'КОСТЯНАЯ ТЮРЬМА!', '#e0f2fe', 21);
        break;
      }

      // SANS: синяя душа - телекинез и бросок в стену.
      case 'sans_blue_soul': {
        target.hp = Math.max(0, target.hp - (ab.damage || 2));
        target.freezeTimer = 0.7;
        const horizontal = Math.abs(target.x - (canvasRef.current?.width || 600) / 2) > Math.abs(target.y - (canvasRef.current?.height || 600) / 2);
        if (horizontal) {
          target.vx = target.x < (canvasRef.current?.width || 600) / 2 ? -20 : 20;
          target.vy = 0;
        } else {
          target.vy = target.y < (canvasRef.current?.height || 600) / 2 ? -20 : 20;
          target.vx = 0;
        }
        createParticles(target.x, target.y, '#2563eb', 30, 'ring', 2.4);
        addFloatingText(target.x, target.y - 46, 'СИНЯЯ ДУША!', '#60a5fa', 24);
        break;
      }

      // SANS: BAD TIME - кости + четыре бластера одновременно.
      case 'sans_bad_time': {
        target.hp = Math.max(0, target.hp - 2);
        target.freezeTimer = 0.8;
        for (let i = 0; i < 12; i++) {
          const a = (i * Math.PI * 2) / 12;
          projectilesRef.current.push({
            id: Math.random().toString(), owner: fighter.id,
            x: target.x + Math.cos(a) * 175, y: target.y + Math.sin(a) * 175,
            vx: -Math.cos(a) * 9, vy: -Math.sin(a) * 9,
            radius: 9, damage: 1, color: '#ffffff', glowColor: '#00e5ff',
            life: 0, maxLife: 85, type: i % 3 === 0 ? 'laser' : 'bone', delay: i * 2
          });
        }
        createParticles(target.x, target.y, '#00e5ff', 35, 'ring', 3);
        addFloatingText(target.x, target.y - 54, 'YOU ARE GONNA HAVE A BAD TIME', '#00e5ff', 20);
        flashRef.current = { color: '#38bdf8', alpha: 0.35 };
        if (settings.screenShake) screenShakeRef.current = 18;
        break;
      }

      // Мифическая точка: абсолютная сингулярность и поглощение.
      case 'singularity_devour': {
        target.hp = Math.max(0, target.hp - (ab.damage || 4));
        fighter.hp = Math.min(fighter.maxHp, fighter.hp + 2);
        target.vx = -normX * 15;
        target.vy = -normY * 15;
        target.freezeTimer = 1.0;
        projectilesRef.current = projectilesRef.current.filter(p => p.owner === fighter.id);
        for (let i = 0; i < 4; i++) createParticles(fighter.x, fighter.y, i % 2 ? '#ffffff' : '#7c3aed', 18, 'ring', 1.5 + i);
        addFloatingText(fighter.x, fighter.y - 38, 'АБСОЛЮТНЫЙ ГОРИЗОНТ!', '#ffffff', 23);
        addFloatingText(fighter.x, fighter.y - 62, '+2 HP', '#22c55e', 18);
        flashRef.current = { color: '#ffffff', alpha: 0.42 };
        if (settings.screenShake) screenShakeRef.current = 20;
        break;
      }

      // SECRET GLITCH: переписывает позицию, физику и здоровье цели.
      case 'glitch_rewrite': {
        target.hp = Math.max(0, target.hp - (ab.damage || 5));
        target.freezeTimer = 1.6;
        const oldX = fighter.x;
        const oldY = fighter.y;
        fighter.x = target.x - normX * (target.radius + fighter.radius + 24);
        fighter.y = target.y - normY * (target.radius + fighter.radius + 24);
        fighter.invulnerableTimer = 1.2;
        for (let i = 0; i < 14; i++) {
          const a = (i * Math.PI * 2) / 14;
          projectilesRef.current.push({
            id: Math.random().toString(), owner: fighter.id,
            x: oldX, y: oldY, vx: Math.cos(a) * 10, vy: Math.sin(a) * 10,
            radius: 7 + (i % 4), damage: 1,
            color: i % 2 ? '#00f5ff' : '#ff1478', glowColor: i % 2 ? '#00f5ff' : '#ff1478',
            life: 0, maxLife: 100, type: 'bsod', homing: i % 3 === 0
          });
        }
        createParticles(target.x, target.y, '#ff1478', 45, 'spark', 2.8);
        addFloatingText(target.x, target.y - 52, 'WORLD_KERNEL REWRITTEN', '#00f5ff', 22);
        flashRef.current = { color: '#ff1478', alpha: 0.58 };
        if (settings.screenShake) screenShakeRef.current = 24;
        break;
      }

      // ULTRAKILL: удар о землю.
      case 'ultra_slam': {
        fighter.vx = normX * 15;
        fighter.vy = normY * 15;
        target.hp = Math.max(0, target.hp - (ab.damage || 2));
        target.vx = normX * 13;
        target.vy = normY * 13;
        target.freezeTimer = 0.5;
        createParticles(fighter.x, fighter.y, '#f87171', 30, 'ring', 2.2);
        addFloatingText(fighter.x, fighter.y - 34, 'GROUND SLAM!', '#fca5a5', 22);
        if (settings.screenShake) screenShakeRef.current = 16;
        break;
      }

      // ULTRAKILL: монета + рельсотрон.
      case 'ultra_railcoin': {
        projectilesRef.current.push({
          id: Math.random().toString(), owner: fighter.id,
          x: fighter.x + normX * (fighter.radius + 18), y: fighter.y + normY * (fighter.radius + 18),
          vx: normX * 26, vy: normY * 26,
          radius: 12, damage: ab.damage || 3,
          color: '#fde047', glowColor: '#fbbf24',
          life: 0, maxLife: 90, type: 'laser', piercing: true, homing: true
        });
        createParticles(fighter.x, fighter.y - 30, '#fde047', 20, 'spark', 1.6);
        addFloatingText(fighter.x, fighter.y - 40, 'COIN → RAILCANNON!', '#fde047', 21);
        break;
      }

      // ULTRAKILL: парирующий рывок, стирающий вражеские снаряды.
      case 'ultra_parry_dash': {
        projectilesRef.current = projectilesRef.current.filter(p => p.owner === fighter.id);
        fighter.vx = normX * 22;
        fighter.vy = normY * 22;
        fighter.invulnerableTimer = 0.6;
        target.hp = Math.max(0, target.hp - (ab.damage || 2));
        createParticles(fighter.x, fighter.y, '#38bdf8', 26, 'ring', 1.8);
        addFloatingText(fighter.x, fighter.y - 32, 'PARRY!', '#7dd3fc', 24);
        break;
      }

      // ULTRAKILL: пробуждение семи душ — запуск кинематики.
      case 'ultra_ascend': {
        ultraRef.current.cine = 0;
        ultraRef.current.charge = 0;
        fighter.invulnerableTimer = 6;
        soundManager.playSevenSoulsTheme();
        break;
      }

      // ULTRAKILL: взмах радужного меча.
      case 'ultra_sword': {
        target.hp = Math.max(0, target.hp - (ab.damage || 3));
        target.vx = normX * 12;
        target.vy = normY * 12;
        for (let i = 0; i < 18; i++) {
          const a = weaponOffset - 0.7 + (i / 17) * 1.4;
          createParticles(
            fighter.x + Math.cos(a) * (fighter.radius + 34),
            fighter.y + Math.sin(a) * (fighter.radius + 34),
            `hsl(${(i * 20) % 360}, 100%, 65%)`,
            2, 'spark', 1.4
          );
        }
        addFloatingText(fighter.x, fighter.y - 36, 'RADIANT SLASH!', '#f472b6', 22);
        break;
      }

      // ULTRAKILL: радужный Гастер-Бластер.
      case 'ultra_rainbow_blaster': {
        for (let i = 0; i < 4; i++) {
          const a = weaponOffset + (i - 1.5) * 0.18;
          projectilesRef.current.push({
            id: Math.random().toString(), owner: fighter.id,
            x: fighter.x + Math.cos(a) * (fighter.radius + 20),
            y: fighter.y + Math.sin(a) * (fighter.radius + 20),
            vx: Math.cos(a) * 19, vy: Math.sin(a) * 19,
            radius: 15, damage: ab.damage || 4,
            color: `hsl(${(i * 90) % 360}, 100%, 65%)`, glowColor: '#ffffff',
            life: 0, maxLife: 80, type: 'laser', piercing: true, delay: i * 4
          });
        }
        createParticles(fighter.x, fighter.y, '#22d3ee', 34, 'ring', 2.4);
        addFloatingText(fighter.x, fighter.y - 40, 'PRISM BLASTER!', '#22d3ee', 22);
        if (settings.screenShake) screenShakeRef.current = 14;
        break;
      }

      // ULTRAKILL: раскол мира — арена визуально разрезается навсегда.
      case 'ultra_arena_cut': {
        target.hp = Math.max(0, target.hp - (ab.damage || 5));
        target.freezeTimer = 1.1;
        ultraRef.current.slashes.push({
          x: (canvasRef.current?.width || 600) / 2 + (Math.random() - 0.5) * 120,
          y: (canvasRef.current?.height || 600) / 2 + (Math.random() - 0.5) * 120,
          a: Math.atan2(normY, normX) + (Math.random() - 0.5) * 0.5
        });
        if (ultraRef.current.slashes.length > 6) ultraRef.current.slashes.shift();
        for (let i = 0; i < 40; i++) {
          createParticles(target.x, target.y, `hsl(${(i * 9) % 360}, 100%, 62%)`, 2, 'spark', 2.6);
        }
        addFloatingText(target.x, target.y - 46, 'WORLD SPLITTER!', '#c084fc', 24);
        flashRef.current = { color: '#ffffff', alpha: 0.7 };
        if (settings.screenShake) screenShakeRef.current = 34;
        break;
      }

      // SECRET LIGHTING: семь молниеносных ударов и небесный шторм.
      // ===== STELLAR: STAR — 10 секунд звездопада (много слабых звёзд) =====
      case 'stellar_starfall': {
        starfallRef.current = { left: ab.duration || 10, spawn: 0, owner: fighter.id };
        addFloatingText(fighter.x, fighter.y - 40, 'STAR — ЗВЕЗДОПАД!', '#ffe9a8', 24);
        createParticles(fighter.x, fighter.y, '#ffe9a8', 30, 'star', 1.8);
        flashRef.current = { color: '#a5b4ff', alpha: 0.3 };
        break;
      }

      // ===== STELLAR: STR — хил 20% и звёздный щит =====
      case 'stellar_restore': {
        const heal = Math.max(1, Math.round(fighter.maxHp * 0.2));
        fighter.hp = Math.min(fighter.maxHp, fighter.hp + heal);
        fighter.hasShield = true;
        fighter.shieldHitsRemaining = 5;
        addFloatingText(fighter.x, fighter.y - 40, `+${heal} HP · ЩИТ 5`, '#a5b4ff', 22);
        createParticles(fighter.x, fighter.y, '#a5b4ff', 34, 'ring', 2.2);
        break;
      }

      // ===== GOD OF WAR: королевский разрез с рассечением арены =====
      case 'gow_royal_cut': {
        target.hp = Math.max(0, target.hp - (ab.damage || 6));
        target.freezeTimer = 0.8;
        target.vx = normX * 16;
        target.vy = normY * 16;
        arenaCutsRef.current.push({
          x: (canvasRef.current?.width || 600) / 2,
          y: (canvasRef.current?.height || 600) / 2,
          a: weaponOffset,
          color: '#ff7a45',
          born: performance.now(),
        });
        if (arenaCutsRef.current.length > 6) arenaCutsRef.current.shift();
        // Искры, пепел и вспышка по всей линии удара.
        for (let i = 0; i < 60; i++) {
          const t = i / 60;
          createParticles(
            fighter.x + Math.cos(weaponOffset) * t * 900,
            fighter.y + Math.sin(weaponOffset) * t * 900,
            i % 3 === 0 ? '#ffd9a0' : i % 3 === 1 ? '#ff5236' : '#7a2a16',
            2, 'spark', 2.4
          );
        }
        addFloatingText(target.x, target.y - 48, 'КОРОЛЕВСКИЙ РАЗРЕЗ!', '#ff7a45', 26);
        flashRef.current = { color: '#ffd9a0', alpha: 0.75 };
        if (settings.screenShake) screenShakeRef.current = 34;
        break;
      }

      // ===== GOD OF WAR: ярость Спарты =====
      case 'gow_spartan_rage': {
        fighter.damageMultiplier = Math.min(3, (fighter.damageMultiplier || 1) * 1.6);
        fighter.speedBoostTimer = 6;
        fighter.hp = Math.min(fighter.maxHp, fighter.hp + 3);
        target.vx = normX * 18;
        target.vy = normY * 18;
        target.hp = Math.max(0, target.hp - (ab.damage || 2));
        createParticles(fighter.x, fighter.y, '#ff3b2f', 44, 'ring', 2.6);
        addFloatingText(fighter.x, fighter.y - 42, 'ЯРОСТЬ СПАРТАНЦА!', '#ff3b2f', 24);
        if (settings.screenShake) screenShakeRef.current = 20;
        break;
      }

      // ===== GOD OF WAR: топор Левиафана (заморозка + возврат) =====
      case 'gow_axe_storm': {
        target.freezeTimer = Math.max(target.freezeTimer, 1.6);
        projectilesRef.current.push({
          id: Math.random().toString(), owner: fighter.id,
          x: fighter.x + normX * (fighter.radius + 14), y: fighter.y + normY * (fighter.radius + 14),
          vx: normX * 17, vy: normY * 17,
          radius: 13, damage: ab.damage || 4,
          color: '#8fe3ff', glowColor: '#d6f6ff',
          life: 0, maxLife: 110, type: 'blade' as never, piercing: true, returnAt: 34,
        });
        createParticles(target.x, target.y, '#8fe3ff', 26, 'ring', 1.8);
        addFloatingText(fighter.x, fighter.y - 38, 'ТОПОР ЛЕВИАФАНА!', '#8fe3ff', 22);
        break;
      }

      // ===== SWORD GLITCHER: одна из 20 форм, вид меняется вместе с техникой =====
      case 'sword_glitch_cycle': {
        const form = ((fighter.abilitySlot ?? 0) % 20 + 20) % 20;
        const blades = 8;
        target.hp = Math.max(0, target.hp - (ab.damage || 3));
        for (let i = 0; i < blades; i++) {
          const spread = form % 4 === 0 ? 0.16 : form % 4 === 1 ? 0.5 : form % 4 === 2 ? 0.9 : 0.32;
          const a = weaponOffset + (i - (blades - 1) / 2) * spread;
          projectilesRef.current.push({
            id: Math.random().toString(), owner: fighter.id,
            x: fighter.x + Math.cos(a) * (fighter.radius + 10),
            y: fighter.y + Math.sin(a) * (fighter.radius + 10),
            vx: Math.cos(a) * (13 + form * 0.3), vy: Math.sin(a) * (13 + form * 0.3),
            radius: 9, damage: 1,
            color: form % 2 ? '#ff4fd8' : '#8affd6', glowColor: '#e9fff8',
            life: 0, maxLife: 80, type: 'blade' as never,
            homing: form >= 18, delay: form >= 4 ? i * 2 : 0,
          });
        }
        createParticles(fighter.x, fighter.y, form % 2 ? '#ff4fd8' : '#8affd6', 26, 'spark', 2);
        addFloatingText(fighter.x, fighter.y - 40, ab.nameRu, form % 2 ? '#ff4fd8' : '#8affd6', 20);
        if (settings.screenShake) screenShakeRef.current = 10 + form * 0.4;
        break;
      }

      // ===== ECLIPSE (босс): пожирание света =====
      case 'eclipse_devour': {
        target.vx = -normX * 15;
        target.vy = -normY * 15;
        target.hp = Math.max(0, target.hp - (ab.damage || 4));
        target.freezeTimer = Math.max(target.freezeTimer, 0.6);
        for (let r = 0; r < 4; r++) createParticles(fighter.x, fighter.y, r % 2 ? '#c9a6ff' : '#ffd6a5', 22, 'ring', 1.5 + r * 0.7);
        addFloatingText(fighter.x, fighter.y - 46, 'ПОЖИРАНИЕ СВЕТА!', '#c9a6ff', 24);
        flashRef.current = { color: '#1b1327', alpha: 0.6 };
        if (settings.screenShake) screenShakeRef.current = 22;
        break;
      }

      case 'lightning_tempest': {
        target.hp = Math.max(0, target.hp - (ab.damage || 5));
        target.freezeTimer = 1.4;
        fighter.invulnerableTimer = 1.3;
        fighter.vx = normX * 24;
        fighter.vy = normY * 24;
        for (let i = 0; i < 7; i++) {
          const spread = weaponOffset + (i - 3) * 0.13;
          projectilesRef.current.push({
            id: Math.random().toString(), owner: fighter.id,
            x: fighter.x, y: fighter.y,
            vx: Math.cos(spread) * 20, vy: Math.sin(spread) * 20,
            radius: 8, damage: 1, color: '#fef08a', glowColor: '#67e8f9',
            life: 0, maxLife: 65, type: 'laser', piercing: true, delay: i * 3
          });
        }
        createParticles(target.x, target.y, '#67e8f9', 55, 'spark', 3.2);
        addFloatingText(target.x, target.y - 50, 'НЕБЕСНЫЙ ЭЛЕКТРОШТОРМ!', '#fef08a', 23);
        flashRef.current = { color: '#67e8f9', alpha: 0.62 };
        if (settings.screenShake) screenShakeRef.current = 25;
        break;
      }

      case 'freeze_wave':
      case 'jumpscare':
      case 'emergency_meeting':
      case 'bsod_error': {
        // Freeze / Stun target
        target.freezeTimer = 1.6;
        target.vx *= 0.1;
        target.vy *= 0.1;
        createParticles(target.x, target.y, ab.particleColor || '#38bdf8', 20, 'ring');
        addFloatingText(target.x, target.y - 20, 'ОГЛУШЕН!', ab.particleColor || '#38bdf8', 20);
        break;
      }

      case 'robot_transform': {
        // Mecha Robot transformation
        fighter.isTransformed = true;
        fighter.abilityActiveTimer = 7.0; // 7 seconds transformed!
        fighter.radius *= 1.4;
        createParticles(fighter.x, fighter.y, '#38bdf8', 25, 'spark', 2.0);
        addFloatingText(fighter.x, fighter.y - 30, 'МЕХА АКТИВИРОВАНА!', '#38bdf8', 22);
        break;
      }

      case 'spawn_minions': {
        // Spawn 2 attack drones
        for (let m = 0; m < 2; m++) {
          projectilesRef.current.push({
            id: Math.random().toString(),
            owner: fighter.id,
            x: fighter.x + (Math.random() - 0.5) * 40,
            y: fighter.y + (Math.random() - 0.5) * 40,
            vx: (Math.random() - 0.5) * 5,
            vy: (Math.random() - 0.5) * 5,
            radius: 8,
            damage: 1,
            color: ab.particleColor || '#c084fc',
            glowColor: ab.particleColor || '#c084fc',
            life: 0,
            maxLife: 180,
            type: 'minion',
            homing: true
          });
        }
        addFloatingText(fighter.x, fighter.y - 20, 'ДРОНЫ!', '#c084fc');
        break;
      }

      case 'mystery_chaos': {
        // Mystery chaos - triggers random powerful burst
        fighter.vx = (Math.random() - 0.5) * 16;
        fighter.vy = (Math.random() - 0.5) * 16;
        target.hp = Math.max(0, target.hp - 2);
        createParticles(target.x, target.y, '#e879f9', 24, 'ring');
        addFloatingText(target.x, target.y - 20, 'ХАОС 999!', '#e879f9', 22);
        break;
      }

      // ===== FINAL: Ритуал семи кругов — старт кинематики =====
      case 'final_ritual': {
        cinematicRef.current = { kind: 'final_ritual', t: 0, caster: fighter, other: target };
        if (settings.screenShake) screenShakeRef.current = 14;
        soundManager.playAbility('mystery_chaos');
        break;
      }

      // ===== FINAL: Залп 7 кругов как у Санса (по очереди за арену и возврат) =====
      case 'circle_barrage': {
        for (let i = 0; i < 7; i++) {
          const a = (i * Math.PI * 2) / 7;
          projectilesRef.current.push({
            id: Math.random().toString(),
            owner: fighter.id,
            x: fighter.x + Math.cos(a) * (fighter.radius * 1.7),
            y: fighter.y + Math.sin(a) * (fighter.radius * 1.7),
            vx: Math.cos(a) * 17,
            vy: Math.sin(a) * 17,
            radius: 10,
            damage: ab.damage || 2,
            color: FINAL_CIRCLE_COLORS[i],
            glowColor: FINAL_CIRCLE_COLORS[i],
            life: 0,
            maxLife: 95,
            type: 'laser',
            piercing: true,
            delay: i * 12,
            returnAt: 42
          });
        }
        createParticles(fighter.x, fighter.y, '#37e2ff', 26, 'spark');
        addFloatingText(fighter.x, fighter.y - 30, 'СЕМЕРИЧНЫЙ ПРИГОВОР!', ab.particleColor || '#37e2ff', 20);
        break;
      }

      // ===== FINAL: Радужная спираль-Нова =====
      case 'circle_nova': {
        for (let i = 0; i < 7; i++) {
          projectilesRef.current.push({
            id: Math.random().toString(),
            owner: fighter.id,
            x: fighter.x,
            y: fighter.y,
            vx: 0,
            vy: 0,
            radius: 11,
            damage: ab.damage || 2,
            color: FINAL_CIRCLE_COLORS[i],
            glowColor: FINAL_CIRCLE_COLORS[i],
            life: 0,
            maxLife: 130,
            type: 'spiral',
            spiralAngle: (i * Math.PI * 2) / 7,
            spiralDist: fighter.radius + 8
          });
        }
        createParticles(fighter.x, fighter.y, '#a855f7', 30, 'spark');
        addFloatingText(fighter.x, fighter.y - 30, 'ПРИЗМАТИЧЕСКАЯ НОВА!', ab.particleColor || '#a855f7', 20);
        break;
      }

      // ===== ГОДЖО: Синий — орбитальная сфера притяжения =====
      case 'gojo_blue': {
        const arenaCx = canvasRef.current ? canvasRef.current.width / 2 : 300;
        const arenaCy = canvasRef.current ? canvasRef.current.height / 2 : 300;
        const startAngle = Math.atan2(fighter.y - arenaCy, fighter.x - arenaCx);
        projectilesRef.current.push({
          id: Math.random().toString(),
          owner: fighter.id,
          x: fighter.x + normX * (fighter.radius + 40),
          y: fighter.y + normY * (fighter.radius + 40),
          vx: 0,
          vy: 0,
          radius: 22,
          damage: ab.damage || 2,
          color: '#60a5fa',
          glowColor: '#60a5fa',
          life: 0,
          maxLife: 185,
          type: 'gojo_blue',
          captureX: target.x,
          captureY: target.y,
          orbitAngle: startAngle + 0.6,
          drainAcc: 0
        });
        addFloatingText(fighter.x, fighter.y - 30, 'СИНИЙ!', '#60a5fa', 24);
        createParticles(fighter.x, fighter.y, '#60a5fa', 20, 'spark');
        break;
      }

      // ===== ГОДЖО: Красный — стоячий красный круг + взрыв =====
      case 'gojo_red': {
        projectilesRef.current.push({
          id: Math.random().toString(),
          owner: fighter.id,
          x: fighter.x + normX * (fighter.radius + 75),
          y: fighter.y + normY * (fighter.radius + 75),
          vx: 0,
          vy: 0,
          radius: 26,
          damage: ab.damage || 3,
          color: '#f87171',
          glowColor: '#ef4444',
          life: 0,
          maxLife: 80,
          type: 'gojo_red',
          drainAcc: 0
        });
        addFloatingText(fighter.x, fighter.y - 30, 'КРАСНЫЙ!', '#f87171', 24);
        createParticles(fighter.x + normX * 40, fighter.y + normY * 40, '#f87171', 22, 'spark');
        break;
      }

      // ===== ГОДЖО: HOLLOW PURPLE — кинематика слияния Синего и Красного =====
      case 'hollow_purple': {
        cinematicRef.current = { kind: 'hollow_purple', t: 0, caster: fighter, other: target };
        if (settings.screenShake) screenShakeRef.current = 12;
        soundManager.playAbility('hollow_purple');
        break;
      }

      // ===== ГОДЖО: Расширение территории «Бесконечная Бездна» =====
      case 'domain_infinite': {
        domainRef.current = { t: 0, caster: fighter, victim: target, dmgTimer: 0 };
        target.freezeTimer = 4.2;
        fighter.invulnerableTimer = 4.2;
        addFloatingText(fighter.x, fighter.y - 40, 'БЕСКОНЕЧНАЯ БЕЗДНА!', '#7c3aed', 26);
        soundManager.playAbility('hollow_purple');
        if (settings.screenShake) screenShakeRef.current = 14;
        break;
      }
        // Generic buff/dash
        fighter.vx = normX * 8;
        fighter.vy = normY * 8;
        break;
    }

    // Множитель формы применяется и к прямым способностям (Падший ANGEL наносит меньше урона).
    const rawDirectDamage = Math.max(0, targetHpBeforeAbility - target.hp);
    if (rawDirectDamage > 0 && (fighter.damageMultiplier || 1) !== 1) {
      const scaledDirectDamage = Math.max(1, Math.round(rawDirectDamage * (fighter.damageMultiplier || 1)));
      target.hp = Math.max(0, targetHpBeforeAbility - scaledDirectDamage);
    }

    // Прямые способности игрока получают рейдовый пробой брони босса.
    if (gameMode === 'boss_raid' && fighter.id === 'player') {
      const directDamage = Math.max(0, targetHpBeforeAbility - target.hp);
      if (directDamage > 0) {
        const raidMultiplier = raidDamageBonus(target.character.id);
        target.hp = Math.max(0, target.hp - directDamage * (raidMultiplier - 1));
        addFloatingText(target.x, target.y - 72, `РЕЙДОВЫЙ ПРОБОЙ x${raidMultiplier}`, '#fbbf24', 16);
      }
    }
  }, [settings.screenShake, abilityListFor, gameMode]);

  // Main 60fps Game Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas dimensions
    const updateCanvasSize = () => {
      const rect = canvas.getBoundingClientRect();
      canvas.width = rect.width || 600;
      canvas.height = rect.height || 600;
    };
    updateCanvasSize();
    initFighters(canvas.width, canvas.height);

    let animationFrameId: number;

    const gameLoop = (time: number) => {
      const dt = Math.min((time - lastTimeRef.current) / 1000, 0.1);
      lastTimeRef.current = time;

      if (!pausedRef.current && !matchEndedRef.current && fighter1Ref.current && fighter2Ref.current) {
        const p1 = fighter1Ref.current;
        const p2 = fighter2Ref.current;

        // ================= СЕКВЕНЦИЯ ВТОРОЙ ЖИЗНИ (Артём -> САХАРОК) =================
        // Экран темнеет, время останавливается, тело распадается на частицы и возрождается новая форма!
        if (secondLifeSeqRef.current) {
          const seq = secondLifeSeqRef.current;
          seq.t += dt;
          const dying = seq.dying;

          // ВРЕМЯ ОСТАНОВЛЕНО: оба бойца заморожены, мигает тьма
          p1.freezeTimer = Math.max(p1.freezeTimer, 0.2);
          p2.freezeTimer = Math.max(p2.freezeTimer, 0.2);
          p1.vx *= 0.85;
          p1.vy *= 0.85;
          p2.vx *= 0.85;
          p2.vy *= 0.85;

          // Распад на частицы: струим золотые искры по телу Артёма
          if (Math.random() < 0.8) {
            createParticles(
              dying.x + (Math.random() - 0.5) * dying.radius * 2,
              dying.y + (Math.random() - 0.5) * dying.radius * 2,
              Math.random() < 0.5 ? '#fcd34d' : '#fbbf24',
              2,
              'spark'
            );
          }
          // Тело медленно прячется
          dying.radius = Math.max(dying.radius * 0.995, seq.origRadius * 0.25);

          // ФАЗА МЕТАМОРФОЗЫ: тело исчезает и появляется вторая форма.
          if (seq.t >= 2.0 && !dying.sugarokForm) {
            dying.sugarokForm = true;
            const sl = dying.character.secondLife!;
            // Полная смена образа бойца
            dying.character = {
              ...dying.character,
              name: sl.name,
              titleRu: sl.nameRu,
              avatarColor: sl.avatarColor,
              glowColor: sl.glowColor,
              secondaryColor: '#1f2937',
              iconEmoji: sl.avatarEmoji,
              baseSpeed: dying.character.baseSpeed * sl.speedMul,
              weaponColor: sl.glowColor
            };
            dying.radius = seq.origRadius * sl.sizeMul;
            dying.maxHp = sl.maxHp;
            dying.hp = sl.maxHp;
            dying.damageMultiplier = sl.damageMul || 1;
            dying.invulnerableTimer = 1.5;
            dying.freezeTimer = 0.8;
            dying.character = { ...dying.character, weight: Math.max(1, dying.character.weight * 0.7) };
            // Мгновенный рывок второй формы вперёд.
            dying.vx = (dying.id === 'player' ? 1 : -1) * 6;
            createParticles(dying.x, dying.y, '#fbbf24', 40, 'spark');
            createParticles(dying.x, dying.y, sl.glowColor, 1, 'ring', 3);
            addFloatingText(dying.x, dying.y - 40, `${sl.nameRu.toUpperCase()}!`, sl.glowColor, 28);
            addFloatingText(dying.x, dying.y - 68, 'ВТОРАЯ ЖИЗНЬ', '#ffffff', 16);
            soundManager.playAbility('mystery_chaos');
            if (settings.screenShake) screenShakeRef.current = 16;
          }

          // Финиш секвенции — время возобновляется
          if (seq.t >= 3.0) {
            secondLifeSeqRef.current = null;
          }

          // Обновляем частицы и тексты (физика боя на паузе)
          particlesRef.current.forEach(pt => {
            pt.x += pt.vx;
            pt.y += pt.vy;
            pt.alpha -= pt.decay;
          });
          particlesRef.current = particlesRef.current.filter(pt => pt.alpha > 0);
          floatingTextsRef.current.forEach(ft => {
            ft.y += ft.vy;
            ft.alpha -= 0.02;
          });
          floatingTextsRef.current = floatingTextsRef.current.filter(ft => ft.alpha > 0);

          // --- Рендер кадра паузы-ритуала ---
          const aW = currentArenaSize.current.width;
          const aH = currentArenaSize.current.height;
          const aL = (canvas.width - aW) / 2;
          const aT = (canvas.height - aH) / 2;
          ctx.clearRect(0, 0, canvas.width, canvas.height);
          ctx.fillStyle = '#090d16';
          ctx.fillRect(aL, aT, aW, aH);
          // бойцы в темноте (только силуэты)
          ctx.save();
          ctx.translate(p1.x, p1.y);
          drawCharacterAvatar(ctx, p1.character, 0, 0, p1.radius, p1.angle, p1.weaponAngle, p1);
          ctx.restore();
          ctx.save();
          ctx.translate(p2.x, p2.y);
          drawCharacterAvatar(ctx, p2.character, 0, 0, p2.radius, p2.angle, p2.weaponAngle, p2);
          ctx.restore();
          // частицы
          particlesRef.current.forEach(pt => {
            ctx.save();
            ctx.globalAlpha = Math.max(0, pt.alpha);
            ctx.fillStyle = pt.color;
            ctx.shadowColor = pt.color;
            ctx.shadowBlur = 6;
            ctx.beginPath();
            ctx.arc(pt.x, pt.y, pt.size, 0, Math.PI * 2);
            ctx.fill();
            ctx.restore();
          });
          floatingTextsRef.current.forEach(ft => {
            ctx.save();
            ctx.globalAlpha = ft.alpha;
            ctx.fillStyle = ft.color;
            ctx.font = `900 ${ft.fontSize || 16}px Inter, sans-serif`;
            ctx.textAlign = 'center';
            ctx.shadowColor = ft.color;
            ctx.shadowBlur = 12;
            ctx.fillText(ft.text, ft.x, ft.y);
            ctx.restore();
          });
          // ТЕМНОТА вокруг + золотое мерцание в центре ритуала
          const lifeAlpha = seq.t < 2.0 ? 0.15 + Math.sin(seq.t * 8) * 0.07 : Math.max(0, 0.5 - (seq.t - 2.0) * 0.5);
          const rg = ctx.createRadialGradient(seq.dying.x, seq.dying.y, 20, seq.dying.x, seq.dying.y, Math.max(aW, aH) * 0.8);
          rg.addColorStop(0, `rgba(251,191,36,${0.35 * (1 - Math.min(1, seq.t / 2))})`);
          rg.addColorStop(0.4, `rgba(9,13,22,${0.55 + lifeAlpha})`);
          rg.addColorStop(1, `rgba(0,0,0,${0.92})`);
          ctx.fillStyle = rg;
          ctx.fillRect(0, 0, canvas.width, canvas.height);
          // Подпись ритуала
          if (seq.t < 2.0) {
            ctx.save();
            ctx.globalAlpha = Math.min(1, seq.t * 1.5);
            ctx.textAlign = 'center';
            ctx.font = `900 ${Math.min(34, canvas.width * 0.05)}px Inter, sans-serif`;
            ctx.fillStyle = seq.dying.character.glowColor;
            ctx.shadowColor = seq.dying.character.glowColor;
            ctx.shadowBlur = 24;
            ctx.fillText(`${seq.dying.character.name.toUpperCase()} ИСЧЕЗАЕТ...`, canvas.width / 2, canvas.height * 0.22);
            ctx.font = `600 ${Math.min(16, canvas.width * 0.028)}px Inter, sans-serif`;
            ctx.fillStyle = '#fcd34d';
            ctx.fillText('вторая жизнь приближается', canvas.width / 2, canvas.height * 0.22 + 30);
            ctx.restore();
          }

          animationFrameId = requestAnimationFrame(gameLoop);
          return; // ЖДЁМ ОКОНЧАНИЯ РИТУАЛА — игра вне времени
        }

        // ================= ULTRAKILL: ПРОБУЖДЕНИЕ СЕМИ ДУШ / СТИРАНИЕ =================
        if (ultraRef.current.cine !== null || ultraRef.current.death !== null) {
          const isDeath = ultraRef.current.death !== null;
          const t = (isDeath ? ultraRef.current.death! : ultraRef.current.cine!) + dt;
          if (isDeath) ultraRef.current.death = t;
          else ultraRef.current.cine = t;

          const hero =
            p1.character.id === 'ultrakill' ? p1 : p2.character.id === 'ultrakill' ? p2 : p1;

          // Время полностью остановлено.
          p1.freezeTimer = Math.max(p1.freezeTimer, 0.3);
          p2.freezeTimer = Math.max(p2.freezeTimer, 0.3);
          p1.vx *= 0.7; p1.vy *= 0.7;
          p2.vx *= 0.7; p2.vy *= 0.7;

          ctx.clearRect(0, 0, canvas.width, canvas.height);
          // Полностью чёрный экран: виден только сам персонаж.
          ctx.fillStyle = '#000000';
          ctx.fillRect(0, 0, canvas.width, canvas.height);

          const hx = canvas.width / 2;
          const hy = canvas.height / 2;

          if (!isDeath) {
            // Плавно нарастающая радуга.
            const ramp = Math.min(1, Math.max(0, (t - 1.1) / 3.0));
            if (ramp > 0) {
              const hue = (t * 150) % 360;
              ctx.fillStyle = `hsla(${hue}, 100%, 55%, ${0.06 + ramp * 0.4})`;
              ctx.fillRect(0, 0, canvas.width, canvas.height);
              const rg = ctx.createRadialGradient(hx, hy, 20, hx, hy, Math.max(canvas.width, canvas.height) * 0.7);
              rg.addColorStop(0, `hsla(${(hue + 40) % 360}, 100%, 70%, ${0.25 + ramp * 0.5})`);
              rg.addColorStop(1, 'rgba(0,0,0,0)');
              ctx.fillStyle = rg;
              ctx.fillRect(0, 0, canvas.width, canvas.height);
            }

            // Глитч-дёрганье силуэта.
            const jx = (Math.random() - 0.5) * (t > 1.1 ? 9 : 2);
            const jy = (Math.random() - 0.5) * (t > 1.1 ? 9 : 2);
            ctx.save();
            ctx.translate(hx + jx, hy + jy);
            drawCharacterAvatar(ctx, hero.character, 0, 0, hero.radius, 0, hero.weaponAngle, hero);
            ctx.restore();

            if (t > 3.2) {
              // Крылья и меч проявляются к финалу.
              ctx.save();
              ctx.translate(hx, hy);
              const wingHue = (t * 200) % 360;
              ctx.strokeStyle = `hsl(${wingHue}, 100%, 70%)`;
              ctx.shadowColor = `hsl(${(wingHue + 90) % 360}, 100%, 65%)`;
              ctx.shadowBlur = 26;
              ctx.lineWidth = 4;
              for (const side of [-1, 1]) {
                for (let f2 = 0; f2 < 4; f2++) {
                  ctx.beginPath();
                  ctx.moveTo(side * hero.radius * 0.5, 0);
                  ctx.quadraticCurveTo(
                    side * hero.radius * (1.8 + f2 * 0.4), -hero.radius * (0.7 + f2 * 0.35),
                    side * hero.radius * (1.1 + f2 * 0.5), -hero.radius * (1.9 + f2 * 0.3)
                  );
                  ctx.stroke();
                }
              }
              ctx.strokeStyle = '#ffffff';
              ctx.lineWidth = 6;
              ctx.beginPath();
              ctx.moveTo(-hero.radius * 0.3, hero.radius * 0.9);
              ctx.lineTo(hero.radius * 1.9, -hero.radius * 1.5);
              ctx.stroke();
              ctx.restore();
            }

            ctx.textAlign = 'center';
            ctx.font = `900 ${Math.min(40, canvas.width * 0.06)}px 'Courier New', monospace`;
            ctx.fillStyle = `hsl(${(t * 220) % 360}, 100%, 72%)`;
            ctx.shadowColor = '#ffffff';
            ctx.shadowBlur = 18;
            if (t > 1.3) ctx.fillText('SEVEN SOULS', hx + (Math.random() - 0.5) * 6, canvas.height * 0.2);
            if (t > 2.6) {
              ctx.font = `700 ${Math.min(18, canvas.width * 0.03)}px Inter, sans-serif`;
              ctx.fillText('DETERMINATION OVERFLOW', hx, canvas.height * 0.2 + 34);
            }

            if (t >= 5.2) {
              // Применяем трансформацию.
              const u = ultraRef.current;
              u.awakened = true;
              u.cine = null;
              u.shieldSpent = false;
              hero.maxHp = Math.max(1, Math.round(hero.maxHp * 0.9 * 100) / 100);
              hero.hp = Math.min(hero.maxHp, Math.max(1, Math.round(hero.hp * 0.9 * 100) / 100));
              hero.damageMultiplier = (hero.damageMultiplier || 1) * 1.25;
              hero.character = {
                ...hero.character,
                baseSpeed: hero.character.baseSpeed * 1.25,
                weaponType: 'sword',
                weaponCount: 2,
                weaponColor: '#f472b6',
                glowColor: '#ffffff'
              };
              hero.abilitySlot = 0;
              hero.invulnerableTimer = 1.2;
              if (hero.id === 'player') setPlayerMaxHp(hero.maxHp);
              else setBotMaxHp(hero.maxHp);
              bannerRef.current = { text: 'ULTRAKILL ПРОБУЖДЁН', color: '#f472b6', t: 1.8 };
              flashRef.current = { color: '#ffffff', alpha: 0.9 };
              if (settings.screenShake) screenShakeRef.current = 26;
            }
          } else {
            // СМЕРТЬ: тряска, затем полное стирание персонажа.
            const shake = t < 1.4 ? (1.4 - t) * 26 : 0;
            const dissolve = Math.min(1, Math.max(0, (t - 1.4) / 1.6));
            ctx.save();
            ctx.translate(hx + (Math.random() - 0.5) * shake, hy + (Math.random() - 0.5) * shake);
            ctx.globalAlpha = 1 - dissolve;
            drawCharacterAvatar(ctx, hero.character, 0, 0, hero.radius * (1 - dissolve * 0.4), 0, hero.weaponAngle, hero);
            ctx.restore();
            if (dissolve > 0 && Math.random() < 0.9) {
              createParticles(
                hx + (Math.random() - 0.5) * hero.radius * 2,
                hy + (Math.random() - 0.5) * hero.radius * 2,
                `hsl(${Math.random() * 360}, 100%, 70%)`, 2, 'spark', 1.2
              );
            }
            particlesRef.current.forEach(pt => {
              pt.x += pt.vx; pt.y += pt.vy; pt.alpha -= pt.decay;
              ctx.save();
              ctx.globalAlpha = Math.max(0, pt.alpha) * (1 - dissolve * 0.6);
              ctx.fillStyle = pt.color;
              ctx.beginPath();
              ctx.arc(pt.x, pt.y, pt.size, 0, Math.PI * 2);
              ctx.fill();
              ctx.restore();
            });
            particlesRef.current = particlesRef.current.filter(pt => pt.alpha > 0);

            ctx.textAlign = 'center';
            ctx.font = `900 ${Math.min(34, canvas.width * 0.05)}px 'Courier New', monospace`;
            ctx.fillStyle = `rgba(248,250,252,${1 - dissolve})`;
            ctx.fillText('ERASED', hx + (Math.random() - 0.5) * shake, canvas.height * 0.24);

            if (t >= 3.2 && !matchEndedRef.current) {
              matchEndedRef.current = true;
              const winner: 'player' | 'bot' | 'p2' =
                hero.id === 'player' ? (gameMode === 'two_player' ? 'p2' : 'bot') : 'player';
              reportMatchRef.current(winner, {
                hits: p1.hitsDealt,
                damage: p1.damageDealt,
                kills: gameMode === 'endless' ? p1.kills : undefined,
                duration: (performance.now() - matchStartRef.current) / 1000
              });
            }
          }

          animationFrameId = requestAnimationFrame(gameLoop);
          return;
        }

        // ================= КИНЕМАТИКИ: РИТУАЛ FINAL / HOLLOW PURPLE =================
        if (cinematicRef.current) {
          const seq = cinematicRef.current;
          seq.t += dt;
          const caster = seq.caster;
          const other = seq.other;

          // ВРЕМЯ ОСТАНОВЛЕНО: никто не двигается
          p1.freezeTimer = Math.max(p1.freezeTimer, 0.2);
          p2.freezeTimer = Math.max(p2.freezeTimer, 0.2);
          p1.vx *= 0.8; p1.vy *= 0.8;
          p2.vx *= 0.8; p2.vy *= 0.8;

          particlesRef.current.forEach(pt => { pt.x += pt.vx; pt.y += pt.vy; pt.alpha -= pt.decay; });
          particlesRef.current = particlesRef.current.filter(pt => pt.alpha > 0);
          floatingTextsRef.current.forEach(ft => { ft.y += ft.vy; ft.alpha -= 0.02; });
          floatingTextsRef.current = floatingTextsRef.current.filter(ft => ft.alpha > 0);

          const aW = currentArenaSize.current.width;
          const aH = currentArenaSize.current.height;
          const aL = (canvas.width - aW) / 2;
          const aT = (canvas.height - aH) / 2;

          const lerp = (a: number, b: number, k: number) => a + (b - a) * k;
          const easeIO = (k: number) => (k < 0.5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2);

          if (seq.kind === 'final_ritual') {
            // ---------- РИТУАЛ СЕМИ КРУГОВ FINAL ----------
            const dark = Math.min(0.9, seq.t * 0.5);
            const ringStart = Math.max(aW, aH) * 0.46;
            const progress = Math.min(1, Math.max(0, (seq.t - 0.4) / 2.0));
            const ringR = lerp(ringStart, caster.radius * 1.55, easeIO(progress));
            const spinSpeed = 1.5 + progress * 4.5;

            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.fillStyle = '#090d16';
            ctx.fillRect(aL, aT, aW, aH);
            ctx.strokeRect(aL, aT, aW, aH);
            ctx.save(); ctx.translate(p1.x, p1.y); drawCharacterAvatar(ctx, p1.character, 0, 0, p1.radius, p1.angle, p1.weaponAngle, p1); ctx.restore();
            ctx.save(); ctx.translate(p2.x, p2.y); drawCharacterAvatar(ctx, p2.character, 0, 0, p2.radius, p2.angle, p2.weaponAngle, p2); ctx.restore();

            // Тьма
            ctx.fillStyle = `rgba(0,0,0,${dark})`;
            ctx.fillRect(0, 0, canvas.width, canvas.height);

            // 7 цветных кругов закручиваются
            for (let i = 0; i < 7; i++) {
              const ang = (i * Math.PI * 2) / 7 + seq.t * spinSpeed;
              const cx = caster.x + Math.cos(ang) * ringR;
              const cy = caster.y + Math.sin(ang) * ringR;
              const col = FINAL_CIRCLE_COLORS[i];
              ctx.save();
              // шлейф между кругами
              const angNext = ((i + 1) * Math.PI * 2) / 7 + seq.t * spinSpeed;
              ctx.strokeStyle = col + '55';
              ctx.lineWidth = 2;
              ctx.beginPath();
              ctx.moveTo(cx, cy);
              ctx.lineTo(caster.x + Math.cos(angNext) * ringR, caster.y + Math.sin(angNext) * ringR);
              ctx.stroke();
              // сам круг
              ctx.fillStyle = col;
              ctx.shadowColor = col;
              ctx.shadowBlur = 22;
              ctx.beginPath();
              ctx.arc(cx, cy, 13 * (1 - progress * 0.35), 0, Math.PI * 2);
              ctx.fill();
              ctx.fillStyle = '#ffffff';
              ctx.beginPath();
              ctx.arc(cx, cy, 4.5, 0, Math.PI * 2);
              ctx.fill();
              ctx.restore();
            }

            // Имя FINAL дёргается
            ctx.save();
            ctx.textAlign = 'center';
            const jit = () => (Math.random() - 0.5) * 6;
            ctx.font = `900 ${Math.min(52, canvas.width * 0.08)}px 'Courier New', monospace`;
            ctx.fillStyle = '#0ff';
            ctx.globalAlpha = 0.8;
            ctx.fillText('FINAL', canvas.width / 2 + 3 + jit(), canvas.height * 0.2);
            ctx.fillStyle = '#f43f5e';
            ctx.fillText('FINAL', canvas.width / 2 - 3 + jit(), canvas.height * 0.2 + jit());
            ctx.globalAlpha = 1;
            ctx.fillStyle = '#f8fafc';
            ctx.fillText('FINAL', canvas.width / 2 + jit() * 0.5, canvas.height * 0.2);
            ctx.font = `700 ${Math.min(15, canvas.width * 0.024)}px Inter, sans-serif`;
            ctx.fillStyle = '#fda4af';
            ctx.fillText('СЕМЬ КРУГОВ СХОДЯТСЯ... НИКТО НЕ МОЖЕТ ДВИГАТЬСЯ', canvas.width / 2, canvas.height * 0.2 + 34);
            ctx.restore();

            // Завершение ритуала — круги становятся частью бойца! (FINAL сильнее OVERKILL)
            if (seq.t >= 2.6) {
              caster.finalCircles = true;
              caster.hp = caster.maxHp; // ПОЛНАЯ починка
              caster.character = { ...caster.character, baseSpeed: caster.character.baseSpeed * 2.2 };
              caster.damageMultiplier = 1.6; // ×1.6 урона — мощнее любого OVERKILL!
              caster.invulnerableTimer = 1.2;
              caster.character = { ...caster.character, weaponColor: '#fda4af' };
              createParticles(caster.x, caster.y, '#f43f5e', 60, 'spark');
              addFloatingText(caster.x, caster.y - 46, 'HP 100% • СКОРОСТЬ ×2.2 • УРОН ×1.6', '#fda4af', 18);
              addFloatingText(caster.x, caster.y - 72, 'FINAL ПРОБУЖДЁН!', '#f43f5e', 26);
              flashRef.current = { color: '#f43f5e', alpha: 0.7 };
              bannerRef.current = { text: 'FINAL ПРОБУЖДЁН! Сильнее любого OVERKILL', color: '#f43f5e', t: 1.6 };
              if (settings.screenShake) screenShakeRef.current = 22;
              soundManager.playVictory();
              cinematicRef.current = null;
            }
          } else {
            // ---------- HOLLOW PURPLE (Годжо) ----------
            const T = seq.t;
            const dark = T < 1 ? T * 0.85 : T < 2.2 ? 0.85 : Math.max(0, 0.85 - (T - 2.2) * 1.4);
            const merge = Math.min(1, Math.max(0, (T - 0.9) / 1.3));
            const me = easeIO(merge);
            const blueStart = { x: caster.x - 170, y: caster.y - 70 };
            const redStart = { x: caster.x + 170, y: caster.y - 70 };
            const bx = lerp(blueStart.x, caster.x, me);
            const by = lerp(blueStart.y, caster.y, me);
            const rx = lerp(redStart.x, caster.x, me);
            const ry = lerp(redStart.y, caster.y, me);

            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.fillStyle = '#090d16';
            ctx.fillRect(aL, aT, aW, aH);
            ctx.strokeRect(aL, aT, aW, aH);
            ctx.save(); ctx.translate(p1.x, p1.y); drawCharacterAvatar(ctx, p1.character, 0, 0, p1.radius, p1.angle, p1.weaponAngle, p1); ctx.restore();
            ctx.save(); ctx.translate(p2.x, p2.y); drawCharacterAvatar(ctx, p2.character, 0, 0, p2.radius, p2.angle, p2.weaponAngle, p2); ctx.restore();
            ctx.fillStyle = `rgba(0,0,0,${dark})`;
            ctx.fillRect(0, 0, canvas.width, canvas.height);

            // Синий слева пеё, красный справа — сливаются в фиолетовый
            const orbR = T < 2.2 ? 20 + Math.sin(T * 7) * 3 : 20 + (T - 2.2) * 90;
            if (merge < 1 || T < 2.2) {
              ctx.save();
              ctx.fillStyle = merge > 0.65 ? '#a855f7' : '#60a5fa';
              ctx.shadowColor = ctx.fillStyle;
              ctx.shadowBlur = 26;
              ctx.beginPath(); ctx.arc(bx, by, orbR, 0, Math.PI * 2); ctx.fill();
              ctx.fillStyle = merge > 0.65 ? '#a855f7' : '#f87171';
              ctx.shadowColor = ctx.fillStyle;
              ctx.beginPath(); ctx.arc(rx, ry, orbR, 0, Math.PI * 2); ctx.fill();
              ctx.restore();
            }
            if (T >= 2.2) {
              // Единый ПУСТОТНЫЙ за спиной Годжо
              ctx.save();
              ctx.fillStyle = '#c084fc';
              ctx.shadowColor = '#a855f7';
              ctx.shadowBlur = 45;
              ctx.beginPath(); ctx.arc(caster.x, caster.y, orbR, 0, Math.PI * 2); ctx.fill();
              ctx.strokeStyle = '#a855f788';
              ctx.lineWidth = 3;
              for (let r = 0; r < 3; r++) {
                ctx.beginPath();
                ctx.arc(caster.x, caster.y, orbR + 14 + r * 12 + Math.sin(T * 5 + r) * 5, 0, Math.PI * 2);
                ctx.stroke();
              }
              ctx.restore();
            }

            ctx.save();
            ctx.textAlign = 'center';
            ctx.font = `900 ${Math.min(34, canvas.width * 0.055)}px Inter, sans-serif`;
            ctx.fillStyle = merge < 0.5 ? '#93c5fd' : '#c084fc';
            ctx.shadowColor = '#a855f7';
            ctx.shadowBlur = 20;
            ctx.fillText('HOLLOW PURPLE', canvas.width / 2, canvas.height * 0.18);
            ctx.restore();

            // Выстрел: экран дико трясётся, шар летит за экран
            if (T >= 2.62 && !matchEndedRef.current) {
              const ang = Math.atan2(other.y - caster.y, other.x - caster.x) || 0;
              projectilesRef.current.push({
                id: Math.random().toString(),
                owner: caster.id,
                x: caster.x + Math.cos(ang) * (caster.radius + 30),
                y: caster.y + Math.sin(ang) * (caster.radius + 30),
                vx: Math.cos(ang) * 24,
                vy: Math.sin(ang) * 24,
                radius: 26,
                damage: 5,
                color: '#c084fc',
                glowColor: '#a855f7',
                life: 0,
                maxLife: 400,
                type: 'hollow_purple',
                piercing: true
              });
              flashRef.current = { color: '#a855f7', alpha: 0.6 };
              if (settings.screenShake) screenShakeRef.current = 26;
              soundManager.playHit(true);
              cinematicRef.current = null;
            }
          }

          animationFrameId = requestAnimationFrame(gameLoop);
          return;
        }

        // ================= ДОМЕН ГОДЖО «БЕСКОНЕЧНАЯ БЕЗДНА» =================
        if (domainRef.current) {
          const d = domainRef.current;
          d.t += dt;
          d.dmgTimer += dt;
          // Жертва парализована вечным потоком информации
          d.victim.freezeTimer = Math.max(d.victim.freezeTimer, 0.3);
          d.victim.vx *= 0.8;
          d.victim.vy *= 0.8;
          // Разум перегружается — периодический урон
          if (d.dmgTimer >= 1.1) {
            d.dmgTimer = 0;
            d.victim.hp = Math.max(0, d.victim.hp - 1);
            addFloatingText(d.victim.x, d.victim.y - 30, '-1 ПУСТОТА', '#c084fc', 20);
            createParticles(d.victim.x, d.victim.y, '#7c3aed', 14, 'spark');
            soundManager.playHit(false);
          }
          // Домен схлопывается
          if (d.t >= 4.2) {
            createParticles(d.caster.x, d.caster.y, '#c084fc', 30, 'ring', 3);
            flashRef.current = { color: '#c084fc', alpha: 0.4 };
            domainRef.current = null;
          }
        }

        if (timeStopRef.current) {
          timeStopRef.current.t -= dt;
          if (timeStopRef.current.t <= 0) timeStopRef.current = null;
        }

        // Dynamic Arena Sizing: если есть LEVIATHAN — арена становится гигантской на весь экран
        const isGargantuaPresent = p1.character.id === 'gargantua_leviathan' || p2.character.id === 'gargantua_leviathan';
        const isLeviathanPresent = p1.character.id === 'leviathan' || p2.character.id === 'leviathan';

        const hasGiant = p1.character.isGiant || p2.character.isGiant || p1.isTransformed || p2.isTransformed;

        let desiredW: number;
        let desiredH: number;
        if (isGargantuaPresent) {
          // Гаргантюа: мир в 7 раз шире/выше обычной арены. На экране видна только часть колосса.
          desiredW = 560 * 7;
          desiredH = 540 * 7;
        } else if (isLeviathanPresent) {
          // Обычный Leviathan тоже требует большого мира, но меньше Гаргантюа.
          desiredW = 560 * 4;
          desiredH = 540 * 4;
        } else if (hasGiant) {
          desiredW = Math.min(canvas.width - 24, 840);
          desiredH = Math.min(canvas.height - 24, 700);
        } else {
          // Обычный стандартный квадрат
          desiredW = Math.min(canvas.width - 40, 560);
          desiredH = Math.min(canvas.height - 40, 540);
        }

        const targetArenaWidth = desiredW;
        const targetArenaHeight = desiredH;

        currentArenaSize.current.width += (targetArenaWidth - currentArenaSize.current.width) * 0.05;
        currentArenaSize.current.height += (targetArenaHeight - currentArenaSize.current.height) * 0.05;

        const arenaLeft = (canvas.width - currentArenaSize.current.width) / 2;
        const arenaRight = arenaLeft + currentArenaSize.current.width;
        const arenaTop = (canvas.height - currentArenaSize.current.height) / 2;
        const arenaBottom = arenaTop + currentArenaSize.current.height;

        // 1. Process Player 1 Controls (WASD / Arrows / Touch)
        let inputX = 0;
        let inputY = 0;
        if (keysPressed.current['KeyW'] || keysPressed.current['ArrowUp']) inputY -= 1;
        if (keysPressed.current['KeyS'] || keysPressed.current['ArrowDown']) inputY += 1;
        if (keysPressed.current['KeyA'] || keysPressed.current['ArrowLeft']) inputX -= 1;
        if (keysPressed.current['KeyD'] || keysPressed.current['ArrowRight']) inputX += 1;

        // Add mobile touch joystick
        if (mobileInput.current.vx !== 0 || mobileInput.current.vy !== 0) {
          inputX += mobileInput.current.vx;
          inputY += mobileInput.current.vy;
        }

        const isDashing =
          keysPressed.current['ShiftLeft'] ||
          (gameMode !== 'two_player' && keysPressed.current['ShiftRight']) ||
          mobileInput.current.dash;
        const speedMultiplier = (p1.speedBoostTimer > 0 ? 1.5 : 1.0) * (isDashing ? 1.3 : 1.0);

        if (p1.freezeTimer <= 0) {
          if (inputX !== 0 || inputY !== 0) {
            const mag = Math.hypot(inputX, inputY) || 1;
            const accel = 0.45 * speedMultiplier;
            p1.vx += (inputX / mag) * accel;
            p1.vy += (inputY / mag) * accel;
          }
        }

        // Trigger player ability on Space / Button
        if (keysPressed.current['Space'] || mobileInput.current.skill) {
          triggerAbility(p1, p2);
        }

        // 2. Process Player 2 Controls (Two Player mode) OR AI Bot Logic
        if (gameMode === 'two_player') {
          let p2X = 0;
          let p2Y = 0;
          if (keysPressed.current['Numpad8'] || keysPressed.current['KeyI']) p2Y -= 1;
          if (keysPressed.current['Numpad5'] || keysPressed.current['KeyK']) p2Y += 1;
          if (keysPressed.current['Numpad4'] || keysPressed.current['KeyJ']) p2X -= 1;
          if (keysPressed.current['Numpad6'] || keysPressed.current['KeyL']) p2X += 1;

          // Сенсорное управление друга (ВЕРХ экрана, перевёрнутое)
          if (mobileInputP2.current.vx !== 0 || mobileInputP2.current.vy !== 0) {
            p2X += mobileInputP2.current.vx;
            p2Y += mobileInputP2.current.vy;
          }

          const p2Dash = keysPressed.current['ShiftRight'] || mobileInputP2.current.dash;
          const p2SpeedMult = (p2.speedBoostTimer > 0 ? 1.5 : 1.0) * (p2Dash ? 1.3 : 1.0);

          if (p2.freezeTimer <= 0 && (p2X !== 0 || p2Y !== 0)) {
            const mag = Math.hypot(p2X, p2Y) || 1.0;
            p2.vx += (p2X / mag) * 0.45 * p2SpeedMult;
            p2.vy += (p2Y / mag) * 0.45 * p2SpeedMult;
          }
          // У друга тоже МОЩНАЯ способность (Enter / KeyO / кнопка сверху)
          if (keysPressed.current['Enter'] || keysPressed.current['KeyO'] || mobileInputP2.current.skill) {
            mobileInputP2.current.skill = false; // разовое срабатывание на тапе
            triggerAbility(p2, p1);
          }
        } else {
          // AI Bot logic scaling with player's matches played!
          const botSkillLevel = Math.min(1.0, 0.35 + matchesPlayed * 0.08); // scaled intelligence
          if (p2.freezeTimer <= 0) {
            // Steering toward player or powerup
            let targetX = p1.x;
            let targetY = p1.y;

            // If powerups exist, smart bot goes for them!
            if (orbsRef.current.length > 0 && Math.random() < botSkillLevel) {
              targetX = orbsRef.current[0].x;
              targetY = orbsRef.current[0].y;
            }

            const dx = targetX - p2.x;
            const dy = targetY - p2.y;
            const d = Math.hypot(dx, dy) || 1;
            const botAccel = (0.2 + botSkillLevel * 0.25) * (p2.character.baseSpeed / 5) * (p2.character.speedMultiplier || 1);

            p2.vx += (dx / d) * botAccel;
            p2.vy += (dy / d) * botAccel;

            // Bot activates ability when in range
            if (d < 220 && p2.abilityCooldownTimer <= 0 && Math.random() < 0.04 * botSkillLevel) {
              triggerAbility(p2, p1);
            }
          }
        }

        // 3. Physics update: Friction, Max Speed & Movement
        [p1, p2].forEach(f => {
          // Friction & damping
          f.vx *= 0.985;
          f.vy *= 0.985;

          // Cap maximum velocity
          const curSpeed = Math.hypot(f.vx, f.vy);
          // Мастери Lighting: +1.75x скорости при включённой мастери и во время Speed GOD.
          const lightningSpeed = f.character.id === 'lighting_secret' && lightingMasteryUnlocked && enableLightingMastery ? 1.75 : 1;
          const godBoost = speedGodRef.current.active && f.id === 'player' ? 50 : 1;
          const maxSpd = (f.character.baseSpeed + (f.character.speedBonus || 0) * 0.1) * (f.character.speedMultiplier || 1) * lightningSpeed * godBoost * (f.speedBoostTimer > 0 ? 2.0 : 1.4);
          if (curSpeed > maxSpd * 2.2) {
            f.vx = (f.vx / curSpeed) * maxSpd * 2.2;
            f.vy = (f.vy / curSpeed) * maxSpd * 2.2;
          }

          // Apply velocity
          f.x += f.vx;
          f.y += f.vy;

          // Накопление дистанции для мастери Lighting (10 км суммарно) по игроку.
          if (f.id === 'player' && !lastPosRef.current) lastPosRef.current = { x: f.x, y: f.y };
          if (f.id === 'player' && lastPosRef.current) {
            const moved = Math.hypot(f.x - lastPosRef.current.x, f.y - lastPosRef.current.y);
            if (moved > 1) masteryDocRef.current.distance += moved;
            lastPosRef.current = { x: f.x, y: f.y };
          }

          // Персональные следы движения для проработанных моделей.
          if (f.character.id === 'lighting_secret' && curSpeed > 1.5 && Math.random() < 0.75) {
            createParticles(
              f.x - f.vx * 1.8 + (Math.random() - 0.5) * f.radius,
              f.y - f.vy * 1.8 + (Math.random() - 0.5) * f.radius,
              Math.random() > 0.35 ? '#67e8f9' : '#fef08a',
              2,
              'spark',
              1.7
            );
          } else if (f.character.id === 'glitch_secret' && curSpeed > 1 && Math.random() < 0.45) {
            createParticles(f.x - f.vx, f.y - f.vy, Math.random() > 0.5 ? '#00f5ff' : '#ff1478', 2, 'spark', 0.8);
          } else if (f.character.id === 'ender_dragon' && curSpeed > 1 && Math.random() < 0.3) {
            createParticles(f.x - Math.cos(f.angle) * f.radius * 2, f.y - Math.sin(f.angle) * f.radius * 2, '#d946ef', 2, 'spark', 0.7);
          }

          // Rotate weapons & facing angle
          f.weaponAngle += 0.06;
          f.angle = Math.atan2(f.vy, f.vx);

          // Update timers
          if (f.freezeTimer > 0) f.freezeTimer = Math.max(0, f.freezeTimer - dt);
          if (f.invulnerableTimer > 0) f.invulnerableTimer = Math.max(0, f.invulnerableTimer - dt);
          if (f.abilityCooldownTimer > 0) f.abilityCooldownTimer = Math.max(0, f.abilityCooldownTimer - dt);
          if (f.speedBoostTimer > 0) f.speedBoostTimer = Math.max(0, f.speedBoostTimer - dt);
          if (f.spikesBuffTimer > 0) {
            f.spikesBuffTimer = Math.max(0, f.spikesBuffTimer - dt);
            if (f.spikesBuffTimer === 0) f.hasSpikesBuff = false;
          }
          if (f.isTransformed && f.abilityActiveTimer > 0) {
            f.abilityActiveTimer = Math.max(0, f.abilityActiveTimer - dt);
            if (f.abilityActiveTimer === 0) {
              f.isTransformed = false;
              f.radius /= 1.4;
            }
          }
        });

        // Мастери hahaha: живой в раунде -> копим секунды (квест 2).
        if (p1.hp > 0) masteryDocRef.current.survived += dt;

        // Speed GOD (мастери LIGHTING GOD): время стоит, игрок бесконечно рикошетит от стен на x50.
        if (speedGodRef.current.active) {
          speedGodRef.current.left = Math.max(0, speedGodRef.current.left - dt);
          // Время «заморожено» для противника, пока длится Speed GOD.
          p2.freezeTimer = Math.max(p2.freezeTimer, 0.25);
          p2.vx *= 0.2;
          p2.vy *= 0.2;
          // Держим бешеную скорость: если игрок замедлился — снова разгоняем.
          const sp = Math.hypot(p1.vx, p1.vy);
          const wanted = 46;
          if (sp < wanted) {
            const a = sp > 0.4 ? Math.atan2(p1.vy, p1.vx) : Math.random() * Math.PI * 2;
            p1.vx = Math.cos(a) * wanted;
            p1.vy = Math.sin(a) * wanted;
          }
          p1.invulnerableTimer = Math.max(p1.invulnerableTimer, 0.1);
          createParticles(p1.x, p1.y, Math.random() > 0.5 ? '#67e8f9' : '#fef08a', 3, 'spark', 2.4);
          if (speedGodRef.current.left <= 0) {
            speedGodRef.current.active = false;
            addFloatingText(p1.x, p1.y - 40, 'SPEED GOD ЗАВЕРШЁН', '#67e8f9', 20);
          }
        }

        // STELLAR: звездопад — много слабых звёзд сверху в течение 10 секунд.
        if (starfallRef.current) {
          const sf = starfallRef.current;
          sf.left -= dt;
          sf.spawn -= dt;
          const caster = sf.owner === 'player' ? p1 : p2;
          const victim = sf.owner === 'player' ? p2 : p1;
          if (sf.spawn <= 0) {
            sf.spawn = 0.12;
            const cw = canvas.width;
            for (let i = 0; i < 2; i++) {
              const sx = Math.random() * cw;
              projectilesRef.current.push({
                id: Math.random().toString(), owner: caster.id,
                x: sx, y: -20 - Math.random() * 60,
                vx: (Math.random() - 0.5) * 1.5, vy: 7 + Math.random() * 4,
                radius: 7, damage: 1,
                color: Math.random() > 0.5 ? '#ffe9a8' : '#a5b4ff', glowColor: '#ffffff',
                life: 0, maxLife: 150, type: 'star' as never,
              });
            }
            createParticles(victim.x + (Math.random() - 0.5) * 120, 20, '#ffe9a8', 2, 'star', 1.2);
          }
          if (sf.left <= 0) starfallRef.current = null;
        }

        // 3.5 ПАССИВКИ И МЕХАНИКИ: ULTRAKILL, God, Error, Flex
        {
          const st = passiveRef.current;
          if (!st.init) {
            st.init = true;
            st.hp = { player: p1.hp, bot: p2.hp, p2: p2.hp };
            st.dmg = { player: p1.damageDealt, bot: p2.damageDealt, p2: p2.damageDealt };
          }

          [p1, p2].forEach(f => {
            const key = f.id;
            const prevHp = st.hp[key] ?? f.hp;
            const prevDmg = st.dmg[key] ?? f.damageDealt;
            const lost = prevHp - f.hp;
            const dealt = f.damageDealt - prevDmg;

            // ERROR: Exception Handled — 20% шанс полностью отменить входящий урон.
            if (lost > 0 && f.character.id === 'error' && Math.random() < 0.2) {
              f.hp = prevHp;
              addFloatingText(f.x, f.y - 30, 'EXCEPTION HANDLED', '#ef4444', 18);
              createParticles(f.x, f.y, '#ef4444', 14, 'ring', 1.4);
            }

            // FLEX: каждое попадание наращивает урон на +10%.
            if (dealt > 0 && f.character.id === 'flex') {
              f.damageMultiplier = Math.min(2.5, (f.damageMultiplier || 1) + 0.1);
            }

            // GOD: регенерация 1 HP каждые 6 секунд.
            if (f.character.id === 'god') {
              st.godRegen[key] = (st.godRegen[key] || 0) + dt;
              if (st.godRegen[key] >= 6) {
                st.godRegen[key] = 0;
                if (f.hp > 0 && f.hp < f.maxHp) {
                  f.hp = Math.min(f.maxHp, f.hp + 1);
                  addFloatingText(f.x, f.y - 32, '+1 БОЖЕСТВЕННАЯ РЕГЕНЕРАЦИЯ', '#fef08a', 16);
                }
              }
            }

            // ULTRAKILL: щит на 1 HP, шкала ярости и дробное здоровье.
            if (f.character.id === 'ultrakill') {
              const u = ultraRef.current;
              u.charge = Math.min(100, u.charge + dealt * 7 + Math.max(0, lost) * 9);

              const currentLost = prevHp - f.hp;
              if (currentLost > 0) {
                if (u.shieldHp > 0) {
                  // Щит поглощает удар целиком.
                  u.shieldHp -= 1;
                  f.hp = prevHp;
                  addFloatingText(f.x, f.y - 30, `ЩИТ ${u.shieldHp}/5`, '#7dd3fc', 18);
                  createParticles(f.x, f.y, '#38bdf8', 16, 'ring', 1.5);
                } else if (u.awakened && prevHp <= 1) {
                  // Дробная лестница здоровья после пробуждения.
                  const ladder = [0.9, 0.7, 0.5, 0.3, 0.1, 0.01, 0];
                  const next = ladder.find(v => v < prevHp - 0.0001);
                  f.hp = next === undefined ? 0 : next;
                  if (f.hp > 0) {
                    addFloatingText(f.x, f.y - 34, `${f.hp} HP`, '#f472b6', 22);
                    createParticles(f.x, f.y, '#f472b6', 18, 'spark', 1.6);
                  }
                }
              }

              // Автощит на последнем здоровье (сбалансированная прочность 4-6).
              if (f.hp > 0 && f.hp <= 1 && u.shieldHp <= 0 && !u.shieldSpent) {
                u.shieldSpent = true;
                u.shieldHp = 4 + Math.floor(Math.random() * 3);
                f.hasShield = false;
                addFloatingText(f.x, f.y - 44, `АВАРИЙНЫЙ ЩИТ ${u.shieldHp}!`, '#38bdf8', 22);
                createParticles(f.x, f.y, '#38bdf8', 30, 'ring', 2.2);
              }

              if (f.id === 'player') {
                setUltraHud(prev =>
                  prev.charge === Math.floor(u.charge) && prev.awakened === u.awakened && prev.shield === u.shieldHp
                    ? prev
                    : { charge: Math.floor(u.charge), awakened: u.awakened, shield: u.shieldHp }
                );
              }
            }

            st.hp[key] = f.hp;
            st.dmg[key] = f.damageDealt;
          });
        }

        // 4. Arena Boundary Wall Collisions & Elastic Bounces
        [p1, p2].forEach(f => {
          // Mega-giants (leviathans) are intentionally bigger than the arena — they overflow off-card.
          // We cap the effective collision radius so they still bounce naturally instead of getting stuck.
          const maxAllowed = Math.min(currentArenaSize.current.width, currentArenaSize.current.height) * 0.42;
          const r = Math.min(f.radius, maxAllowed);
          let bounced = false;

          if (f.x - r < arenaLeft) {
            f.x = arenaLeft + r;
            f.vx = Math.abs(f.vx) * 0.9 + 1;
            bounced = true;
          } else if (f.x + r > arenaRight) {
            f.x = arenaRight - r;
            f.vx = -Math.abs(f.vx) * 0.9 - 1;
            bounced = true;
          }

          if (f.y - r < arenaTop) {
            f.y = arenaTop + r;
            f.vy = Math.abs(f.vy) * 0.9 + 1;
            bounced = true;
          } else if (f.y + r > arenaBottom) {
            f.y = arenaBottom - r;
            f.vy = -Math.abs(f.vy) * 0.9 - 1;
            bounced = true;
          }

          if (bounced) {
            createParticles(f.x, f.y, f.character.glowColor, 5, 'spark');
            soundManager.playBounce(f.character.weight);
          }
        });

        // 5. Weapon & Body Collision Detection between Fighters
        const fDistX = p2.x - p1.x;
        const fDistY = p2.y - p1.y;
        const fDist = Math.hypot(fDistX, fDistY) || 1;

        // Calculate weapon hitboxes for P1
        const p1Weapons = (p1.character.weaponCount || 1);
        const p1Reach = p1.radius + (p1.character.weaponReach || 30);
        const p2Weapons = (p2.character.weaponCount || 1);
        const p2Reach = p2.radius + (p2.character.weaponReach || 30);

        let p1HitP2 = false;
        let p2HitP1 = false;

        // Check P1 weapons hitting P2
        for (let i = 0; i < p1Weapons; i++) {
          const wAngle = p1.weaponAngle + (i * Math.PI * 2) / p1Weapons;
          const wx = p1.x + Math.cos(wAngle) * p1Reach;
          const wy = p1.y + Math.sin(wAngle) * p1Reach;
          if (Math.hypot(p2.x - wx, p2.y - wy) < p2.radius + 8) {
            p1HitP2 = true;
            break;
          }
        }

        // Check P2 weapons hitting P1
        for (let i = 0; i < p2Weapons; i++) {
          const wAngle = p2.weaponAngle + (i * Math.PI * 2) / p2Weapons;
          const wx = p2.x + Math.cos(wAngle) * p2Reach;
          const wy = p2.y + Math.sin(wAngle) * p2Reach;
          if (Math.hypot(p1.x - wx, p1.y - wy) < p1.radius + 8) {
            p2HitP1 = true;
            break;
          }
        }

        // Direct body clash
        if (fDist < p1.radius + p2.radius) {
          p1HitP2 = true;
          p2HitP1 = true;
          // Separate overlapping circles
          const overlap = (p1.radius + p2.radius) - fDist;
          const nx = fDistX / fDist;
          const ny = fDistY / fDist;
          p1.x -= nx * overlap * 0.5;
          p1.y -= ny * overlap * 0.5;
          p2.x += nx * overlap * 0.5;
          p2.y += ny * overlap * 0.5;
        }

        // Handle P1 hitting P2
        if (p1HitP2 && p2.invulnerableTimer <= 0) {
          // Sans 30% dodge check
          if (p2.character.id === 'sans' && Math.random() < 0.3) {
            p2.x += (Math.random() - 0.5) * 80;
            p2.y += (Math.random() - 0.5) * 80;
            p2.invulnerableTimer = 0.3;
            addFloatingText(p2.x, p2.y - 20, 'MISS!', '#38bdf8', 20);
          } else {
            let dmg = p1.hasSpikesBuff ? 2 : 1;
            if (p1.character.id === 'overkill_glove' || p1.character.id === 'final') dmg = 3; // FINAL вне кругов уже тяжёлый
            // Speed GOD: касание при скорости x50 наносит 0.75 урона.
            if (speedGodRef.current.active && p1.id === 'player') dmg = 0.75;
            else dmg = Math.max(1, Math.round(dmg * (p1.damageMultiplier || 1)));
            // Мастери Lighting: +1.5x урона от героя (если включена).
            if (p1.character.id === 'lighting_secret' && lightingMasteryUnlocked && enableLightingMastery) dmg = Math.max(1, Math.round(dmg * 1.5));
            if (gameMode === 'boss_raid') dmg *= raidDamageBonus(p2.character.id);

            if (p2.hasShield) {
              p2.hasShield = false;
              addFloatingText(p2.x, p2.y - 20, 'ЩИТ СЛОМАН!', '#38bdf8', 18);
              createParticles(p2.x, p2.y, '#38bdf8', 15, 'ring');
              soundManager.playHit(false);
            } else {
              p2.hp = Math.max(0, p2.hp - dmg);
              p2.invulnerableTimer = 0.25;
              p1.hitsDealt++;
              p1.damageDealt += dmg;
              addFloatingText(p2.x, p2.y - 20, `-${dmg}`, '#ef4444', 22);
              createParticles(p2.x, p2.y, '#ef4444', 12, 'spark');
              soundManager.playHit(true);

              // Charge Robot User transformation meter
              if (p1.character.id === 'robot_user' && !p1.isTransformed) {
                p1.transformationMeter = Math.min(100, p1.transformationMeter + 25);
                setPlayerTransMeter(p1.transformationMeter);
                if (p1.transformationMeter >= 100) {
                  triggerAbility(p1, p2);
                  p1.transformationMeter = 0;
                }
              }
            }

            // Knockback impulse
            const kf = p1.character.knockbackForce || 1.5;
            p2.vx += (fDistX / fDist) * 7 * kf;
            p2.vy += (fDistY / fDist) * 7 * kf;
            p1.vx -= (fDistX / fDist) * 4;
            p1.vy -= (fDistY / fDist) * 4;

            if (settings.screenShake) screenShakeRef.current = 8;
          }
        }

        // Handle P2 hitting P1
        if (p2HitP1 && p1.invulnerableTimer <= 0) {
          if (p1.character.id === 'sans' && Math.random() < 0.3) {
            p1.x += (Math.random() - 0.5) * 80;
            p1.y += (Math.random() - 0.5) * 80;
            p1.invulnerableTimer = 0.3;
            addFloatingText(p1.x, p1.y - 20, 'MISS!', '#38bdf8', 20);
          } else {
            let dmg = p2.hasSpikesBuff ? 2 : 1;
            if (p2.character.id === 'overkill_glove') dmg = 3;
            dmg = Math.max(1, Math.round(dmg * (p2.damageMultiplier || 1)));

            if (p1.hasShield) {
              p1.hasShield = false;
              addFloatingText(p1.x, p1.y - 20, 'ЩИТ СЛОМАН!', '#38bdf8', 18);
              createParticles(p1.x, p1.y, '#38bdf8', 15, 'ring');
              soundManager.playHit(false);
            } else {
              p1.hp = Math.max(0, p1.hp - dmg);
              p1.invulnerableTimer = 0.25;
              addFloatingText(p1.x, p1.y - 20, `-${dmg}`, '#ef4444', 22);
              createParticles(p1.x, p1.y, '#ef4444', 12, 'spark');
              soundManager.playHit(true);
            }

            const kf = p2.character.knockbackForce || 1.5;
            p1.vx -= (fDistX / fDist) * 7 * kf;
            p1.vy -= (fDistY / fDist) * 7 * kf;
            p2.vx += (fDistX / fDist) * 4;
            p2.vy += (fDistY / fDist) * 4;

            if (settings.screenShake) screenShakeRef.current = 8;
          }
        }

        // 6. Projectiles update & collision (включая спирали, Синий/Красный Годжо, возвраты FINAL)
        const ownerOf = (proj: Projectile) => (proj.owner === 'player' ? p1 : p2);
        const cipherTypes = ['gojo_blue', 'gojo_red', 'hollow_purple', 'spiral'];

        projectilesRef.current.forEach((proj) => {
          // Clock Man замораживает все чужие снаряды вместе со временем.
          if (timeStopRef.current && proj.owner !== timeStopRef.current.owner) return;
          proj.life++;

          // Задержка вылета (круги FINAL стартуют по очереди)
          if (proj.delay && proj.delay > 0) {
            proj.delay -= 1;
            return;
          }

          const target = proj.owner === 'player' ? p2 : p1;
          const owner = ownerOf(proj);

          // ---- СПЕЦИАЛЬНЫЕ ТИПЫ ----
          if (proj.type === 'spiral') {
            // Радужная спираль-мертвая метка вокруг владельца
            proj.spiralDist = (proj.spiralDist || 10) + 2.4;
            proj.spiralAngle = (proj.spiralAngle || 0) + 0.13;
            proj.x = owner.x + Math.cos(proj.spiralAngle) * proj.spiralDist;
            proj.y = owner.y + Math.sin(proj.spiralAngle) * proj.spiralDist;
          } else if (proj.type === 'gojo_blue') {
            // СИНИЙ: медленно краёт орбиту вокруг арены, ВБИРАЕТ врага даже за её пределами
            const cx = (arenaLeft + arenaRight) / 2;
            const cy = (arenaTop + arenaBottom) / 2;
            const orbitR = Math.min(arenaRight - arenaLeft, arenaBottom - arenaTop) * 0.46 + Math.sin(proj.life * 0.05) * 26;
            proj.orbitAngle = (proj.orbitAngle || 0) + 0.021;
            proj.x = cx + Math.cos(proj.orbitAngle) * orbitR;
            proj.y = cy + Math.sin(proj.orbitAngle) * orbitR;
            // Притяжение цели
            const pdx = proj.x - target.x;
            const pdy = proj.y - target.y;
            const pdd = Math.hypot(pdx, pdy) || 1;
            target.vx += (pdx / pdd) * 0.55;
            target.vy += (pdy / pdd) * 0.55;
            if (pdd < 130) {
              proj.drainAcc = (proj.drainAcc || 0) + dt;
              createParticles(proj.x, proj.y, '#60a5fa', 1, 'spark');
              if (proj.drainAcc >= 0.55) {
                proj.drainAcc = 0;
                target.hp = Math.max(0, target.hp - 1);
                addFloatingText(target.x, target.y - 26, '-1 СИНИЙ', '#60a5fa', 18);
                soundManager.playHit(false);
              }
            }
          } else if (proj.type === 'gojo_red') {
            // КРАСНЫЙ: стоячий красный круг вбирает и взрывается
            const pdx = proj.x - target.x;
            const pdy = proj.y - target.y;
            const pdd = Math.hypot(pdx, pdy) || 1;
            if (pdd < 260) {
              target.vx += (pdx / pdd) * 0.9;
              target.vy += (pdy / pdd) * 0.9;
            }
          } else {
            // Ѕбычное прямолинейное движение + возвраты к кастеру (круги FINAL)
            proj.x += proj.vx;
            proj.y += proj.vy;

            if (proj.homing) {
              const tdx = target.x - proj.x;
              const tdy = target.y - proj.y;
              const td = Math.hypot(tdx, tdy) || 1;
              proj.vx += (tdx / td) * 0.4;
              proj.vy += (tdy / td) * 0.4;
            }

            // Возврат к хозяину (Семеричный приговор)
            if (proj.returnAt && proj.life > proj.returnAt) {
              const o = owner;
              const odx = o.x - proj.x;
              const ody = o.y - proj.y;
              const odd = Math.hypot(odx, ody) || 1;
              proj.vx = (odx / odd) * 13;
              proj.vy = (ody / odd) * 13;
              proj.homing = false;
              if (odd < owner.radius + 14) {
                proj.life = proj.maxLife; // вернулся — вливается обратно
              }
            }
          }

          // Урон по цели (кроме gojo_blue — он периодически терзает сам; gojo_red бьёт только взрывом)
          const canHit = proj.type !== 'gojo_blue' && proj.type !== 'gojo_red';
          if (canHit && Math.hypot(target.x - proj.x, target.y - proj.y) < target.radius + proj.radius) {
            if (target.invulnerableTimer <= 0) {
              if (target.hasShield && !proj.piercing) {
                target.hasShield = false;
                addFloatingText(target.x, target.y - 20, 'ЩИТ!', '#38bdf8');
              } else {
                let srcDmg = Math.max(1, Math.round(proj.damage * (owner.damageMultiplier || 1)));
                if (gameMode === 'boss_raid' && owner.id === 'player' && target.id !== 'player') srcDmg *= raidDamageBonus(target.character.id);
                target.hp = Math.max(0, target.hp - srcDmg);
                addFloatingText(target.x, target.y - 20, `-${srcDmg}`, proj.color, 20);
                createParticles(target.x, target.y, proj.color, 12, 'spark');
                soundManager.playHit(proj.type === 'hollow_purple');
                if (proj.type === 'hollow_purple') target.invulnerableTimer = 0.7;
              }
            }
            if (!proj.piercing) {
              proj.life = proj.maxLife;
            }
          }

          // Стены: особые типы (круги FINAL, Годжо) игнорируют границы — мир шире арены.
          // СНАРЯДЫ С returnAt (Семеричный приговор) всегда свободно вылетают за карту и возвращаются.
          const noWalls = cipherTypes.includes(proj.type) || (proj.returnAt && proj.returnAt > 0);
          const offA = proj.x < arenaLeft || proj.x > arenaRight || proj.y < arenaTop || proj.y > arenaBottom;
          if (offA && !noWalls) {
            if (proj.piercing) {
              proj.life = proj.maxLife;
            } else {
              proj.vx = -proj.vx;
              proj.vy = -proj.vy;
            }
          }
          // Hollow Purple бесследно исчезает далеко за экраном
          if (proj.type === 'hollow_purple') {
            const margin = 160;
            if (proj.x < -margin || proj.x > canvas.width + margin || proj.y < -margin || proj.y > canvas.height + margin) {
              proj.life = proj.maxLife;
            }
          }
          // СИНИЙ завершается — возвращаем захваченную цель туда, откуда её вырвали
          if (proj.type === 'gojo_blue' && proj.life >= proj.maxLife - 1 && proj.captureX !== undefined && proj.captureY !== undefined) {
            createParticles(target.x, target.y, '#60a5fa', 18, 'ring', 2);
            target.x = proj.captureX;
            target.y = proj.captureY;
            target.vx = 0;
            target.vy = 0;
            target.freezeTimer = Math.max(target.freezeTimer, 0.35);
            createParticles(target.x, target.y, '#93c5fd', 18, 'spark');
            addFloatingText(target.x, target.y - 28, 'ВОЗВРАЩЁН', '#60a5fa', 16);
          }
          // КРАСНЫЙ завершается взрывом (также при прямом касании цели)
          if (proj.type === 'gojo_red' && proj.life < proj.maxLife - 1 && Math.hypot(target.x - proj.x, target.y - proj.y) < target.radius + proj.radius) {
            proj.life = proj.maxLife - 1; // форсируем взрыв в этом кадре
          }
          if (proj.type === 'gojo_red' && proj.life >= proj.maxLife - 1) {
            const pdd = Math.hypot(target.x - proj.x, target.y - proj.y) || 1;
            if (pdd < 200) {
              let dmg = Math.max(1, Math.round(proj.damage * (owner.damageMultiplier || 1)));
              if (gameMode === 'boss_raid' && owner.id === 'player' && target.id !== 'player') dmg *= raidDamageBonus(target.character.id);
              target.hp = Math.max(0, target.hp - dmg);
              target.vx += ((target.x - proj.x) / pdd) * 11;
              target.vy += ((target.y - proj.y) / pdd) * 11;
              addFloatingText(target.x, target.y - 26, `-${dmg} ВЗРЫВ!`, '#f87171', 22);
            }
            createParticles(proj.x, proj.y, '#f87171', 32, 'ring', 2.0);
            createParticles(proj.x, proj.y, '#ef4444', 20, 'spark', 2.0);
            soundManager.playHit(true);
          }
        });
        projectilesRef.current = projectilesRef.current.filter(p => p.life < p.maxLife);

        // 7. Power-Up Orbs: Standard и Boss Raid (в рейде помогают пережить длинный бой).
        if (gameMode === 'standard' || gameMode === 'boss_raid') {
          orbSpawnTimerRef.current += dt;
          const orbDelay = gameMode === 'boss_raid' ? 5.5 : 8;
          if (orbSpawnTimerRef.current > orbDelay && orbsRef.current.length < 2) {
            orbSpawnTimerRef.current = 0;
            const types: Array<'spike_armor' | 'energy_shield' | 'speed_boost' | 'heal'> = [
              'spike_armor',
              'energy_shield',
              'speed_boost',
              'heal'
            ];
            const chosenType = types[Math.floor(Math.random() * types.length)];
            orbsRef.current.push({
              id: Math.random().toString(),
              x: arenaLeft + 80 + Math.random() * (currentArenaSize.current.width - 160),
              y: arenaTop + 80 + Math.random() * (currentArenaSize.current.height - 160),
              radius: 16,
              type: chosenType,
              duration: 15,
              pulseTimer: 0
            });
          }

          // Check collection by fighters
          orbsRef.current.forEach((orb, oIdx) => {
            orb.pulseTimer += 0.05;
            [p1, p2].forEach(f => {
              if (Math.hypot(f.x - orb.x, f.y - orb.y) < f.radius + orb.radius) {
                // Apply orb effect
                soundManager.playPowerup();
                if (orb.type === 'spike_armor') {
                  f.hasSpikesBuff = true;
                  f.spikesBuffTimer = 6.0;
                  addFloatingText(f.x, f.y - 25, '+ШИПЫ!', '#ef4444', 20);
                } else if (orb.type === 'energy_shield') {
                  f.hasShield = true;
                  addFloatingText(f.x, f.y - 25, '+ЩИТ!', '#38bdf8', 20);
                } else if (orb.type === 'speed_boost') {
                  f.speedBoostTimer = 5.0;
                  addFloatingText(f.x, f.y - 25, '+СКОРОСТЬ!', '#fbbf24', 20);
                } else if (orb.type === 'heal') {
                  f.hp = Math.min(f.maxHp, f.hp + 1);
                  addFloatingText(f.x, f.y - 25, '+1 HP!', '#22c55e', 20);
                }
                createParticles(orb.x, orb.y, '#ffffff', 14, 'ring');
                orbsRef.current.splice(oIdx, 1);
              }
            });
          });
        }

        // 8. Update HUD states
        setPlayerHp(p1.hp);
        setBotHp(p2.hp);
        setPlayerCooldown(Math.ceil(p1.abilityCooldownTimer));
        // Циклические способности: показываем СЛЕДУЮЩУЮ в цепочке
        const p1List = abilityListFor(p1);
        if (p1List.length > 0) {
          const next = p1List[(p1.abilitySlot ?? 0) % p1List.length];
          if (next.nameRu !== playerAbilityName) setPlayerAbilityName(next.nameRu);
        }
        if (gameMode === 'two_player') {
          setP2Cooldown(Math.ceil(p2.abilityCooldownTimer));
          const p2List = abilityListFor(p2);
          if (p2List.length > 0) {
            const next2 = p2List[(p2.abilitySlot ?? 0) % p2List.length];
            if (next2.nameRu !== p2AbilityName) setP2AbilityName(next2.nameRu);
          }
        }
        setPlayerBuffs({
          hasShield: p1.hasShield,
          hasSpikes: p1.hasSpikesBuff,
          speedBoost: p1.speedBoostTimer > 0
        });
        // Палитра способностей: все доступные техники на экране, а не одна случайная.
        {
          const map = abilityOptionsFor(p1);
          let changed = palette.length !== map.length;
          if (!changed) for (let i = 0; i < map.length; i++) if (map[i].key !== palette[i]?.key) { changed = true; break; }
          if (changed) setPalette(map.map(m => ({ key: m.key, name: m.name, cd: m.cd, locked: m.locked, color: m.color })));
        }

        // 8.5 ENDLESS: бот умирает — следующий челленджер появляется немедленно!
        if (!matchEndedRef.current && gameMode === 'endless' && p2.hp <= 0) {
          p1.kills++;
          // Квест мастери Lighting: 100 убийств суммарно.
          masteryDocRef.current.kills++;
          endlessRef.current.kills++;
          endlessRef.current.wave++;
          setEndlessHud({ kills: endlessRef.current.kills, wave: endlessRef.current.wave });

          // Лечение в зависимости от подрежима
          if (endlessSubmode === 'standard') {
            p1.hp = Math.min(p1.maxHp, p1.hp + 2);
            addFloatingText(p1.x, p1.y - 34, '+2 HP', '#22c55e', 20);
          } else if (endlessSubmode === 'duo') {
            p1.hp = Math.min(p1.maxHp, p1.hp + 1);
            addFloatingText(p1.x, p1.y - 34, '+1 HP', '#22c55e', 18);
            // Дуо: теневая жижа преследует тебя 12 секунд
            for (let s = 0; s < 2; s++) {
              projectilesRef.current.push({
                id: Math.random().toString(),
                owner: 'bot',
                x: p2.x + (Math.random() - 0.5) * 90,
                y: p2.y + (Math.random() - 0.5) * 90,
                vx: (Math.random() - 0.5) * 4,
                vy: (Math.random() - 0.5) * 4,
                radius: 9,
                damage: 1,
                color: '#f43f5e',
                glowColor: '#f43f5e',
                life: 0,
                maxLife: 360,
                type: 'shade',
                homing: true
              });
            }
          } else {
            addFloatingText(p1.x, p1.y - 34, 'LAST STAND: без лечения!', '#fbbf24', 18);
          }

          bannerRef.current = { text: `ВОЛНА ${endlessRef.current.wave} — НОВЫЙ ПРОТИВНИК!`, color: '#fbbf24', t: 1.2 };
          createParticles(p2.x, p2.y, '#f43f5e', 34, 'spark');

          // Новый случайный противник, прокачанный по волне
          // SECRET никогда не появляется случайно в Endless, пока остаётся тайной.
          const pool = ALL_CHARACTERS.filter(c => c.id !== 'coming_soon' && c.rarity !== 'secret');
          const nextBase = pool[Math.floor(Math.random() * pool.length)] || ALL_CHARACTERS[2];
          const scaledHp = nextBase.maxHp + Math.floor(endlessRef.current.wave / 3);
          const corner = Math.floor(Math.random() * 4);
          const nx = corner % 2 === 0 ? arenaLeft + 90 : arenaRight - 90;
          const ny = corner < 2 ? arenaTop + 90 : arenaBottom - 90;
          // МУТИРУЕМ существующий объект p2 (а не заменяем) — иначе в этом же кадре
          // старая ссылка p2 с hp=0 сразу завершала матч ("1 волна всего").
          p2.character = { ...nextBase, ability: { ...nextBase.ability }, maxHp: scaledHp } as Character;
          p2.x = nx;
          p2.y = ny;
          p2.vx = (Math.random() - 0.5) * 5;
          p2.vy = (Math.random() - 0.5) * 5;
          p2.radius = 32 * (nextBase.isGiant ? nextBase.giantMultiplier || 1.5 : 1.0);
          p2.hp = scaledHp;
          p2.maxHp = scaledHp;
          p2.freezeTimer = 0.8;
          p2.invulnerableTimer = 1.0;
          p2.abilityCooldownTimer = 2.0;
          p2.abilitySlot = 0;
          p2.secondLifeUsed = false;
          p2.sugarokForm = false;
          p2.finalCircles = false;
          p2.damageMultiplier = 1;
          p2.isTransformed = false;
          p2.transformationMeter = 0;
          p2.hasShield = false;
          p2.hasSpikesBuff = false;
          // Убираем снаряды бывшего противника (кроме теней Дуо)
          projectilesRef.current = projectilesRef.current.filter(pr => pr.owner !== 'bot' || pr.type === 'shade');
          setBotHp(scaledHp);
          setBotMaxHp(scaledHp);
          soundManager.playDefeat();
        }

        // 9. Match Finish condition check — с проверкой ВТОРОЙ ЖИЗНИ (Артём -> САХАРОК!)
        if (!matchEndedRef.current) {
          if (p1.hp <= 0 || p2.hp <= 0) {
            const dying = p1.hp <= 0 ? p1 : p2;
            const other = p1.hp <= 0 ? p2 : p1;
            if (dying.character.id === 'ultrakill' && ultraRef.current.death === null) {
              // ULTRAKILL умирает особой сценой стирания.
              ultraRef.current.death = 0;
              other.freezeTimer = Math.max(other.freezeTimer, 1);
              soundManager.playDefeat();
            } else if (dying.character.secondLife && !dying.secondLifeUsed) {
              // СТОП ВРЕМЯ! Запускаем ритуал распада и возрождения Сахарком
              dying.secondLifeUsed = true;
              dying.hp = 1; // выживает на ниточке до конца ритуала
              dying.invulnerableTimer = 3.4;
              other.freezeTimer = Math.max(other.freezeTimer, 0.5);
              secondLifeSeqRef.current = {
                t: 0,
                dying,
                origRadius: dying.radius,
                clothColor: dying.character.avatarColor
              };
              createParticles(dying.x, dying.y, '#fcd34d', 30, 'spark');
              soundManager.playAbility('jumpscare');
              if (settings.screenShake) screenShakeRef.current = 12;
            } else {
              matchEndedRef.current = true;
              const winner = p1.hp <= 0 ? (gameMode === 'two_player' ? 'p2' : 'bot') : 'player';
              // Победа = убийство для квестов мастери.
              if (winner === 'player') masteryDocRef.current.kills++;
              endTimeoutRef.current = setTimeout(() => {
                sendMasteryRef.current();
                reportMatchRef.current(winner, {
                  hits: p1.hitsDealt,
                  damage: p1.damageDealt,
                  kills: gameMode === 'endless' ? p1.kills : undefined,
                  duration: (performance.now() - matchStartRef.current) / 1000
                });
              }, 600);
            }
          }
        }
      }

      // ================= DRAWING PASS =================
      ctx.save();
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Screen Shake
      if (screenShakeRef.current > 0) {
        const sx = (Math.random() - 0.5) * screenShakeRef.current;
        const sy = (Math.random() - 0.5) * screenShakeRef.current;
        ctx.translate(sx, sy);
        screenShakeRef.current = Math.max(0, screenShakeRef.current - 0.8);
      }

      const aW = currentArenaSize.current.width;
      const aH = currentArenaSize.current.height;
      const aL = (canvas.width - aW) / 2;
      const aT = (canvas.height - aH) / 2;

      // ===== КАМЕРА: если арена больше экрана (Гаргантюа), следуем за игроком =====
      {
        const focus = fighter1Ref.current;
        let targetX = 0;
        let targetY = 0;
        if (focus) {
          if (aW > canvas.width) {
            targetX = Math.min(Math.max(focus.x - canvas.width / 2, aL), aL + aW - canvas.width);
          }
          if (aH > canvas.height) {
            targetY = Math.min(Math.max(focus.y - canvas.height / 2, aT), aT + aH - canvas.height);
          }
        }
        cameraRef.current.x += (targetX - cameraRef.current.x) * 0.12;
        cameraRef.current.y += (targetY - cameraRef.current.y) * 0.12;
      }
      // Весь мир рисуется со смещением камеры; HUD-оверлеи — уже без него.
      ctx.save();
      ctx.translate(-cameraRef.current.x, -cameraRef.current.y);

      // Draw Arena Floor Background & Grid
      ctx.fillStyle = '#090d16';
      ctx.fillRect(aL, aT, aW, aH);

      // Разрезы арены после КОРОЛЕВСКОГО РАЗРЕЗА: арена остаётся рассечённой.
      if (arenaCutsRef.current.length) {
        ctx.save();
        ctx.beginPath();
        ctx.rect(aL, aT, aW, aH);
        ctx.clip();
        for (const cut of arenaCutsRef.current) {
          const age = (performance.now() - cut.born) / 1000;
          ctx.save();
          ctx.translate(cut.x, cut.y);
          ctx.rotate(cut.a);
          // Тёмный провал.
          ctx.fillStyle = '#02040a';
          ctx.fillRect(-aW * 1.5, -8, aW * 3, 16);
          // Раскалённые кромки, остывающие со временем.
          const heat = Math.max(0.18, 1 - age / 6);
          ctx.strokeStyle = `rgba(255,122,69,${heat})`;
          ctx.shadowColor = '#ff5236';
          ctx.shadowBlur = 20 * heat;
          ctx.lineWidth = 2.5;
          ctx.beginPath();
          ctx.moveTo(-aW * 1.5, -9); ctx.lineTo(aW * 1.5, -9);
          ctx.moveTo(-aW * 1.5, 9); ctx.lineTo(aW * 1.5, 9);
          ctx.stroke();
          ctx.restore();
        }
        ctx.restore();
      }

      // Cyber Grid lines
      ctx.strokeStyle = '#1e293b';
      ctx.lineWidth = 1;
      const gridSize = 40;
      for (let x = aL; x <= aL + aW; x += gridSize) {
        ctx.beginPath();
        ctx.moveTo(x, aT);
        ctx.lineTo(x, aT + aH);
        ctx.stroke();
      }
      for (let y = aT; y <= aT + aH; y += gridSize) {
        ctx.beginPath();
        ctx.moveTo(aL, y);
        ctx.lineTo(aL + aW, y);
        ctx.stroke();
      }

      // Arena Center Circle & Logo
      ctx.strokeStyle = '#38bdf822';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(canvas.width / 2, canvas.height / 2, 70, 0, Math.PI * 2);
      ctx.stroke();

      // Arena Glowing Border
      ctx.strokeStyle = '#38bdf8';
      ctx.shadowColor = '#0284c7';
      ctx.shadowBlur = 15;
      ctx.lineWidth = 4;
      ctx.strokeRect(aL, aT, aW, aH);
      ctx.shadowBlur = 0; // reset

      // Draw Orbs
      orbsRef.current.forEach(orb => {
        const pulse = Math.sin(orb.pulseTimer * 3) * 3;
        const orbColor = orb.type === 'spike_armor' ? '#ef4444' : orb.type === 'energy_shield' ? '#38bdf8' : orb.type === 'speed_boost' ? '#fbbf24' : '#22c55e';
        ctx.save();
        ctx.fillStyle = orbColor;
        ctx.shadowColor = orbColor;
        ctx.shadowBlur = 15;
        ctx.beginPath();
        ctx.arc(orb.x, orb.y, orb.radius + pulse, 0, Math.PI * 2);
        ctx.fill();
        ctx.lineWidth = 2;
        ctx.strokeStyle = '#ffffff';
        ctx.stroke();

        // Icon text
        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 12px sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        const orbSymbol = orb.type === 'spike_armor' ? '⚔️' : orb.type === 'energy_shield' ? '🛡️' : orb.type === 'speed_boost' ? '⚡' : '❤️';
        ctx.fillText(orbSymbol, orb.x, orb.y);
        ctx.restore();
      });

      // Draw Projectiles (с неоновым шлейфом)
      projectilesRef.current.forEach(proj => {
        if (proj.delay && proj.delay > 0) return; // ждут своей очереди
        ctx.save();
        // Шлейф: 3 призрачных круга позади по траектории
        const speed = Math.hypot(proj.vx, proj.vy);
        if (speed > 3) {
          const bx = -proj.vx / speed;
          const by = -proj.vy / speed;
          for (let t = 1; t <= 3; t++) {
            ctx.globalAlpha = 0.34 - t * 0.1;
            ctx.fillStyle = proj.color;
            ctx.beginPath();
            ctx.arc(proj.x + bx * t * 11, proj.y + by * t * 11, proj.radius * (1 - t * 0.25), 0, Math.PI * 2);
            ctx.fill();
          }
          ctx.globalAlpha = 1;
        }
        ctx.fillStyle = proj.color;
        ctx.shadowColor = proj.glowColor;
        ctx.shadowBlur = proj.type === 'hollow_purple' ? 34 : 16;
        if (proj.type === 'bone') {
          // Настоящая кость: стержень и круглые суставы с двух концов.
          const a = Math.atan2(proj.vy, proj.vx);
          ctx.translate(proj.x, proj.y);
          ctx.rotate(a);
          ctx.fillStyle = '#f8fafc';
          ctx.fillRect(-proj.radius * 1.6, -proj.radius * 0.34, proj.radius * 3.2, proj.radius * 0.68);
          for (const sx of [-1, 1]) {
            ctx.beginPath();
            ctx.arc(sx * proj.radius * 1.55, -proj.radius * 0.34, proj.radius * 0.48, 0, Math.PI * 2);
            ctx.arc(sx * proj.radius * 1.55, proj.radius * 0.34, proj.radius * 0.48, 0, Math.PI * 2);
            ctx.fill();
          }
        } else if (proj.type === 'laser') {
          // Бластеры и молнии рисуются как яркие длинные лучи, а не маленькие шарики.
          const a = Math.atan2(proj.vy, proj.vx);
          ctx.translate(proj.x, proj.y);
          ctx.rotate(a);
          const beamLength = proj.radius * 5.2;
          const beam = ctx.createLinearGradient(-beamLength, 0, beamLength, 0);
          beam.addColorStop(0, 'transparent');
          beam.addColorStop(0.35, proj.color);
          beam.addColorStop(0.65, '#ffffff');
          beam.addColorStop(1, 'transparent');
          ctx.fillStyle = beam;
          ctx.fillRect(-beamLength, -proj.radius * 0.55, beamLength * 2, proj.radius * 1.1);
        } else if (proj.type === 'bsod') {
          ctx.fillRect(proj.x - proj.radius, proj.y - proj.radius * 0.65, proj.radius * 2, proj.radius * 1.3);
          ctx.strokeStyle = '#ffffffaa';
          ctx.lineWidth = 1.5;
          ctx.strokeRect(proj.x - proj.radius, proj.y - proj.radius * 0.65, proj.radius * 2, proj.radius * 1.3);
        } else {
          ctx.beginPath();
          ctx.arc(proj.x, proj.y, proj.radius, 0, Math.PI * 2);
          ctx.fill();
          // Ядро белого накала
          ctx.fillStyle = '#ffffffcc';
          ctx.beginPath();
          ctx.arc(proj.x, proj.y, proj.radius * 0.36, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.restore();
      });

      // Draw Fighters
      if (fighter1Ref.current && fighter2Ref.current) {
        const drawFinalCircles = (f: FighterEntity) => {
          if (!f.finalCircles) return;
          const baseAng = f.weaponAngle * 3.4;
          for (let i = 0; i < 7; i++) {
            const a = baseAng + (i * Math.PI * 2) / 7;
            const cx = f.x + Math.cos(a) * (f.radius * 1.72);
            const cy = f.y + Math.sin(a) * (f.radius * 1.72);
            const col = FINAL_CIRCLE_COLORS[i];
            ctx.save();
            // Ожерелье-связка между кругами
            const na = baseAng + ((i + 1) * Math.PI * 2) / 7;
            ctx.strokeStyle = col + '44';
            ctx.lineWidth = 1.5;
            ctx.beginPath();
            ctx.moveTo(cx, cy);
            ctx.lineTo(f.x + Math.cos(na) * (f.radius * 1.72), f.y + Math.sin(na) * (f.radius * 1.72));
            ctx.stroke();
            ctx.fillStyle = col;
            ctx.shadowColor = col;
            ctx.shadowBlur = 16;
            ctx.beginPath();
            ctx.arc(cx, cy, 11, 0, Math.PI * 2);
            ctx.fill();
            ctx.fillStyle = '#ffffff';
            ctx.beginPath();
            ctx.arc(cx, cy, 4, 0, Math.PI * 2);
            ctx.fill();
            ctx.restore();
          }
        };

        drawCharacterAvatar(
          ctx,
          fighter1Ref.current.character,
          fighter1Ref.current.x,
          fighter1Ref.current.y,
          fighter1Ref.current.radius,
          fighter1Ref.current.angle,
          fighter1Ref.current.weaponAngle,
          fighter1Ref.current
        );
        drawFinalCircles(fighter1Ref.current);

        drawCharacterAvatar(
          ctx,
          fighter2Ref.current.character,
          fighter2Ref.current.x,
          fighter2Ref.current.y,
          fighter2Ref.current.radius,
          fighter2Ref.current.angle,
          fighter2Ref.current.weaponAngle,
          fighter2Ref.current
        );
        drawFinalCircles(fighter2Ref.current);
      }

      // ===== ДОМЕН ГОДЖО: БЕСКОНЕЧНАЯ БЕЗДНА (большой купол вокруг цели) =====
      if (domainRef.current) {
        const d = domainRef.current;
        const domeR = 40 + (d.t / 4.2) * Math.max(aW, aH) * 0.9;
        ctx.save();
        // Затемнение вне домена
        ctx.fillStyle = 'rgba(9,5,18,0.55)';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        // Домен с барьером
        const dgrd = ctx.createRadialGradient(d.caster.x, d.caster.y, domeR * 0.2, d.caster.x, d.caster.y, domeR);
        dgrd.addColorStop(0, 'rgba(60,10,110,0.55)');
        dgrd.addColorStop(0.8, 'rgba(20,4,40,0.85)');
        dgrd.addColorStop(1, 'rgba(124,58,237,0.9)');
        ctx.fillStyle = dgrd;
        ctx.beginPath();
        ctx.arc(d.caster.x, d.caster.y, domeR, 0, Math.PI * 2);
        ctx.fill();
        // Глиф-орнамент
        ctx.strokeStyle = '#a855f7aa';
        ctx.lineWidth = 2;
        for (let g = 0; g < 8; g++) {
          const ga = d.t * 0.5 + (g * Math.PI * 2) / 8;
          const gx = d.caster.x + Math.cos(ga) * domeR * 0.72;
          const gy = d.caster.y + Math.sin(ga) * domeR * 0.72;
          ctx.beginPath();
          ctx.arc(gx, gy, 7, 0, Math.PI * 2);
          ctx.stroke();
        }
        // Внутренние звёздные частицы
        ctx.fillStyle = '#e9d5ff';
        for (let s2 = 0; s2 < 30; s2++) {
          const sa = s2 * 2.39996323;
          const sr = (s2 / 30) * domeR * 0.8;
          ctx.beginPath();
          ctx.arc(d.caster.x + Math.cos(sa + d.t * 0.3) * sr, d.caster.y + Math.sin(sa + d.t * 0.3) * sr, 1.6, 0, Math.PI * 2);
          ctx.fill();
        }
        // Подпись домена
        ctx.font = `900 ${Math.min(26, aW * 0.04)}px Inter, sans-serif`;
        ctx.textAlign = 'center';
        ctx.fillStyle = '#d8b4fe';
        ctx.shadowColor = '#7c3aed';
        ctx.shadowBlur = 16;
        ctx.fillText('БЕСКОНЕЧНАЯ БЕЗДНА', d.caster.x, d.caster.y - domeR * 0.95);
        ctx.restore();
      }

      // Draw Particles
      particlesRef.current.forEach((p) => {
        p.x += p.vx;
        p.y += p.vy;
        p.alpha -= p.decay;

        ctx.save();
        ctx.globalAlpha = Math.max(0, p.alpha);
        ctx.fillStyle = p.color;
        ctx.shadowColor = p.color;
        ctx.shadowBlur = 6;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      });
      particlesRef.current = particlesRef.current.filter(p => p.alpha > 0);

      // Draw Floating Texts
      floatingTextsRef.current.forEach(ft => {
        ft.y += ft.vy;
        ft.alpha -= 0.02;

        ctx.save();
        ctx.globalAlpha = Math.max(0, ft.alpha);
        ctx.fillStyle = ft.color;
        ctx.shadowColor = '#000000';
        ctx.shadowBlur = 4;
        ctx.font = `bold ${ft.fontSize}px sans-serif`;
        ctx.textAlign = 'center';
        ctx.fillText(ft.text, ft.x, ft.y);
        ctx.restore();
      });
      floatingTextsRef.current = floatingTextsRef.current.filter(ft => ft.alpha > 0);

      // ULTRAKILL: арена реально остаётся разрезанной после третьей техники.
      if (ultraRef.current.slashes.length > 0) {
        ctx.save();
        ultraRef.current.slashes.forEach(s => {
          ctx.save();
          ctx.translate(s.x, s.y);
          ctx.rotate(s.a);
          const len = Math.max(aW, aH) * 1.4;
          const g = ctx.createLinearGradient(-len / 2, 0, len / 2, 0);
          g.addColorStop(0, 'rgba(0,0,0,0)');
          g.addColorStop(0.5, 'rgba(2,4,10,0.95)');
          g.addColorStop(1, 'rgba(0,0,0,0)');
          ctx.fillStyle = g;
          ctx.fillRect(-len / 2, -7, len, 14);
          const hue = (performance.now() / 12) % 360;
          ctx.strokeStyle = `hsl(${hue}, 100%, 65%)`;
          ctx.shadowColor = `hsl(${(hue + 60) % 360}, 100%, 60%)`;
          ctx.shadowBlur = 22;
          ctx.lineWidth = 3;
          ctx.beginPath();
          ctx.moveTo(-len / 2, -7);
          ctx.lineTo(len / 2, -7);
          ctx.moveTo(-len / 2, 7);
          ctx.lineTo(len / 2, 7);
          ctx.stroke();
          ctx.restore();
        });
        ctx.restore();
      }

      // Закрываем область камеры: дальше идут экранные оверлеи.
      ctx.restore();

      // Clock Man: визуальная остановка времени - золотой циферблат поверх арены.
      if (timeStopRef.current) {
        ctx.save();
        const centerX = canvas.width / 2;
        const centerY = canvas.height / 2;
        const clockR = Math.min(canvas.width, canvas.height) * 0.31;
        ctx.fillStyle = 'rgba(8, 12, 24, 0.38)';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.strokeStyle = '#fbbf24aa';
        ctx.shadowColor = '#fbbf24';
        ctx.shadowBlur = 18;
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.arc(centerX, centerY, clockR, 0, Math.PI * 2);
        ctx.stroke();
        for (let h = 0; h < 12; h++) {
          const a = (h * Math.PI * 2) / 12;
          ctx.beginPath();
          ctx.moveTo(centerX + Math.cos(a) * clockR * 0.88, centerY + Math.sin(a) * clockR * 0.88);
          ctx.lineTo(centerX + Math.cos(a) * clockR, centerY + Math.sin(a) * clockR);
          ctx.stroke();
        }
        ctx.beginPath();
        ctx.moveTo(centerX, centerY);
        ctx.lineTo(centerX + clockR * 0.5, centerY - clockR * 0.2);
        ctx.moveTo(centerX, centerY);
        ctx.lineTo(centerX - clockR * 0.18, centerY - clockR * 0.62);
        ctx.stroke();
        ctx.font = '900 18px Inter, sans-serif';
        ctx.textAlign = 'center';
        ctx.fillStyle = '#fde047';
        ctx.fillText(`TIME STOP ${timeStopRef.current.t.toFixed(1)}s`, centerX, centerY + clockR + 30);
        ctx.restore();
      }

      // ===== ЭПИЧНЫЙ БАННЕР СПОСОБНОСТЕЙ (центр экрана, затухает) =====
      if (bannerRef.current) {
        bannerRef.current.t -= 0.022;
        if (bannerRef.current.t <= 0) {
          bannerRef.current = null;
        } else {
          const bn = bannerRef.current;
          const alpha = Math.min(1, bn.t * 1.8);
          ctx.save();
          ctx.globalAlpha = alpha;
          ctx.textAlign = 'center';
          const fs = Math.min(30, aW * 0.042);
          ctx.font = `900 ${fs}px Inter, sans-serif`;
          // Подложка-лента
          const tw = ctx.measureText(bn.text).width;
          ctx.fillStyle = 'rgba(3,6,14,0.72)';
          ctx.fillRect(canvas.width / 2 - tw / 2 - 18, canvas.height * 0.42 - fs - 10, tw + 36, fs + 26);
          ctx.fillStyle = bn.color;
          ctx.shadowColor = bn.color;
          ctx.shadowBlur = 18;
          ctx.fillText(bn.text, canvas.width / 2, canvas.height * 0.42);
          ctx.restore();
        }
      }

      // ===== ВСПЫШКА ЭКРАНА при активации способностей =====
      if (flashRef.current) {
        flashRef.current.alpha -= 0.06;
        if (flashRef.current.alpha <= 0) {
          flashRef.current = null;
        } else {
          ctx.save();
          ctx.globalAlpha = flashRef.current.alpha;
          ctx.fillStyle = flashRef.current.color;
          ctx.fillRect(0, 0, canvas.width, canvas.height);
          ctx.restore();
        }
      }

      ctx.restore();
      animationFrameId = requestAnimationFrame(gameLoop);
    };

    animationFrameId = requestAnimationFrame(gameLoop);
    return () => {
      cancelAnimationFrame(animationFrameId);
      if (endTimeoutRef.current) clearTimeout(endTimeoutRef.current);
    };
    // App gives every new match a fresh key. Pausing or granting rewards must not restart it.
  }, []);

  return (
    <div className="relative w-full h-full flex flex-col items-center justify-center select-none overflow-hidden">
      {/* Переключатели мастери (видны на паузе). */}
      {isPaused && onSetMasteryToggle && (
        <div className="absolute left-4 top-20 z-40 w-60 bg-slate-900/95 border border-slate-700 rounded-2xl p-4 shadow-2xl pointer-events-auto">
          <div className="text-[10px] font-black uppercase tracking-wider text-amber-300 mb-2">Мастери (вкл/выкл)</div>
          {[
            ['lighting', 'Lighting', lightingMasteryUnlocked, enableLightingMastery],
            ['hahaha', 'Hahaha', hahahaMasteryUnlocked, enableHahahaMastery],
          ].map(([key, label, unlocked, enabled]) => (
            <button key={key as string} disabled={!unlocked} onClick={() => onSetMasteryToggle(key as 'lighting' | 'hahaha', !enabled)}
              className={`w-full flex items-center justify-between py-1.5 text-[11px] rounded-lg ${(!unlocked as boolean) ? 'opacity-40 cursor-not-allowed' : 'hover:bg-white/5'}`}>
              <span className="text-slate-300">{label as string}{(!unlocked as boolean) && ' · закрыто'}</span>
              <span className={`w-9 h-5 rounded-full relative transition ${enabled ? 'bg-amber-500' : 'bg-slate-700'}`}>
                <span className={`absolute top-0.5 w-4 h-4 rounded-full bg-white transition-all ${enabled ? 'left-4' : 'left-0.5'}`} />
              </span>
            </button>
          ))}
          <p className="text-[9px] text-slate-500 mt-2">Выключение убирает бонусы мастери, прогресс сохраняется.</p>
        </div>
      )}
      {/* Top Combat HUD */}
      <div className="absolute top-3 left-4 right-4 z-20 flex items-center justify-between pointer-events-none max-w-4xl mx-auto">
        {/* Player 1 Health & Info */}
        <div className="flex items-center gap-3 bg-slate-900/85 backdrop-blur-md px-4 py-2 rounded-2xl border border-sky-500/40 shadow-lg shadow-sky-500/10">
          <div className="w-10 h-10 rounded-full flex items-center justify-center font-bold text-xl" style={{ backgroundColor: playerChar.avatarColor }}>
            {playerChar.iconEmoji || '👤'}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-sm text-sky-400 tracking-wide uppercase">{playerChar.name}</span>
              <span className="text-xs text-slate-400">P1</span>
            </div>
            {/* HP Hearts (small HP) or Health Bar (giants with big HP) */}
            <div className="flex items-center gap-1 mt-1">
              {playerMaxHp <= 10 ? (
                <>
                  {Array.from({ length: playerMaxHp }).map((_, i) => (
                    <div
                      key={i}
                      className={`w-4 h-4 rounded-full transition-all duration-300 ${
                        i < playerHp
                          ? 'bg-rose-500 shadow-md shadow-rose-500/60 scale-100'
                          : 'bg-slate-700/50 scale-75 border border-slate-600'
                      }`}
                    />
                  ))}
                  <span className="ml-2 text-xs font-bold text-rose-400">{playerHp} HP</span>
                </>
              ) : (
                <>
                  <div className="w-24 sm:w-32 h-3 bg-slate-700/60 rounded-full overflow-hidden border border-slate-600">
                    <div
                      className="h-full bg-gradient-to-r from-rose-600 to-rose-400 transition-all duration-300"
                      style={{ width: `${(playerHp / playerMaxHp) * 100}%` }}
                    />
                  </div>
                  <span className="ml-2 text-xs font-bold text-rose-400">{playerHp}/{playerMaxHp}</span>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Center Mode / Buffs Indicator */}
        <div className="hidden sm:flex flex-col items-center justify-center bg-slate-900/80 px-4 py-1.5 rounded-xl border border-slate-700">
          <span className="text-[11px] font-bold uppercase tracking-wider text-amber-400">
            {gameMode === 'final_health'
              ? '🔥 1 HP SUDDEN DEATH'
              : gameMode === 'boss_raid'
              ? `👹 BOSS RAID · УРОН ×${raidDamageBonus(botChar.id)}`
              : gameMode === 'two_player'
              ? '👥 МУЛЬТИПЛЕЕР'
              : gameMode === 'endless'
              ? `♾️ ВОЛНА ${endlessHud.wave} · УБИЙСТВ ${endlessHud.kills}`
              : '⚔️ DUEL ARENA'}
          </span>
          <div className="flex items-center gap-2 mt-0.5 text-xs">
            {playerBuffs.hasShield && <span className="text-cyan-400 font-bold animate-pulse">🛡️ ЩИТ</span>}
            {playerBuffs.hasSpikes && <span className="text-rose-400 font-bold animate-pulse">⚔️ ШИПЫ</span>}
            {playerBuffs.speedBoost && <span className="text-amber-400 font-bold animate-pulse">⚡ СКОРОСТЬ</span>}
            {playerChar.id === 'final' && <span className="text-rose-300 font-black animate-pulse">⚠️ FINAL</span>}
          </div>
        </div>

        {/* Bot / P2 Health & Info */}
        <div className="flex items-center gap-3 bg-slate-900/85 backdrop-blur-md px-4 py-2 rounded-2xl border border-rose-500/40 shadow-lg shadow-rose-500/10">
          <div className="text-right">
            <div className="flex items-center justify-end gap-2">
              <span className="text-xs text-slate-400">{gameMode === 'two_player' ? 'P2' : 'BOT'}</span>
              <span className="font-extrabold text-sm text-rose-400 tracking-wide uppercase">{botChar.name}</span>
            </div>
            <div className="flex items-center justify-end gap-1 mt-1">
              {botMaxHp <= 10 ? (
                <>
                  <span className="mr-2 text-xs font-bold text-rose-400">{botHp} HP</span>
                  {Array.from({ length: botMaxHp }).map((_, i) => (
                    <div
                      key={i}
                      className={`w-4 h-4 rounded-full transition-all duration-300 ${
                        i < botHp
                          ? 'bg-rose-500 shadow-md shadow-rose-500/60 scale-100'
                          : 'bg-slate-700/50 scale-75 border border-slate-600'
                      }`}
                    />
                  ))}
                </>
              ) : (
                <>
                  <span className="mr-2 text-xs font-bold text-rose-400">{botHp}/{botMaxHp}</span>
                  <div className="w-24 sm:w-32 h-3 bg-slate-700/60 rounded-full overflow-hidden border border-slate-600">
                    <div
                      className="h-full bg-gradient-to-r from-rose-400 to-rose-600 transition-all duration-300"
                      style={{ width: `${(botHp / botMaxHp) * 100}%` }}
                    />
                  </div>
                </>
              )}
            </div>
          </div>
          <div className="w-10 h-10 rounded-full flex items-center justify-center font-bold text-xl" style={{ backgroundColor: botChar.avatarColor }}>
            {botChar.iconEmoji || '🤖'}
          </div>
        </div>
      </div>

      {/* Main 60fps Canvas */}
      <canvas
        ref={canvasRef}
        className="w-full h-full max-w-5xl max-h-[82vh] cursor-crosshair rounded-2xl bg-slate-950 border border-slate-800 shadow-2xl"
      />

      {/* ===== ПАЛИТРА ВСЕХ СПОСОБНОСТЕЙ: каждая техника отдельной кнопкой ===== */}
      {gameMode !== 'two_player' && palette.length > 0 && (
        <div className="absolute bottom-24 sm:bottom-20 left-1/2 -translate-x-1/2 z-30 pointer-events-auto max-w-[94vw]">
          <div className="flex items-center gap-1.5 px-2 py-1.5 bg-slate-900/80 border border-slate-700/70 rounded-2xl backdrop-blur-sm overflow-x-auto" style={{ scrollbarWidth: 'thin' }}>
            {palette.map((ab, i) => {
              const locked = !!ab.locked;
              const disabled = locked || playerCooldown > 0 || playerChar.id === 'final' && !playerChar.extraAbilities;
              return (
                <button
                  key={ab.key}
                  disabled={disabled}
                  onClick={() => {
                    const f = fighter1Ref.current, foe = fighter2Ref.current;
                    if (!f || !foe || playerCooldown > 0) return;
                    const list = abilityListFor(f);
                    const idx = list.findIndex(a => a.id === ab.key);
                    if (idx < 0) return;
                    f.abilitySlot = idx;
                    triggerAbility(f, foe);
                  }}
                  title={ab.locked || ab.name}
                  className={`relative shrink-0 min-w-[58px] px-2 py-2 rounded-xl border text-center transition-all active:scale-95 select-none ${locked ? 'opacity-45' : 'hover:brightness-125'}`}
                  style={{ borderColor: `${ab.color}55`, background: `${ab.color}14`, touchAction: 'manipulation' }}
                >
                  <span className="block font-black text-[13px] leading-none" style={{ color: ab.color }}>{locked ? '🔒' : i + 1}</span>
                  <span className="mt-1 block max-w-[74px] truncate text-[7px] uppercase leading-tight text-slate-200">{ab.name}</span>
                  {!locked && <span className="mt-0.5 block text-[6px] text-slate-400">{ab.cd}с</span>}
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* ================= НИЖНЯЯ ПАНЕЛЬ: способность P1 + мобильное управление ================= */}
      <div className="absolute bottom-3 left-2 right-2 z-30 flex items-end justify-between gap-2 max-w-4xl mx-auto pointer-events-auto">
        {/* Кнопка способности P1 */}
        <button
          onPointerDown={e => {
            e.preventDefault();
            if (fighter1Ref.current && fighter2Ref.current) {
              triggerAbility(fighter1Ref.current, fighter2Ref.current);
            }
          }}
          disabled={playerCooldown > 0}
          style={{ touchAction: 'none' }}
          className={`flex items-center gap-2 px-3 sm:px-5 py-2.5 sm:py-3 rounded-2xl font-bold text-sm shadow-xl transition-all duration-200 border active:scale-95 select-none ${
            playerCooldown > 0
              ? 'bg-slate-800/80 border-slate-700 text-slate-400'
              : 'bg-gradient-to-r from-cyan-600 to-blue-600 border-cyan-400 text-white shadow-cyan-500/30 animate-pulse'
          }`}
        >
          <div className="text-xl">✨</div>
          <div className="text-left">
            <div className="text-[10px] sm:text-xs text-cyan-200 uppercase tracking-wider max-w-[120px] sm:max-w-none truncate">
              {playerAbilityName}
            </div>
            <div className="text-[10px] sm:text-xs font-semibold">
              {playerCooldown > 0 ? `КД: ${playerCooldown}с` : 'ГОТОВО!'}
            </div>
          </div>
        </button>

        {/* SPEED GOD — отдельная кнопка (мастери Lighting) */}
        {playerChar.id === 'lighting_secret' && lightingMasteryUnlocked && enableLightingMastery && (
          <button
            onPointerDown={e => { e.preventDefault(); triggerSpeedGod(); }}
            style={{ touchAction: 'none' }}
            disabled={speedGodRef.current.active}
            className={`flex flex-col items-center justify-center px-3 py-2.5 rounded-2xl font-bold text-[10px] uppercase tracking-wider shadow-xl transition-all duration-200 border select-none ${
              speedGodRef.current.active ? 'bg-cyan-300/20 border-cyan-200 text-cyan-100' : 'bg-gradient-to-r from-cyan-400 to-sky-500 border-white text-white shadow-cyan-400/40 animate-pulse'
            }`}
          >
            <span className="text-lg">⚡</span>
            <span>SPEED GOD</span>
            <span className="text-[9px] font-normal normal-case">{speedGodRef.current.active ? `${speedGodRef.current.left.toFixed(1)}с` : '7с · x50'}</span>
          </button>
        )}

        {/* ULTRAKILL: шкала ярости, щит и статус пробуждения */}
        {playerChar.id === 'ultrakill' && (
          <div className="hidden sm:flex flex-col gap-1 bg-slate-900/90 border border-fuchsia-500/40 px-3 py-1.5 rounded-xl">
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-black uppercase text-fuchsia-300">
                {ultraHud.awakened ? 'SEVEN SOULS' : 'ЯРОСТЬ'}
              </span>
              <div className="w-28 h-3 bg-slate-800 rounded-full overflow-hidden border border-slate-700">
                <div
                  className="h-full transition-all duration-200"
                  style={{
                    width: `${ultraHud.awakened ? 100 : ultraHud.charge}%`,
                    background: ultraHud.awakened
                      ? 'linear-gradient(90deg,#f87171,#fbbf24,#4ade80,#38bdf8,#a855f7)'
                      : 'linear-gradient(90deg,#f472b6,#c084fc)'
                  }}
                />
              </div>
              <span className="text-[10px] font-bold text-white">
                {ultraHud.awakened ? 'ULT' : `${ultraHud.charge}%`}
              </span>
            </div>
            {ultraHud.shield > 0 && (
              <div className="text-[10px] font-bold text-sky-300">🛡 ЩИТ: {ultraHud.shield}/5</div>
            )}
          </div>
        )}

        {/* Шкала трансформации Robot User */}
        {playerChar.id === 'robot_user' && (
          <div className="hidden sm:flex bg-slate-900/90 border border-cyan-500/40 px-3 py-1.5 rounded-xl items-center gap-2">
            <span className="text-xs font-bold text-cyan-400">Трансформация:</span>
            <div className="w-24 h-3 bg-slate-800 rounded-full overflow-hidden border border-slate-700">
              <div className="h-full bg-gradient-to-r from-cyan-400 to-blue-500 transition-all duration-200" style={{ width: `${playerTransMeter}%` }} />
            </div>
            <span className="text-xs font-bold text-white">{playerTransMeter}%</span>
          </div>
        )}

        {/* Мобильный D-PAD игрока 1 (снизу) */}
        <TouchPad
          accent="cyan"
          onMove={(vx, vy) => {
            mobileInput.current.vx = vx;
            mobileInput.current.vy = vy;
          }}
          onDash={d => {
            mobileInput.current.dash = d;
          }}
        />
      </div>

      {/* ================= ВЕРХНЯЯ ПАНЕЛЬ ДРУГА (перевёрнута к нему), только мультиплеер ================= */}
      {gameMode === 'two_player' && (
        <div
          className="absolute top-16 left-2 right-2 z-30 flex items-end justify-between gap-2 max-w-4xl mx-auto pointer-events-auto sm:hidden"
          style={{ transform: 'rotate(180deg)' }}
        >
          <button
            onPointerDown={e => {
              e.preventDefault();
              if (fighter1Ref.current && fighter2Ref.current) {
                triggerAbility(fighter2Ref.current, fighter1Ref.current);
              }
            }}
            disabled={p2Cooldown > 0}
            style={{ touchAction: 'none' }}
            className={`flex items-center gap-2 px-3 py-2.5 rounded-2xl font-bold text-xs shadow-xl transition-all duration-200 border active:scale-95 select-none ${
              p2Cooldown > 0
                ? 'bg-slate-800/80 border-slate-700 text-slate-400'
                : 'bg-gradient-to-r from-rose-600 to-pink-600 border-rose-400 text-white shadow-rose-500/30 animate-pulse'
            }`}
          >
            <div className="text-lg">✨</div>
            <div className="text-left">
              <div className="text-[10px] text-rose-200 uppercase tracking-wider max-w-[120px] truncate">{p2AbilityName}</div>
              <div className="text-[10px] font-semibold">{p2Cooldown > 0 ? `КД: ${p2Cooldown}с` : 'ЖМИ!'}</div>
            </div>
          </button>

          <TouchPad
            accent="rose"
            onMove={(vx, vy) => {
              mobileInputP2.current.vx = vx;
              mobileInputP2.current.vy = vy;
            }}
            onDash={d => {
              mobileInputP2.current.dash = d;
            }}
          />
        </div>
      )}

      {/* Разделительная линия половин экрана для двух игроков на телефоне */}
      {gameMode === 'two_player' && (
        <div className="absolute left-0 right-0 top-1/2 z-10 h-px bg-gradient-to-r from-transparent via-rose-500/40 to-transparent sm:hidden pointer-events-none">
          <div className="absolute left-1/2 -translate-x-1/2 -top-2.5 text-[9px] font-black tracking-[0.3em] text-rose-400/70 bg-slate-950/60 px-2 rounded">
            ИГРА С ДРУГОМ
          </div>
        </div>
      )}
    </div>
  );
};


/* ================= Надёжный сенсорный D-PAD (pointer events + touch-action:none) ================= */
const TouchPad: React.FC<{
  accent: 'cyan' | 'rose';
  onMove: (vx: number, vy: number) => void;
  onDash: (dashing: boolean) => void;
}> = ({ accent, onMove, onDash }) => {
  const held = useRef<{ up: boolean; down: boolean; left: boolean; right: boolean }>({ up: false, down: false, left: false, right: false });
  const emit = () => {
    const h = held.current;
    onMove((h.right ? 1 : 0) - (h.left ? 1 : 0), (h.down ? 1 : 0) - (h.up ? 1 : 0));
  };
  const bind = (dir: 'up' | 'down' | 'left' | 'right') => ({
    onPointerDown: (e: React.PointerEvent) => {
      e.preventDefault();
      (e.currentTarget as HTMLElement).setPointerCapture?.(e.pointerId);
      held.current[dir] = true;
      emit();
    },
    onPointerUp: (e: React.PointerEvent) => {
      e.preventDefault();
      held.current[dir] = false;
      emit();
    },
    onPointerCancel: () => {
      held.current[dir] = false;
      emit();
    },
    onPointerLeave: () => {
      held.current[dir] = false;
      emit();
    },
    onContextMenu: (e: React.MouseEvent) => e.preventDefault()
  });
  const active = accent === 'cyan' ? 'active:bg-cyan-500' : 'active:bg-rose-500';
  const border = accent === 'cyan' ? 'border-cyan-700/60' : 'border-rose-700/60';
  const dashCls = accent === 'cyan' ? 'bg-amber-600 active:bg-amber-400 border-amber-400' : 'bg-rose-600 active:bg-rose-400 border-rose-400';
  const btn = `w-11 h-11 bg-slate-800 ${active} rounded-xl text-white font-black flex items-center justify-center text-base select-none`;
  return (
    <div className="flex sm:hidden items-center gap-2" style={{ touchAction: 'none' }}>
      <div className={`grid grid-cols-3 gap-1 bg-slate-900/85 p-1.5 rounded-2xl border ${border}`} style={{ touchAction: 'none' }}>
        <div />
        <button {...bind('up')} className={btn} style={{ touchAction: 'none' }}>▲</button>
        <div />
        <button {...bind('left')} className={btn} style={{ touchAction: 'none' }}>◀</button>
        <button {...bind('down')} className={btn} style={{ touchAction: 'none' }}>▼</button>
        <button {...bind('right')} className={btn} style={{ touchAction: 'none' }}>▶</button>
      </div>
      <button
        onPointerDown={e => {
          e.preventDefault();
          (e.currentTarget as HTMLElement).setPointerCapture?.(e.pointerId);
          onDash(true);
        }}
        onPointerUp={() => onDash(false)}
        onPointerCancel={() => onDash(false)}
        onPointerLeave={() => onDash(false)}
        onContextMenu={e => e.preventDefault()}
        style={{ touchAction: 'none' }}
        className={`w-14 h-14 rounded-2xl ${dashCls} text-white font-black text-[11px] flex items-center justify-center shadow-lg border select-none`}
      >
        ТУРБО
      </button>
    </div>
  );
};
