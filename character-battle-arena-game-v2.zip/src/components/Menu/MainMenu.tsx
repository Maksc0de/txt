import React, { useState } from 'react';
import { Play, Users, ShoppingBag, Package, Settings, Flame, ShieldAlert, Swords, Trophy, Coins, Zap, Gamepad2 } from 'lucide-react';
import type { Character, GameMode, PlayerProgress } from '../../types/game';
import { CharacterPreviewCanvas } from '../Selection/CharacterPreviewCanvas';
import { ALL_CHARACTERS } from '../../data/characters';
import { soundManager } from '../../audio/soundManager';
import { RAID_BOSSES } from '../../game/raidRules';
import { FighterName } from '../Common/FighterName';
import { DAILY_REWARDS, DAILY_QUESTS, ALL_QUESTS_BONUS, FREE_HERO_NEED_DAYS, todayStr } from '../../hooks/useGameSave';

interface MainMenuProps {
  save: PlayerProgress;
  selectedPlayerChar: Character;
  selectedBotChar: Character;
  selectedFriendChar: Character;
  currentMode: GameMode;
  endlessSubmode?: 'standard' | 'duo' | 'last';
  onChangeEndlessSubmode?: (mode: 'standard' | 'duo' | 'last') => void;
  onChangeMode: (mode: GameMode) => void;
  onChangeBoss: (id: string) => void;
  onChangeFriend: (id: string) => void;
  onStartGame: () => void;
  onOpenCharacterSelect: () => void;
  onOpenShop: () => void;
  onOpenCrates: () => void;
  onOpenSettings: () => void;
  teamSize: 1 | 2;
  onTeamSize: (size: 1 | 2) => void;
  onOpenBosses?: () => void;
  onClaimDaily?: () => { coins: number; freeHero?: string };
  onClaimDailyQuest?: (questId: string) => { coins: number };
}

export const MainMenu: React.FC<MainMenuProps> = ({
  save,
  selectedPlayerChar,
  selectedBotChar,
  selectedFriendChar,
  currentMode,
  endlessSubmode = 'standard',
  onChangeEndlessSubmode,
  onChangeMode,
  onChangeBoss,
  onChangeFriend,
  onStartGame,
  onOpenCharacterSelect,
  onOpenShop,
  onOpenCrates,
  onOpenSettings,
  teamSize,
  onTeamSize,
  onOpenBosses,
  onClaimDaily,
  onClaimDailyQuest,
}) => {
  const [showModeModal, setShowModeModal] = useState<boolean>(false);
  const [showBossModal, setShowBossModal] = useState<boolean>(false);
  const [showFriendModal, setShowFriendModal] = useState<boolean>(false);
  const [claimToast, setClaimToast] = useState<string | null>(null);
  const [showDaily, setShowDaily] = useState<boolean>(false);
  const dailyClaimable = save.daily.day !== todayStr() || !save.daily.claimed;

  const winRate = save.matchesPlayed > 0 ? Math.round((save.wins / save.matchesPlayed) * 100) : 0;
  const visibleRosterCount = ALL_CHARACTERS.filter(
    c => c.id !== 'volcanic_ash' && (c.rarity !== 'secret' || save.unlockedCharacters.includes(c.id))
  ).length;
  const defeatedBosses = save.defeatedBosses || [];
  const unlockedBosses: Array<{ id: string; hp: number; tier: string; title: string }> = RAID_BOSSES.filter(b => defeatedBosses.includes(b.id));

  const nameRender = (c: Character) => <FighterName character={c} />;

  return (
    <div className="w-full h-full min-h-screen bg-slate-950 text-white flex flex-col justify-between p-4 sm:p-6 select-none overflow-y-auto relative">
      {/* Background Animated Cyber Neon Grid */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#1e293b15_1px,transparent_1px),linear-gradient(to_bottom,#1e293b15_1px,transparent_1px)] bg-[size:3rem_3rem] pointer-events-none" />

      {/* Top Header Bar */}
      <div className="relative z-10 max-w-5xl w-full mx-auto flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-cyan-500 to-indigo-600 flex items-center justify-center font-black text-2xl shadow-lg shadow-cyan-500/20 border border-cyan-400/40 animate-pulse">
            ⚔️
          </div>
          <div>
            <h1 className="text-xl sm:text-2xl font-black uppercase tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-sky-300 to-indigo-400">
              CIRCLE ARENA BRAWL
            </h1>
            <p className="text-[11px] text-slate-400 font-bold uppercase tracking-widest">
              {visibleRosterCount} Боец • Физические Дуэли • Локальная пати
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div
            onClick={() => { soundManager.playClick(); onOpenShop(); }}
            className="flex items-center gap-2 bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/40 px-3.5 py-2 rounded-2xl transition-all cursor-pointer shadow-inner"
          >
            <Coins className="w-4 h-4 text-amber-400 animate-pulse" />
            <span className="font-extrabold text-amber-300 text-sm">{save.coins.toLocaleString()}</span>
          </div>
          <button
            onClick={() => { soundManager.playClick(); onOpenSettings(); }}
            className="w-10 h-10 rounded-2xl bg-slate-900 border border-slate-700 hover:border-slate-500 text-slate-300 flex items-center justify-center transition-all cursor-pointer shadow-lg hover:text-white"
          >
            <Settings className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Center Matchup Preview & Big Start */}
      <div className="relative z-10 max-w-5xl w-full mx-auto my-auto py-6 flex flex-col items-center gap-6">
        {/* Selected Game Mode Pill */}
        <button
          onClick={() => { soundManager.playClick(); setShowModeModal(true); }}
          className="px-4 py-2 rounded-2xl bg-slate-900/90 border border-sky-500/30 hover:border-sky-400 text-xs font-black uppercase tracking-wider text-sky-300 flex items-center gap-2 transition-all cursor-pointer shadow-lg hover:scale-105 active:scale-95"
        >
          {currentMode === 'standard' && <Swords className="w-4 h-4 text-sky-400" />}
          {currentMode === 'final_health' && <Flame className="w-4 h-4 text-rose-400" />}
          {currentMode === 'boss_raid' && <ShieldAlert className="w-4 h-4 text-amber-400" />}
          {currentMode === 'two_player' && <Gamepad2 className="w-4 h-4 text-emerald-400" />}
          {currentMode === 'endless' && <Flame className="w-4 h-4 text-amber-400" />}
          <span>
            РЕЖИМ:{' '}
            {currentMode === 'standard' ? 'СТАНДАРТ (7 HP + СФЕРЫ)'
              : currentMode === 'final_health' ? 'FINAL HEALTH (1 HP)'
              : currentMode === 'boss_raid' ? 'BOSS RAID'
              : currentMode === 'two_player' ? 'МУЛЬТИПЛЕЕР (2 ИГРОКА)'
              : `ENDLESS (${endlessSubmode === 'duo' ? 'ДУО' : endlessSubmode === 'last' ? 'ЛАСТ' : 'СТАНДАРТ'})`}
          </span>
          <span className="text-slate-500">▼</span>
        </button>

        {/* Endless variant submenu */}
        {currentMode === 'endless' && (
          <div className="flex items-center gap-2 bg-slate-900/70 border border-slate-800 p-1.5 rounded-2xl">
            <span className="text-[10px] font-black uppercase tracking-wider text-slate-500 px-2">Волны:</span>
            {(['standard', 'duo', 'last'] as const).map(v => (
              <button
                key={v}
                onClick={() => { soundManager.playClick(); onChangeEndlessSubmode?.(v); }}
                className={`px-3 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-wider transition-all cursor-pointer ${endlessSubmode === v ? 'bg-amber-500 text-slate-950' : 'text-slate-400 hover:text-white'}`}
              >
                {v === 'standard' ? '+2 HP' : v === 'duo' ? '+1 HP' : 'Last'}
              </button>
            ))}
          </div>
        )}

        {/* Дуо существует только в Boss Raid. */}
        {currentMode === 'boss_raid' && <div className="flex items-center gap-2 bg-slate-900/70 border border-slate-700 p-1.5 rounded-2xl">
          <button
            onClick={() => { soundManager.playClick(); onTeamSize(1); }}
            className={`px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all cursor-pointer ${teamSize === 1 ? 'bg-gradient-to-r from-sky-500 to-blue-600 text-white shadow-md' : 'text-slate-400 hover:text-white'}`}
          >
            Один
          </button>
          <button
            onClick={() => { soundManager.playClick(); onTeamSize(2); }}
            className={`px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all cursor-pointer ${teamSize === 2 ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-white shadow-md' : 'text-slate-400 hover:text-white'}`}
          >
            Дуо (2)
          </button>
          <span className="px-2 text-[10px] text-slate-500 hidden sm:block" style={{ maxWidth: 220 }}>
            {teamSize === 2 ? 'Локальный мультиплеер: ты и друг против одного босса' : 'Одиночный рейд против босса'}
          </span>
        </div>}

        {/* 1 VS 1 Matchup Card */}
        <div className={`w-full ${currentMode === 'boss_raid' && teamSize === 2 ? 'max-w-5xl md:grid-cols-4' : 'max-w-3xl md:grid-cols-3'} bg-slate-900/80 border border-slate-800 rounded-3xl p-6 shadow-2xl backdrop-blur-sm grid grid-cols-1 gap-5 items-center`}>
          {/* Player 1 Fighter Preview */}
          <div
            onClick={() => { soundManager.playClick(); onOpenCharacterSelect(); }}
            className="flex flex-col items-center text-center p-3 rounded-2xl bg-slate-950/70 border border-sky-500/30 hover:border-sky-400 transition-all cursor-pointer group hover:scale-[1.02]"
          >
            <span className="text-[10px] font-black uppercase tracking-wider text-sky-400 mb-1">
              {currentMode === 'boss_raid' && teamSize === 2 ? 'ТЫ · ИГРОК 1' : 'ТВОЙ БОЕЦ'}
            </span>
            <div className="bg-slate-900/60 p-2 rounded-2xl border border-slate-800 my-1 group-hover:shadow-lg group-hover:shadow-sky-500/20 transition-all">
              <CharacterPreviewCanvas character={selectedPlayerChar} size={110} />
            </div>
            <div className="text-base font-black text-white uppercase mt-1">{nameRender(selectedPlayerChar)}</div>
            <div className="text-[11px] text-slate-400">{selectedPlayerChar.titleRu}</div>
            <div className="mt-2 text-[10px] font-bold text-sky-300 bg-sky-950/80 border border-sky-500/30 px-2 py-0.5 rounded-lg">
              ✨ {selectedPlayerChar.ability.nameRu}
            </div>
          </div>

          {/* В дуо-рейде друг выбирает собственного бойца отдельно. */}
          {currentMode === 'boss_raid' && teamSize === 2 && <div
            onClick={() => { soundManager.playClick(); setShowFriendModal(true); }}
            className="flex flex-col items-center text-center p-3 rounded-2xl bg-slate-950/70 border border-emerald-500/30 hover:border-emerald-400 transition-all cursor-pointer group hover:scale-[1.02]"
          >
            <span className="text-[10px] font-black uppercase tracking-wider text-emerald-400 mb-1">ДРУГ · ИГРОК 2</span>
            <div className="bg-slate-900/60 p-2 rounded-2xl border border-slate-800 my-1 group-hover:shadow-lg group-hover:shadow-emerald-500/20 transition-all">
              <CharacterPreviewCanvas character={selectedFriendChar} size={110} />
            </div>
            <div className="text-base font-black text-white uppercase mt-1">{nameRender(selectedFriendChar)}</div>
            <div className="text-[11px] text-slate-400">{selectedFriendChar.titleRu}</div>
            <div className="mt-2 text-[10px] font-bold text-emerald-300 bg-emerald-950/80 border border-emerald-500/30 px-2 py-0.5 rounded-lg">Нажми, чтобы сменить</div>
          </div>}

          {/* VS Center Indicator & Quick Start */}
          <div className="flex flex-col items-center justify-center text-center gap-3">
            <div className="w-14 h-14 rounded-full bg-gradient-to-tr from-rose-600 to-amber-500 flex items-center justify-center font-black text-xl text-white shadow-xl shadow-rose-600/30 border border-amber-400 animate-pulse">
              {currentMode === 'boss_raid' && teamSize === 2 ? '2V1' : currentMode === 'two_player' ? 'P1' : 'VS'}
            </div>

            {/* BIG PLAY BUTTON */}
            <button
              onClick={() => { soundManager.playClick(); onStartGame(); }}
              className="w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500 hover:brightness-110 text-slate-950 font-black text-base uppercase tracking-wider shadow-xl shadow-emerald-500/30 flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-95 hover:scale-105"
            >
              <Play className="w-5 h-5 fill-current" />
              {currentMode === 'boss_raid' && teamSize === 2 ? 'НАЧАТЬ ДУО-РЕЙД' : currentMode === 'two_player' ? 'НАЧАТЬ ДУЭЛЬ ДРУЗЕЙ!' : 'В БОЙ!'}
            </button>
          </div>

          {/* Opponent / Bot Fighter Preview */}
          <div
            onClick={() => { currentMode === 'boss_raid' ? setShowBossModal(true) : onOpenCharacterSelect(); }}
            className="flex flex-col items-center text-center p-3 rounded-2xl bg-slate-950/70 border border-rose-500/30 hover:border-rose-400 transition-all cursor-pointer group hover:scale-[1.02]"
          >
            <span className="text-[10px] font-black uppercase tracking-wider text-rose-400 mb-1">
              {currentMode === 'boss_raid' ? 'БОСС' : currentMode === 'two_player' ? 'ИГРОК 2 (ДРУГ)' : 'ПРОТИВНИК (БОТ)'}
            </span>
            <div className="bg-slate-900/60 p-2 rounded-2xl border border-slate-800 my-1 group-hover:shadow-lg group-hover:shadow-rose-500/20 transition-all">
              <CharacterPreviewCanvas character={selectedBotChar} size={110} />
            </div>
            <div className="text-base font-black text-white uppercase mt-1">{nameRender(selectedBotChar)}</div>
            <div className="text-[11px] text-slate-400">{selectedBotChar.titleRu}</div>
            <div className="mt-2 text-[10px] font-bold text-rose-300 bg-rose-950/80 border border-rose-500/30 px-2 py-0.5 rounded-lg">
              {currentMode === 'boss_raid' ? `👹 HP ×${teamSize === 2 ? 1.9 : 1}` : currentMode === 'two_player' ? `✨ ${selectedBotChar.ability.nameRu}` : `✨ ${selectedBotChar.ability.nameRu}`}
            </div>
          </div>
        </div>

        {/* Boss collection strip */}
        {unlockedBosses.length > 0 && (
          <button
            onClick={() => { soundManager.playClick(); onOpenBosses?.(); }}
            className="w-full max-w-3xl flex items-center gap-3 px-4 py-3 rounded-2xl bg-slate-900/70 border border-amber-500/30 hover:border-amber-400 transition-all cursor-pointer group"
          >
            <span className="text-amber-400 text-xl">👹</span>
            <span className="text-left">
              <span className="block text-[10px] font-black uppercase tracking-wider text-amber-300">Побеждённые боссы</span>
              <span className="block text-xs text-slate-300">
                {unlockedBosses.map(b => b.title || b.id).join(' · ')} — можно играть за них как за персонажей
              </span>
            </span>
            <span className="ml-auto text-slate-500 group-hover:text-white">→</span>
          </button>
        )}

        {/* Bottom Menu Navigation Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 w-full max-w-3xl">
          <button
            onClick={() => { soundManager.playClick(); onOpenCharacterSelect(); }}
            className="p-3.5 rounded-2xl bg-slate-900/90 hover:bg-slate-800 border border-slate-700 hover:border-sky-400 flex flex-col items-center text-center transition-all cursor-pointer shadow-lg active:scale-95 group"
          >
            <div className="w-9 h-9 rounded-xl bg-sky-500/20 text-sky-400 flex items-center justify-center mb-1 group-hover:scale-110 transition-transform"><Users className="w-5 h-5" /></div>
            <span className="text-xs font-black uppercase text-white tracking-wide">Выбор Бойца</span>
            <span className="text-[10px] text-slate-400">{visibleRosterCount} Персонажей</span>
          </button>
          <button
            onClick={() => { soundManager.playClick(); onOpenShop(); }}
            className="p-3.5 rounded-2xl bg-slate-900/90 hover:bg-slate-800 border border-slate-700 hover:border-amber-400 flex flex-col items-center text-center transition-all cursor-pointer shadow-lg active:scale-95 group"
          >
            <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center mb-1 group-hover:scale-110 transition-transform"><ShoppingBag className="w-5 h-5" /></div>
            <span className="text-xs font-black uppercase text-white tracking-wide">Магазин</span>
            <span className="text-[10px] text-slate-400">Бандлы & Бойцы</span>
          </button>
          <button
            onClick={() => { soundManager.playClick(); onOpenCrates(); }}
            className="p-3.5 rounded-2xl bg-slate-900/90 hover:bg-slate-800 border border-slate-700 hover:border-indigo-400 flex flex-col items-center text-center transition-all cursor-pointer shadow-lg active:scale-95 group"
          >
            <div className="w-9 h-9 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center mb-1 group-hover:scale-110 transition-transform"><Package className="w-5 h-5" /></div>
            <span className="text-xs font-black uppercase text-white tracking-wide">Ящики</span>
            <span className="text-[10px] text-slate-400">3 Вида Лутбоксов</span>
          </button>
          <button
            onClick={() => { soundManager.playClick(); onOpenSettings(); }}
            className="p-3.5 rounded-2xl bg-slate-900/90 hover:bg-slate-800 border border-slate-700 hover:border-slate-500 flex flex-col items-center text-center transition-all cursor-pointer shadow-lg active:scale-95 group"
          >
            <div className="w-9 h-9 rounded-xl bg-slate-800 text-slate-300 flex items-center justify-center mb-1 group-hover:scale-110 transition-transform"><Settings className="w-5 h-5" /></div>
            <span className="text-xs font-black uppercase text-white tracking-wide">Настройки</span>
            <span className="text-[10px] text-slate-400">Коды & Сброс</span>
          </button>
        </div>
      </div>

      {/* Daily Rewards & Quests strip */}
      <div className="relative z-10 max-w-5xl w-full mx-auto flex flex-wrap items-center gap-2">
        <button
          onClick={() => { soundManager.playClick(); if (dailyClaimable && onClaimDaily) { const r = onClaimDaily(); if (r.coins > 0) setClaimToast(`+${r.coins} монет${r.freeHero ? ' · открыт персонаж!' : ''}`); else setClaimToast('Награда уже получена сегодня'); setTimeout(() => setClaimToast(null), 3000); } else { setShowDaily(true); } }}
          className={`flex-1 min-w-[220px] flex items-center gap-3 px-4 py-2.5 rounded-2xl border transition-all cursor-pointer ${save.daily.claimed ? 'bg-slate-900/60 border-slate-800 hover:border-slate-600' : 'bg-gradient-to-r from-fuchsia-900/60 to-indigo-900/60 border-fuchsia-500/40 hover:border-fuchsia-400'}`}
        >
          <span className="text-xl">🎁</span>
          <span className="text-left flex-1">
            <span className="block text-[10px] font-black uppercase tracking-wider text-fuchsia-300">Ежедневная награда</span>
            <span className="block text-[11px] text-slate-300">{dailyClaimable ? 'Сегодняшняя награда ждёт!' : 'Сегодня уже забрана — жми, чтобы посмотреть квесты'}</span>
          </span>
          <span className="text-right">
            <span className="block font-black text-amber-300 text-sm">{DAILY_REWARDS[Math.min(save.daily.streak, DAILY_REWARDS.length - 1)]}+</span>
            <span className="block text-[9px] text-slate-500">серия: {save.daily.streak} дн.</span>
          </span>
        </button>
      </div>
      {claimToast && <div className="fixed bottom-20 left-1/2 -translate-x-1/2 z-[60] bg-emerald-500 text-slate-950 px-5 py-3 rounded-2xl font-black text-sm shadow-2xl animate-bounce">{claimToast}</div>}

      {/* Daily modal */}
      {showDaily && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-sm flex items-center justify-center p-4" onClick={() => setShowDaily(false)}>
          <div className="bg-slate-900 border border-slate-700 rounded-3xl p-6 max-w-md w-full flex flex-col gap-4 shadow-2xl max-h-[85vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-black uppercase text-white tracking-wide">Ежедневные награды</h2>
              <button onClick={() => setShowDaily(false)} className="w-8 h-8 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-black text-sm cursor-pointer">✕</button>
            </div>

            {/* Награда дня */}
            <button
              onClick={() => { soundManager.playClick(); if (dailyClaimable && onClaimDaily) { const r = onClaimDaily(); if (r.coins > 0) { setClaimToast(`+${r.coins} монет${r.freeHero ? ' · открыт персонаж!' : ''}`); setTimeout(() => setClaimToast(null), 3000); } } }}
              disabled={!dailyClaimable}
              className={`p-4 rounded-2xl border flex items-center gap-3 transition-all ${save.daily.claimed ? 'bg-slate-950/60 border-slate-800' : 'bg-gradient-to-r from-fuchsia-900/60 to-indigo-900/60 border-fuchsia-500/50 cursor-pointer hover:border-fuchsia-400'}`}
            >
              <span className="text-3xl">🎁</span>
              <span className="flex-1 text-left">
                <span className="block font-black text-white uppercase text-sm">Награда дня</span>
                <span className="block text-[11px] text-slate-400">Серия: {save.daily.streak} дн. · каждая 7-я — бесплатный персонаж</span>
              </span>
              <span className="font-black text-amber-300 text-lg">{save.daily.claimed ? '✓' : `+${DAILY_REWARDS[Math.min(save.daily.streak, DAILY_REWARDS.length - 1)]}`}</span>
            </button>

            {/* Ежедневные квесты */}
            <div className="flex items-center gap-2"><span className="text-lg">📋</span><span className="text-sm font-black uppercase text-white">Квесты дня</span></div>
            {DAILY_QUESTS.map(q => {
              const done = q.id === 'win' ? save.daily.quests.wins >= q.goal : q.id === 'match' ? save.daily.quests.matches >= q.goal : save.daily.quests.crates >= q.goal;
              const claimed = !!save.daily.quests.claimed[q.id];
              const current = q.id === 'win' ? save.daily.quests.wins : q.id === 'match' ? save.daily.quests.matches : save.daily.quests.crates;
              return (
                <div key={q.id} className={`p-3 rounded-2xl border ${done ? 'border-emerald-500/40 bg-emerald-950/30' : 'border-slate-800 bg-slate-950/50'}`}>
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs text-slate-200">{q.label}</span>
                    <span className="text-[10px] text-slate-500">{Math.min(current, q.goal)}/{q.goal}</span>
                  </div>
                  <div className="mt-1.5 flex items-center gap-2">
                    <div className="flex-1 h-2 bg-slate-800 rounded-full overflow-hidden"><div className={`h-full ${done ? 'bg-emerald-400' : 'bg-fuchsia-400'}`} style={{ width: `${Math.min(100, (current / q.goal) * 100)}%` }} /></div>
                    {claimed ? <span className="text-[10px] font-black text-emerald-300 whitespace-nowrap">✓ ПОЛУЧЕНО</span>
                      : done && onClaimDailyQuest ? (
                        <button onClick={() => { soundManager.playClick(); const r = onClaimDailyQuest(q.id); if (r.coins) { setClaimToast(`+${r.coins} монет`); setTimeout(() => setClaimToast(null), 2500); } }} className="px-2.5 py-1 rounded-lg bg-amber-500 text-slate-950 font-black text-[10px] uppercase cursor-pointer">Забрать +{q.reward}</button>
                      ) : <span className="text-[10px] text-amber-400 font-bold whitespace-nowrap">+{q.reward} монет</span>}
                  </div>
                </div>
              );
            })}
            <p className="text-[10px] text-slate-500 leading-relaxed">
              За все 3 квеста дня — бонус +{ALL_QUESTS_BONUS}. Через {Math.max(0, FREE_HERO_NEED_DAYS - save.daily.allQuestsDays)} «полных» дня откроется бесплатный персонаж из коллекции наград.
            </p>
          </div>
        </div>
      )}

      {/* Bottom Mini Stats Footer */}
      <div className="relative z-10 max-w-5xl w-full mx-auto flex flex-wrap items-center justify-between text-xs text-slate-400 bg-slate-900/60 border border-slate-800/80 px-4 py-2.5 rounded-2xl">
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-1 text-slate-300"><Trophy className="w-3.5 h-3.5 text-amber-400" /> Победы: <b>{save.wins}</b> / {save.matchesPlayed} ({winRate}%)</span>
          <span className="flex items-center gap-1 text-slate-300"><Zap className="w-3.5 h-3.5 text-cyan-400" /> Серия: <b>{save.currentWinStreak}</b> (Рекорд: {save.highestWinStreak})</span>
        </div>
        <div className="text-[11px] text-slate-500">Побеждено боссов: <b className="text-amber-300">{defeatedBosses.length}</b> / {RAID_BOSSES.length}</div>
      </div>

      {/* Game Mode Picker Modal */}
      {showModeModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4" onClick={() => setShowModeModal(false)}>
          <div className="bg-slate-900 border border-slate-700 rounded-3xl p-6 max-w-md w-full flex flex-col gap-4 shadow-2xl max-h-[86vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between sticky top-0 -mx-1 bg-slate-900/95 backdrop-blur px-1 py-1 z-10">
              <h2 className="text-lg font-black uppercase text-white tracking-wide">Выберите Режим Игры</h2>
              <button onClick={() => setShowModeModal(false)} className="w-8 h-8 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-black text-sm cursor-pointer">✕</button>
            </div>
            <p className="text-[11px] text-slate-400 -mt-1 sm:hidden">☝️ Свайпай вниз, чтобы увидеть все режимы</p>

            {([
              ['standard', 'Стандартная Дуэль (7 HP)', 'Классика с сферами щита, шипов, ускорения и лечения.', Swords, '#38bdf8'],
              ['final_health', 'Final Health (1 HP)', 'Одно точное попадание решает исход всей битвы!', Flame, '#f87171'],
              ['boss_raid', 'Boss Raid', 'Побеждайте боссов, чтобы открыть их как персонажей. HP зависит от числа игроков.', ShieldAlert, '#fbbf24'],
              ['two_player', 'МУЛЬТИПЛЕЕР (2 игрока)', 'Дуэль на одном устройстве: Игрок 1 снизу, Игрок 2 сверху (экран перевёрнут). У каждого свои кнопки и способности.', Gamepad2, '#34d399'],
              ['endless', 'Endless: Бесконечная Битва', 'Волны врагов. Каждый убитый — очко и монеты.', Flame, '#fbbf24'],
            ] as const).map(([id, title, desc, Icon, color]) => (
              <div
                onClick={() => { soundManager.playClick(); onChangeMode(id); setShowModeModal(false); }}
                className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-start gap-3 ${currentMode === id ? 'bg-slate-950/60 border-slate-700 ring-2 ring-slate-500/20' : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'}`}
              >
                <div className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0" style={{ background: `${color}20`, color }}><Icon className="w-5 h-5" /></div>
                <div><div className="text-sm font-black uppercase text-white">{title}</div><p className="text-xs text-slate-300 mt-0.5">{desc}</p></div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Boss picker modal */}
      {showBossModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4" onClick={() => setShowBossModal(false)}>
          <div className="bg-slate-900 border border-slate-700 rounded-3xl p-6 max-w-lg w-full flex flex-col gap-3 shadow-2xl max-h-[86vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-black uppercase text-white tracking-wide">Выбери Босса</h2>
              <button onClick={() => setShowBossModal(false)} className="w-8 h-8 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-black text-sm cursor-pointer">✕</button>
            </div>
            <p className="text-[11px] text-slate-400">Побеждённые боссы открываются как играбельные персонажи. HP масштабируется: соло ×1, дуо ×1.9.</p>
            <div className="space-y-2">
              {RAID_BOSSES.map(b => {
                const selected = selectedBotChar.id === b.id;
                return (
                  <div
                    onClick={() => { soundManager.playClick(); onChangeBoss(b.id); setShowBossModal(false); }}
                    className={`flex items-center gap-3 p-3 rounded-2xl border transition-all cursor-pointer ${selected ? 'bg-amber-950/60 border-amber-400 ring-2 ring-amber-500/20' : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'}`}
                  >
                    <CharacterPreviewCanvas character={ALL_CHARACTERS.find(c => c.id === b.id) || selectedBotChar} size={52} />
                    <div className="flex-1">
                      <div className="text-sm font-black uppercase text-white">{ALL_CHARACTERS.find(c => c.id === b.id)?.name || b.id}</div>
                      <div className="text-[10px] text-slate-400">Уровень {b.tier} · {b.title}</div>
                    </div>
                    <div className="text-right">
                      <div className="text-sm font-black text-amber-300">{Math.round(b.hp * (teamSize === 2 ? 1.9 : 1)).toLocaleString()} <span className="text-[9px] text-slate-500">HP</span></div>
                      <div className={`text-[9px] font-bold uppercase ${defeatedBosses.includes(b.id) ? 'text-emerald-400' : 'text-slate-500'}`}>{defeatedBosses.includes(b.id) ? '✓ Открыт' : '🔒 Победи, чтобы открыть'}</div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Выбор бойца друга для локального дуо-рейда. */}
      {showFriendModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-sm flex items-center justify-center p-4" onClick={() => setShowFriendModal(false)}>
          <div className="bg-slate-900 border border-emerald-500/30 rounded-3xl p-5 max-w-2xl w-full shadow-2xl max-h-[88vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
            <div className="sticky top-0 z-10 flex items-center justify-between bg-slate-900/95 pb-4">
              <div><span className="text-[9px] font-black uppercase tracking-[.24em] text-emerald-400">ИГРОК 2</span><h2 className="text-xl font-black uppercase text-white">Боец твоего друга</h2></div>
              <button onClick={() => setShowFriendModal(false)} className="w-9 h-9 rounded-xl bg-slate-800 hover:bg-slate-700">✕</button>
            </div>
            <p className="text-xs text-slate-400 mb-4">Показываются только открытые персонажи. В самом рейде у друга будут отдельные кнопки движения и способности.</p>
            <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-2">
              {ALL_CHARACTERS.filter(c => c.id !== 'volcanic_ash' && c.id !== selectedPlayerChar.id && save.unlockedCharacters.includes(c.id)).map(c => (
                <button key={c.id} onClick={() => { soundManager.playPowerup(); onChangeFriend(c.id); setShowFriendModal(false); }} className={`relative p-2 rounded-2xl border flex flex-col items-center gap-1 transition-all ${selectedFriendChar.id === c.id ? 'bg-emerald-950/70 border-emerald-400 ring-2 ring-emerald-400/20' : 'bg-slate-950/60 border-slate-800 hover:border-slate-600'}`}>
                  <CharacterPreviewCanvas character={c} size={70} />
                  <span className="w-full truncate text-[9px] font-black uppercase text-white">{nameRender(c)}</span>
                  <span className="text-[8px] text-slate-500">{c.maxHp} HP</span>
                  {selectedFriendChar.id === c.id && <span className="absolute top-1 right-1 text-emerald-400">✓</span>}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
