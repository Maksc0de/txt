import React, { useState, useEffect, useRef } from 'react';
import { Character, CrateTier } from '../../types/game';
import { ALL_CHARACTERS } from '../../data/characters';
import { CharacterPreviewCanvas } from '../Selection/CharacterPreviewCanvas';
import { soundManager } from '../../audio/soundManager';
import confetti from 'canvas-confetti';
import { Sparkles, Coins, Check, RefreshCw } from 'lucide-react';

interface CrateOpeningModalProps {
  crate: CrateTier;
  unlockedCharacterIds: string[];
  userCoins: number;
  onRewardReceived: (unlockedChar: Character | null, bonusCoins: number) => void;
  onClose: () => void;
  onOpenAnother: () => void;
}

export const CrateOpeningModal: React.FC<CrateOpeningModalProps> = ({
  crate,
  unlockedCharacterIds,
  userCoins,
  onRewardReceived,
  onClose,
  onOpenAnother
}) => {
  const [phase, setPhase] = useState<'shaking' | 'spinning' | 'revealed'>('shaking');
  const [rewardCharacter, setRewardCharacter] = useState<Character | null>(null);
  const [coinCompensation, setCoinCompensation] = useState<number>(0);
  const [isDuplicate, setIsDuplicate] = useState<boolean>(false);
  // Стабильные ссылки: эффект монтируется ровно один раз за открытие ящика.
  const rewardRef = useRef(onRewardReceived);
  rewardRef.current = onRewardReceived;
  const closeRef = useRef(onClose);
  closeRef.current = onClose;
  const doneRef = useRef(false);
  // Защита от двойного нажатия «Ещё» (двойное списание монет).
  const forwardingRef = useRef(false);

  useEffect(() => {
    if (doneRef.current) return; // Защита от повторного запуска анимации и наград.
    doneRef.current = true;
    soundManager.playCrateOpen();

    // 1. Determine drop based on crate rarity weights
    const weights = crate.rarityWeights;
    // Боссы не выпадают из ящиков — их открывают только победой над ними.
    const pool = ALL_CHARACTERS.filter(c => c.rarity !== 'boss' && weights[c.rarity] > 0);

    // Weighted random selection
    let totalWeight = 0;
    pool.forEach(c => {
      totalWeight += weights[c.rarity] || 1;
    });

    let randomVal = Math.random() * totalWeight;
    let chosen: Character = pool[0] || ALL_CHARACTERS[0];

    for (const c of pool) {
      const w = weights[c.rarity] || 1;
      if (randomVal <= w) {
        chosen = c;
        break;
      }
      randomVal -= w;
    }

    const alreadyUnlocked = unlockedCharacterIds.includes(chosen.id);
    let compCoins = 0;
    if (alreadyUnlocked) {
      const minCoin = crate.coinRewardRange[0];
      const maxCoin = crate.coinRewardRange[1];
      compCoins = Math.floor(Math.random() * (maxCoin - minCoin + 1)) + minCoin;
    }

    setRewardCharacter(chosen);
    setIsDuplicate(alreadyUnlocked);
    setCoinCompensation(compCoins);

    // Timing sequence
    const t1 = setTimeout(() => {
      setPhase('spinning');
    }, 1200);

    const t2 = setTimeout(() => {
      setPhase('revealed');
      soundManager.playVictory();

      // Confetti burst
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 }
      });

      rewardRef.current(alreadyUnlocked ? null : chosen, compCoins);
    }, 2800);

    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
    };
    // Монтируем один раз: изменение coins/родителя не должно перезапускать ящик.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [crate.id]);

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4 select-none">
      <div className="max-w-md w-full bg-slate-900 border border-slate-700 rounded-3xl p-6 flex flex-col items-center text-center shadow-2xl relative overflow-hidden">
        {/* Glow halo background */}
        <div
          className="absolute inset-0 opacity-25 blur-3xl pointer-events-none"
          style={{ backgroundColor: crate.accentColor }}
        />

        {/* Phase: Shaking & Opening */}
        {phase === 'shaking' && (
          <div className="flex flex-col items-center py-8">
            <div className="text-7xl animate-bounce">📦</div>
            <h2 className="text-xl font-black uppercase text-white mt-4 tracking-wider animate-pulse">
              Открытие: {crate.nameRu}...
            </h2>
            <p className="text-xs text-slate-400 mt-1">Генерация редкой награды...</p>
          </div>
        )}

        {/* Phase: Spinning Roulette */}
        {phase === 'spinning' && (
          <div className="flex flex-col items-center py-8">
            <div className="w-24 h-24 rounded-full border-4 border-t-cyan-400 border-r-indigo-400 border-b-transparent border-l-transparent animate-spin flex items-center justify-center">
              <Sparkles className="w-8 h-8 text-cyan-400 animate-pulse" />
            </div>
            <h2 className="text-lg font-black uppercase text-cyan-300 mt-6 tracking-wide">
              Определение бойца...
            </h2>
          </div>
        )}

        {/* Phase: Revealed Reward Card */}
        {phase === 'revealed' && rewardCharacter && (
          <div className="flex flex-col items-center w-full animate-in fade-in zoom-in duration-300">
            <span
              className="px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider mb-2 border shadow-lg"
              style={{
                backgroundColor: crate.accentColor + '33',
                color: crate.accentColor,
                borderColor: crate.accentColor
              }}
            >
              {rewardCharacter.rarity.toUpperCase()} НАГРАДА
            </span>

            {/* Character Preview Canvas */}
            <div className="my-3 bg-slate-950/80 p-3 rounded-2xl border border-slate-800 shadow-inner">
              <CharacterPreviewCanvas character={rewardCharacter} size={150} />
            </div>

            <h3 className="text-2xl font-black text-white uppercase tracking-wide">
              {rewardCharacter.name}
            </h3>
            <p className="text-xs text-slate-300 mt-0.5">{rewardCharacter.titleRu}</p>

            {/* Duplicate Notice or New Unlock */}
            {isDuplicate ? (
              <div className="mt-3 bg-amber-500/15 border border-amber-500/40 px-4 py-2 rounded-2xl flex items-center gap-2">
                <Coins className="w-4 h-4 text-amber-400" />
                <span className="text-xs font-bold text-amber-300">
                  Уже открыт! Компенсация: +{coinCompensation} монет
                </span>
              </div>
            ) : (
              <div className="mt-3 bg-emerald-500/15 border border-emerald-500/40 px-4 py-2 rounded-2xl flex items-center gap-2 text-emerald-300">
                <Sparkles className="w-4 h-4 text-emerald-400" />
                <span className="text-xs font-extrabold uppercase tracking-wider">
                  НОВЫЙ ПЕРСОНАЖ РАЗБЛОКИРОВАН!
                </span>
              </div>
            )}

            {/* Action Buttons */}
            <div className="grid grid-cols-2 gap-3 w-full mt-6">
              <button
                onClick={() => {
                  soundManager.playClick();
                  onClose();
                }}
                className="py-3 px-4 rounded-2xl bg-slate-800 hover:bg-slate-700 border border-slate-600 text-slate-200 font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all cursor-pointer"
              >
                <Check className="w-4 h-4" />
                Забрать
              </button>

              <button
                onClick={() => {
                  soundManager.playClick();
                  if (forwardingRef.current) return;
                  if (userCoins >= crate.cost) {
                    forwardingRef.current = true;
                    onOpenAnother();
                  } else {
                    onClose();
                  }
                }}
                disabled={userCoins < crate.cost || forwardingRef.current}
                className={`py-3 px-4 rounded-2xl font-black text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-lg active:scale-95 ${
                  userCoins >= crate.cost && !forwardingRef.current
                    ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 hover:brightness-110 shadow-amber-500/20'
                    : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
                }`}
              >
                <RefreshCw className="w-4 h-4" />
                {forwardingRef.current ? 'Открываем...' : `Еще (${crate.cost})`}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
