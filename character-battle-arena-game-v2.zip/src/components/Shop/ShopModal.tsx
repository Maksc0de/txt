import React, { useMemo, useState } from 'react';
import { Character, CrateTier } from '../../types/game';
import { ALL_CHARACTERS, getCharacterById } from '../../data/characters';
import { STORE_BUNDLES } from '../../data/bundles';
import { CRATE_TIERS } from '../../data/crates';
import { CharacterPreviewCanvas } from '../Selection/CharacterPreviewCanvas';
import { CrateOpeningModal } from './CrateOpeningModal';
import { soundManager } from '../../audio/soundManager';
import { FighterName, fighterNameClass } from '../Common/FighterName';
import { Coins, ShoppingBag, Package, Sparkles, ChevronLeft, Check, ArrowRight } from 'lucide-react';

interface ShopModalProps {
  unlockedCharacterIds: string[];
  userCoins: number;
  onUnlockCharacter: (id: string, cost: number) => boolean;
  onUnlockMultiple: (ids: string[], cost: number) => boolean;
  onAddCoins: (amount: number) => void;
  onRecordCrateOpen: () => void;
  /** Только эти 3 бандла в ротации (меняются каждые 4 дня). */
  activeBundleIds?: string[];
  onClose: () => void;
  onOpenPromoModal: () => void;
}

function bundleDaysLeft(): number {
  const now = Date.now();
  const windowMs = 4 * 86400000;
  const next = (Math.floor(now / windowMs) + 1) * windowMs;
  return Math.max(0, Math.ceil((next - now) / 86400000));
}

export const ShopModal: React.FC<ShopModalProps> = ({
  unlockedCharacterIds,
  userCoins,
  onUnlockCharacter,
  onUnlockMultiple,
  onAddCoins,
  onRecordCrateOpen,
  activeBundleIds,
  onClose,
  onOpenPromoModal
}) => {
  const [activeTab, setActiveTab] = useState<'crates' | 'bundles' | 'characters'>('crates');
  const [activeCrateOpening, setActiveCrateOpening] = useState<CrateTier | null>(null);
  const [characterSearch, setCharacterSearch] = useState<string>('');
  const [selectedCharPreview, setSelectedCharPreview] = useState<Character | null>(null);

  // SECRET-лот появляется только с редким шансом при каждом новом входе в магазин.
  // Если не выпал, ни название редкости, ни персонажи вообще не отображаются.
  const [secretOfferIds] = useState<string[]>(() => {
    const secrets = ALL_CHARACTERS.filter(c => c.rarity === 'secret');
    return secrets.filter(() => Math.random() < 0.06).map(c => c.id);
  });

  const shopCharacters = useMemo(
    // Боссы в магазине не продаются — их выдают только за победу в Boss Raid.
    () => ALL_CHARACTERS.filter(c => c.rarity !== 'boss' && (c.rarity !== 'secret' || secretOfferIds.includes(c.id))),
    [secretOfferIds]
  );

  // Handle Crate Purchase
  const handleOpenCrate = (crate: CrateTier) => {
    soundManager.playClick();
    // Пока анимация ящика идёт — повторное открытие невозможно (защита от фарма).
    if (activeCrateOpening) return;
    if (userCoins < crate.cost) return;
    onAddCoins(-crate.cost);
    onRecordCrateOpen();
    setActiveCrateOpening(crate);
  };

  // Handle Character Purchase
  const handleBuyCharacter = (char: Character) => {
    soundManager.playClick();
    if (char.rarity === 'boss') return; // Боссы открываются только победой над ними.
    if (userCoins < char.price) return;
    const ok = onUnlockCharacter(char.id, char.price);
    if (ok) {
      soundManager.playPowerup();
    }
  };

  return (
    <div className="w-full h-full min-h-screen bg-slate-950 text-white flex flex-col select-none overflow-y-auto">
      {/* Top Shop Header */}
      <div className="sticky top-0 z-30 bg-slate-900/95 backdrop-blur-md border-b border-slate-800 px-4 py-3 flex items-center justify-between shadow-xl">
        <div className="flex items-center gap-3">
          <button
            onClick={() => {
              soundManager.playClick();
              onClose();
            }}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-sm font-semibold transition-all cursor-pointer"
          >
            <ChevronLeft className="w-4 h-4" />
            Назад
          </button>
          <div>
            <h1 className="text-lg font-black tracking-wider uppercase text-transparent bg-clip-text bg-gradient-to-r from-amber-400 via-orange-400 to-yellow-400 flex items-center gap-2">
              <ShoppingBag className="w-5 h-5 text-amber-400" />
              Магазин Арены
            </h1>
          </div>
        </div>

        {/* Coins & Promo Button */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 bg-amber-500/15 border border-amber-500/40 px-3.5 py-1.5 rounded-2xl shadow-inner">
            <Coins className="w-4 h-4 text-amber-400 animate-pulse" />
            <span className="font-extrabold text-amber-300 text-sm">{userCoins.toLocaleString()}</span>
          </div>
          <button
            onClick={() => {
              soundManager.playClick();
              onOpenPromoModal();
            }}
            className="px-3.5 py-1.5 rounded-2xl bg-indigo-600/80 hover:bg-indigo-600 border border-indigo-400/40 text-indigo-200 font-bold text-xs uppercase tracking-wider transition-all cursor-pointer"
          >
            Ввести Код
          </button>
        </div>
      </div>

      {/* Main Container */}
      <div className="flex-1 max-w-7xl w-full mx-auto p-4 flex flex-col gap-6">
        {/* Tab Navigation */}
        <div className="flex items-center justify-center gap-2 bg-slate-900/80 p-1.5 rounded-2xl border border-slate-800 max-w-md mx-auto w-full">
          <button
            onClick={() => {
              soundManager.playClick();
              setActiveTab('crates');
            }}
            className={`flex-1 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
              activeTab === 'crates'
                ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Package className="w-4 h-4" />
            Ящики (3)
          </button>

          <button
            onClick={() => {
              soundManager.playClick();
              setActiveTab('bundles');
            }}
            className={`flex-1 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
              activeTab === 'bundles'
                ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Sparkles className="w-4 h-4" />
            Бандлы ({STORE_BUNDLES.length})
          </button>

          <button
            onClick={() => {
              soundManager.playClick();
              setActiveTab('characters');
            }}
            className={`flex-1 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
              activeTab === 'characters'
                ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <ShoppingBag className="w-4 h-4" />
            Бойцы ({shopCharacters.length})
          </button>
        </div>

        {/* TAB 1: CRATES / LOOTBOXES */}
        {activeTab === 'crates' && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {CRATE_TIERS.map(crate => {
              const canAfford = userCoins >= crate.cost;
              return (
                <div
                  key={crate.id}
                  className={`bg-slate-900/90 border ${crate.borderColor} rounded-3xl p-6 flex flex-col justify-between items-center text-center shadow-xl relative overflow-hidden group hover:scale-[1.02] transition-all`}
                >
                  {/* Background Aura */}
                  <div
                    className="absolute -top-12 -right-12 w-36 h-36 rounded-full opacity-15 blur-2xl pointer-events-none"
                    style={{ backgroundColor: crate.accentColor }}
                  />

                  {/* 3D Chest Visual */}
                  <div className="flex flex-col items-center">
                    <span
                      className="text-xs font-black uppercase tracking-wider px-3 py-1 rounded-full border mb-4 shadow"
                      style={{
                        backgroundColor: crate.accentColor + '22',
                        color: crate.accentColor,
                        borderColor: crate.accentColor
                      }}
                    >
                      {crate.nameRu}
                    </span>

                    <div className="w-28 h-28 rounded-3xl bg-slate-950/80 border border-slate-800 flex items-center justify-center text-6xl shadow-inner group-hover:rotate-6 transition-transform">
                      {crate.id === 'bronze' ? '📦' : crate.id === 'silver' ? '🧰' : '💎'}
                    </div>

                    <p className="text-xs text-slate-300 mt-4 leading-relaxed max-w-xs">
                      {crate.description}
                    </p>

                    {/* Drop Rates Preview */}
                    <div className="w-full bg-slate-950/60 rounded-2xl p-3 border border-slate-800/80 mt-4 text-[11px] text-slate-300 text-left space-y-1">
                      <div className="font-bold text-slate-400 mb-1 uppercase tracking-wider">Шансы выпадения:</div>
                      {crate.rarityWeights.rare > 0 && <div>• Редкие: {crate.rarityWeights.rare}%</div>}
                      {crate.rarityWeights.epic > 0 && <div>• Эпические: {crate.rarityWeights.epic}%</div>}
                      {crate.rarityWeights.legendary > 0 && <div>• Легендарные: {crate.rarityWeights.legendary}%</div>}
                      {crate.rarityWeights.mythic > 0 && <div>• Мифические: {crate.rarityWeights.mythic}%</div>}
                      {crate.rarityWeights.godly > 0 && (
                        <div className="text-yellow-400 font-bold">• Божественные: {crate.rarityWeights.godly}%</div>
                      )}
                    </div>
                  </div>

                  {/* Open Button */}
                  <button
                    onClick={() => handleOpenCrate(crate)}
                    disabled={!canAfford}
                    className={`w-full mt-6 py-3.5 rounded-2xl font-black text-sm uppercase tracking-wider flex items-center justify-center gap-2 transition-all cursor-pointer shadow-lg active:scale-95 ${
                      canAfford
                        ? 'bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 text-slate-950 hover:brightness-110 shadow-amber-500/20'
                        : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
                    }`}
                  >
                    <Coins className="w-5 h-5" />
                    Открыть за {crate.cost.toLocaleString()} монет
                  </button>
                </div>
              );
            })}
          </div>
        )}

        {/* TAB 2: THEMED BUNDLES — ротация 3 набора каждые 4 дня */}
        {activeTab === 'bundles' && (
          <div>
            <div className="flex items-center justify-between gap-3 mb-3 px-1">
              <p className="text-[11px] text-slate-400">Витрина бандлов ротируется каждые 4 дня. Если часть бойцов уже открыта — цена набора меньше.</p>
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 whitespace-nowrap">Обновление: {bundleDaysLeft()} дн.</span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {(activeBundleIds ? STORE_BUNDLES.filter(b => activeBundleIds.includes(b.id)) : STORE_BUNDLES.slice(0, 3)).map(bundle => {
              const missing = bundle.characterIds.filter(id => !unlockedCharacterIds.includes(id));
              const ownedInBundle = bundle.characterIds.length - missing.length;
              const totalOriginal = bundle.characterIds.reduce((sum, id) => sum + Math.max(0, getCharacterById(id).price), 0);
              // Доля цены за недостающих персонажей (скидка за уже открытых).
              const share = missing.length === 0 ? 0
                : Math.max(0, Math.round(bundle.discountPrice * (missing.reduce((sum, id) => sum + Math.max(0, getCharacterById(id).price), 0) / Math.max(1, totalOriginal))));
              const effectivePrice = Math.min(bundle.discountPrice, Math.max(0, share));
              const allOwned = missing.length === 0;
              const canAfford = userCoins >= effectivePrice;
              const bundleCharacters = bundle.characterIds.map(id => getCharacterById(id));

              return (
                <div
                  key={bundle.id}
                  className={`${bundle.id === 'bundle_secret_vault' ? 'secret-bundle-card ' : ''}bg-gradient-to-br ${bundle.bannerColor} bg-opacity-30 border rounded-3xl p-5 flex flex-col justify-between shadow-2xl relative overflow-hidden`}
                >
                  <div>
                    <div className="flex items-center justify-between">
                      <span className="px-2.5 py-1 rounded-xl bg-slate-950/80 border border-slate-700 text-[10px] font-black uppercase text-amber-400 tracking-wider">{bundle.badge}</span>
                      <span className="text-xs font-black text-emerald-400 bg-emerald-950/80 border border-emerald-500/40 px-2 py-0.5 rounded-lg">
                        СКИДКА {Math.round(((bundle.originalPrice - bundle.discountPrice) / bundle.originalPrice) * 100)}%
                      </span>
                    </div>
                    <h3 className="text-lg font-black text-white mt-2 uppercase tracking-wide">{bundle.title}</h3>
                    <p className="text-xs text-slate-300 mt-1 leading-relaxed">{bundle.description}</p>
                    <div className="mt-4 flex flex-wrap gap-2">
                      {bundleCharacters.map(char => {
                        const isOwned = unlockedCharacterIds.includes(char.id);
                        return (
                          <div key={char.id} className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border text-xs font-bold ${isOwned ? 'bg-emerald-950/60 border-emerald-500/40 text-emerald-300' : 'bg-slate-900/80 border-slate-700 text-slate-200'}`}>
                            <span>{char.iconEmoji || '👤'}</span>
                            <span className="truncate max-w-[90px]">{char.name}</span>
                            {isOwned && <Check className="w-3.5 h-3.5 text-emerald-400" />}
                          </div>
                        );
                      })}
                    </div>
                    {ownedInBundle > 0 && !allOwned && (
                      <div className="mt-2 text-[10px] text-emerald-400">✓ Уже есть {ownedInBundle}: цена снижена</div>
                    )}
                  </div>
                  <div className="mt-6 pt-4 border-t border-slate-800/80 flex items-center justify-between">
                    <div>
                      <div className="text-[11px] text-slate-400 line-through">{bundle.discountPrice.toLocaleString()} монет</div>
                      <div className="text-base font-black text-amber-300 flex items-center gap-1"><Coins className="w-4 h-4 text-amber-400" />{effectivePrice.toLocaleString()}</div>
                    </div>
                    {allOwned ? (
                      <div className="px-4 py-2 rounded-xl bg-emerald-600/30 border border-emerald-500/40 text-emerald-300 font-bold text-xs uppercase flex items-center gap-1"><Check className="w-4 h-4" /> КУПЛЕНО</div>
                    ) : (
                      <button
                        onClick={() => {
                          soundManager.playClick();
                          if (userCoins < effectivePrice) return;
                          const ok = onUnlockMultiple(missing, effectivePrice);
                          if (ok) soundManager.playPowerup();
                        }}
                        disabled={!canAfford}
                        className={`py-2.5 px-4 rounded-xl font-black text-xs uppercase tracking-wider flex items-center gap-1.5 transition-all cursor-pointer shadow-lg active:scale-95 ${canAfford ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 hover:brightness-110 shadow-amber-500/20' : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'}`}
                      >
                        Купить Бандл<ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
            </div>
          </div>
        )}

{/* TAB 3: INDIVIDUAL CHARACTERS */}
        {activeTab === 'characters' && (
          <div className="flex flex-col gap-4">
            {/* Search filter */}
            <input
              type="text"
              placeholder={`Поиск по ${shopCharacters.length} бойцам...`}
              value={characterSearch}
              onChange={e => setCharacterSearch(e.target.value)}
              className="w-full max-w-md mx-auto px-4 py-2 bg-slate-900 border border-slate-700 rounded-2xl text-sm text-white placeholder-slate-400 focus:outline-none focus:border-amber-500"
            />

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3 max-h-[68vh] overflow-y-auto pr-1">
              {shopCharacters.filter(c =>
                c.name.toLowerCase().includes(characterSearch.toLowerCase()) ||
                c.titleRu.toLowerCase().includes(characterSearch.toLowerCase())
              ).map(char => {
                const isUnlocked = unlockedCharacterIds.includes(char.id);
                const canAfford = userCoins >= char.price;

                return (
                  <div
                    key={char.id}
                    onClick={() => setSelectedCharPreview(char)}
                    className={`bg-slate-900/85 border border-slate-800 hover:border-slate-700 p-3 rounded-2xl flex flex-col items-center justify-between text-center transition-all cursor-pointer group ${char.rarity === 'secret' ? 'secret-card' : ''}`}
                  >
                    <div className="flex flex-col items-center w-full">
                      <div
                        className="w-14 h-14 rounded-full flex items-center justify-center font-bold text-2xl shadow-inner border-2 mb-2 group-hover:scale-105 transition-transform"
                        style={{ backgroundColor: char.avatarColor, borderColor: char.glowColor }}
                      >
                        {char.iconEmoji || '👤'}
                      </div>
                      <div className={`text-xs font-black uppercase truncate w-full ${fighterNameClass(char.id) || 'text-white'}`}>
                        <FighterName character={char} />
                      </div>
                      <span className="text-[10px] text-slate-400">{char.rarity}</span>
                    </div>

                    <div className="w-full mt-3">
                      {isUnlocked ? (
                        <div className="w-full py-1.5 rounded-xl bg-emerald-600/20 border border-emerald-500/40 text-emerald-300 font-bold text-[11px] uppercase flex items-center justify-center gap-1">
                          <Check className="w-3.5 h-3.5" />
                          Куплен
                        </div>
                      ) : (
                        <button
                          onClick={e => {
                            e.stopPropagation();
                            handleBuyCharacter(char);
                          }}
                          disabled={!canAfford}
                          className={`w-full py-1.5 rounded-xl font-bold text-[11px] uppercase tracking-wide flex items-center justify-center gap-1 transition-all cursor-pointer active:scale-95 ${
                            canAfford
                              ? 'bg-amber-500 hover:bg-amber-400 text-slate-950 font-black'
                              : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
                          }`}
                        >
                          <Coins className="w-3.5 h-3.5" />
                          {char.price.toLocaleString()}
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* Crate Opening Modal Popup */}
      {activeCrateOpening && (
        <CrateOpeningModal
          crate={activeCrateOpening}
          unlockedCharacterIds={unlockedCharacterIds}
          userCoins={userCoins}
          onRewardReceived={(newChar, bonusCoins) => {
            if (newChar) {
              onUnlockCharacter(newChar.id, 0);
            }
            if (bonusCoins > 0) {
              onAddCoins(bonusCoins);
            }
          }}
          onClose={() => setActiveCrateOpening(null)}
          onOpenAnother={() => {
            if (userCoins >= activeCrateOpening.cost) {
              onAddCoins(-activeCrateOpening.cost);
              onRecordCrateOpen();
              // re-trigger
              setActiveCrateOpening(null);
              setTimeout(() => setActiveCrateOpening(activeCrateOpening), 50);
            }
          }}
        />
      )}

      {/* Character Quick Preview Modal */}
      {selectedCharPreview && (
        <div
          className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4"
          onClick={() => setSelectedCharPreview(null)}
        >
          <div
            className="bg-slate-900 border border-slate-700 rounded-3xl p-6 max-w-sm w-full flex flex-col items-center text-center shadow-2xl"
            onClick={e => e.stopPropagation()}
          >
            <div className="bg-slate-950/80 p-2 rounded-2xl border border-slate-800 mb-3">
              <CharacterPreviewCanvas character={selectedCharPreview} size={130} />
            </div>
            {<h3 className={`text-xl font-black uppercase ${fighterNameClass(selectedCharPreview.id) || 'text-white'}`}><FighterName character={selectedCharPreview} /></h3>}
            <p className="text-xs text-slate-300 mt-0.5">{selectedCharPreview.titleRu}</p>
            <div className="mt-3 bg-slate-950/60 p-3 rounded-xl border border-slate-800 text-xs text-left w-full space-y-1">
              <div className="text-cyan-300 font-bold">Способность: {selectedCharPreview.ability.nameRu}</div>
              <div className="text-slate-300">{selectedCharPreview.ability.description}</div>
              <div className="text-slate-400 text-[11px] mt-1">Пассивка: {selectedCharPreview.passiveDesc}</div>
            </div>
            <button
              onClick={() => setSelectedCharPreview(null)}
              className="mt-4 w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs uppercase cursor-pointer"
            >
              Закрыть
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
