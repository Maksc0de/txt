import React, { useRef, useEffect } from 'react';
import { Character } from '../../types/game';
import { drawCharacterAvatar } from '../../utils/characterRenderer';

interface CharacterPreviewCanvasProps {
  character: Character;
  size?: number;
  className?: string;
  isTransformed?: boolean;
}

export const CharacterPreviewCanvas: React.FC<CharacterPreviewCanvasProps> = ({
  character,
  size = 140,
  className = '',
  isTransformed = false
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let weaponAngle = 0;
    let animId: number;

    const render = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Long serpentine leviathans need a smaller head + offset so the body fits in the thumbnail
      const isLongLeviathan = character.modelType === 'segmented_leviathan';
      const isDragon = character.modelType === 'dragon';
      const segLen = character.segmentLength || 4;
      const previewScale = isDragon
        ? 0.82
        : isLongLeviathan
        ? Math.max(0.5, 1.1 / (1 + segLen * 0.12))
        : (character.isGiant ? Math.min(character.giantMultiplier || 1.4, 1.6) : 1.0);
      const baseRadius = 26 * previewScale;
      const centerX = canvas.width / 2 + (isLongLeviathan ? baseRadius * 1.4 : isDragon ? baseRadius * 0.25 : 0);
      const centerY = canvas.height / 2 - (isLongLeviathan ? baseRadius * 0.4 : 0);

      weaponAngle += 0.04;

      drawCharacterAvatar(
        ctx,
        character,
        centerX,
        centerY,
        baseRadius,
        isLongLeviathan ? -0.5 : 0,
        weaponAngle,
        {
          isTransformed,
          hasShield: false,
          hasSpikesBuff: false
        }
      );

      animId = requestAnimationFrame(render);
    };

    animId = requestAnimationFrame(render);
    return () => cancelAnimationFrame(animId);
  }, [character, isTransformed]);

  return (
    <canvas
      ref={canvasRef}
      width={size}
      height={size}
      className={`rounded-2xl ${className}`}
    />
  );
};
