import React from 'react';
import type { Character } from '../../types/game';

/** Особые стили имён: у каждого секретного/финального бойца — свой шрифт и анимация. */
const SPECIAL_NAME_CLASS: Record<string, string> = {
  ultrakill: 'ultra-name',
  final: 'final-glitch',
  glitch_secret: 'secret-glitch',
  lighting_secret: 'secret-lighting',
  stellar_secret: 'stellar-name',
  god_of_war: 'gow-name',
  sword_glitcher: 'sword-glitcher-name',
  eclipse_boss: 'eclipse-name',
  war_lord: 'war-lord-name',
};

export const fighterNameClass = (id: string): string => SPECIAL_NAME_CLASS[id] || '';

export const FighterName: React.FC<{ character: Character; className?: string }> = ({ character, className = '' }) => {
  const special = fighterNameClass(character.id);
  return <span className={`${special} ${className}`.trim()}>{character.name}</span>;
};
