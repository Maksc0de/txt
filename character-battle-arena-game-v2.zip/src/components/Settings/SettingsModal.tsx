import React, { useState } from 'react';
import { GameSettings } from '../../types/game';
import { soundManager } from '../../audio/soundManager';
import { Volume2, Sparkles, KeyRound, RotateCcw, ChevronLeft, Check, AlertTriangle, ShieldCheck } from 'lucide-react';

interface SettingsModalProps {
  settings: GameSettings;
  onUpdateSettings: (newSettings: Partial<GameSettings>) => void;
  onRedeemCode: (code: string) => { success: boolean; message: string; coinsAdded?: number };
  onResetProgress: () => void;
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  settings,
  onUpdateSettings,
  onRedeemCode,
  onResetProgress,
  onClose
}) => {
  const [promoCodeInput, setPromoCodeInput] = useState<string>('');
  const [promoFeedback, setPromoFeedback] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [showResetConfirm, setShowResetConfirm] = useState<boolean>(false);

  const handleApplyCode = (e: React.FormEvent) => {
    e.preventDefault();
    if (!promoCodeInput.trim()) return;
    soundManager.playClick();
    const res = onRedeemCode(promoCodeInput.trim());
    if (res.success) {
      soundManager.playVictory();
      setPromoFeedback({ type: 'success', text: res.message });
      setPromoCodeInput('');
    } else {
      soundManager.playHit(false);
      setPromoFeedback({ type: 'error', text: res.message });
    }
  };

  const handleConfirmReset = () => {
    soundManager.playHit(true);
    onResetProgress();
    setShowResetConfirm(false);
    onClose();
  };

  return (
    <div className="w-full h-full min-h-screen bg-slate-950 text-white flex flex-col select-none overflow-y-auto">
      {/* Header */}
      <div className="sticky top-0 z-30 bg-slate-900/95 backdrop-blur-md border-b border-slate-800 px-4 py-3 flex items-center justify-between shadow-xl">
        <div className="flex items-center gap-3">
          <button
            onClick={() => {
              soundManager.playClick();
              onClose();
            }}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-sm font-semibold transition-all cursor-pointer"
          >
            <ChevronLeft className="w-4 h-4" />
            Назад
          </button>
          <h1 className="text-lg font-black tracking-wider uppercase text-slate-100">
            Настройки & Коды
          </h1>
        </div>
      </div>

      {/* Main Form */}
      <div className="flex-1 max-w-3xl w-full mx-auto p-4 flex flex-col gap-6">
        {/* Section 1: Promo & DLC Code Redemption */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 shadow-xl">
          <div className="flex items-center gap-2 mb-3">
            <KeyRound className="w-5 h-5 text-indigo-400" />
            <h2 className="text-sm font-black uppercase text-indigo-300 tracking-wider">
              Активация Промо / DLC Кода
            </h2>
          </div>

          <form onSubmit={handleApplyCode} className="flex flex-col sm:flex-row gap-2">
            <input
              type="text"
              placeholder="Введите промокод или секретный DLC код..."
              value={promoCodeInput}
              onChange={e => setPromoCodeInput(e.target.value)}
              className="flex-1 px-4 py-3 bg-slate-950 border border-slate-700 rounded-2xl text-sm text-white placeholder-slate-500 uppercase font-mono tracking-wider focus:outline-none focus:border-indigo-500"
            />
            <button
              type="submit"
              className="py-3 px-6 rounded-2xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:brightness-110 text-white font-black text-xs uppercase tracking-wider shadow-lg shadow-indigo-600/30 cursor-pointer active:scale-95"
            >
              Активировать
            </button>
          </form>

          {promoFeedback && (
            <div
              className={`mt-3 p-3 rounded-2xl border text-xs font-bold flex items-center gap-2 ${
                promoFeedback.type === 'success'
                  ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-300'
                  : 'bg-rose-500/15 border-rose-500/40 text-rose-300'
              }`}
            >
              {promoFeedback.type === 'success' ? (
                <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
              ) : (
                <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
              )}
              <span>{promoFeedback.text}</span>
            </div>
          )}
        </div>

        {/* Section 2: Audio & FX Preferences */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 shadow-xl space-y-4">
          <div className="flex items-center gap-2 mb-2">
            <Volume2 className="w-5 h-5 text-cyan-400" />
            <h2 className="text-sm font-black uppercase text-cyan-300 tracking-wider">
              Звук & Графика
            </h2>
          </div>

          {/* Volume Slider */}
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-300 font-bold">Громкость звуковых эффектов:</span>
            <div className="flex items-center gap-3">
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                value={settings.soundVolume}
                onChange={e => {
                  const val = parseFloat(e.target.value);
                  onUpdateSettings({ soundVolume: val });
                }}
                className="w-32 accent-cyan-400"
              />
              <span className="text-xs font-mono font-bold text-cyan-400 w-8">
                {Math.round(settings.soundVolume * 100)}%
              </span>
            </div>
          </div>

          {/* Screen Shake */}
          <div className="flex items-center justify-between pt-2 border-t border-slate-800">
            <div>
              <div className="text-xs text-slate-200 font-bold">Тряска экрана при ударах</div>
              <div className="text-[11px] text-slate-400">Динамический эффект отдачи при столкновениях</div>
            </div>
            <button
              onClick={() => {
                soundManager.playClick();
                onUpdateSettings({ screenShake: !settings.screenShake });
              }}
              className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer ${
                settings.screenShake ? 'bg-cyan-500' : 'bg-slate-800'
              }`}
            >
              <div
                className={`w-5 h-5 bg-white rounded-full absolute top-0.5 transition-transform ${
                  settings.screenShake ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>

          {/* Dynamic Arena Zoom */}
          <div className="flex items-center justify-between pt-2 border-t border-slate-800">
            <div>
              <div className="text-xs text-slate-200 font-bold">Динамическое масштабирование арены</div>
              <div className="text-[11px] text-slate-400">Автоматическое расширение поля при игре за Гигантов</div>
            </div>
            <button
              onClick={() => {
                soundManager.playClick();
                onUpdateSettings({ dynamicArenaZoom: !settings.dynamicArenaZoom });
              }}
              className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer ${
                settings.dynamicArenaZoom ? 'bg-cyan-500' : 'bg-slate-800'
              }`}
            >
              <div
                className={`w-5 h-5 bg-white rounded-full absolute top-0.5 transition-transform ${
                  settings.dynamicArenaZoom ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>

          {/* Particle Density */}
          <div className="flex items-center justify-between pt-2 border-t border-slate-800">
            <span className="text-xs text-slate-300 font-bold">Плотность частиц:</span>
            <div className="flex gap-1">
              {(['low', 'medium', 'high'] as const).map(p => (
                <button
                  key={p}
                  onClick={() => {
                    soundManager.playClick();
                    onUpdateSettings({ particleDensity: p });
                  }}
                  className={`px-3 py-1 rounded-xl text-xs font-bold uppercase cursor-pointer border ${
                    settings.particleDensity === p
                      ? 'bg-cyan-600 border-cyan-400 text-white'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {p === 'low' ? 'Мин' : p === 'medium' ? 'Сред' : 'Макс'}
                </button>
              ))}
            </div>
          </div>

          {/* ====== КАСТОМНЫЙ ЗАДНИЙ ФОН ИГРЫ ====== */}
          <div className="pt-3 border-t border-slate-800">
            <div className="text-xs text-slate-200 font-black uppercase mb-1">Задний фон игры</div>
            <div className="text-[11px] text-slate-400 mb-3">Выбери настроение арены — меняется мгновенно во всех экранах</div>
            <div className="grid grid-cols-3 gap-2">
              {(
                [
                  { id: 'cosmic', name: 'Космос', preview: 'bg-slate-950 border-sky-800' },
                  { id: 'abyss', name: 'Бездна', preview: 'bg-gradient-to-b from-sky-950 to-cyan-900 border-cyan-700' },
                  { id: 'sunset', name: 'Закат', preview: 'bg-gradient-to-b from-orange-900 to-rose-950 border-rose-700' },
                  { id: 'candy', name: 'Конфета', preview: 'bg-gradient-to-b from-fuchsia-900 to-purple-950 border-pink-700' },
                  { id: 'matrix', name: 'Матрица', preview: 'bg-gradient-to-b from-emerald-950 to-green-900 border-emerald-700' },
                  { id: 'volcano', name: 'Вулкан', preview: 'bg-gradient-to-b from-red-900 to-stone-950 border-red-700' }
                ] as const
              ).map(theme => {
                const isActive = (settings.bgTheme || 'cosmic') === theme.id;
                return (
                  <button
                    key={theme.id}
                    onClick={() => {
                      soundManager.playClick();
                      onUpdateSettings({ bgTheme: theme.id });
                    }}
                    className={`relative h-14 rounded-2xl overflow-hidden border-2 transition-all cursor-pointer ${theme.preview} ${
                      isActive ? 'ring-2 ring-cyan-400 scale-[1.03] shadow-lg shadow-cyan-500/20' : 'opacity-70 hover:opacity-100 hover:scale-[1.02]'
                    }`}
                  >
                    <span className="absolute inset-0 flex items-center justify-center text-[10px] font-black uppercase tracking-wider text-white drop-shadow-md">
                      {theme.name}
                    </span>
                    {isActive && (
                      <span className="absolute top-1 right-1 w-4 h-4 rounded-full bg-cyan-400 flex items-center justify-center">
                        <ShieldCheck className="w-3 h-3 text-slate-950" />
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Section 3: Controls Guide */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 shadow-xl space-y-3">
          <div className="flex items-center gap-2 mb-1">
            <Sparkles className="w-5 h-5 text-amber-400" />
            <h2 className="text-sm font-black uppercase text-amber-300 tracking-wider">
              Управление & Правила Боя
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs text-slate-300">
            <div className="bg-slate-950/80 p-3 rounded-2xl border border-slate-800 space-y-1">
              <div className="font-bold text-sky-400 uppercase">Игрок 1 (Клавиатура)</div>
              <div>• <b>WASD</b> или <b>Стрелки</b>: Перемещение бойца</div>
              <div>• <b>ПРОБЕЛ</b>: Активация Уникальной Способности</div>
              <div>• <b>SHIFT</b>: Турбо-рывок и ускорение</div>
            </div>

            <div className="bg-slate-950/80 p-3 rounded-2xl border border-slate-800 space-y-1">
              <div className="font-bold text-rose-400 uppercase">Игрок 2 (Режим 2 Игрока)</div>
              <div>• <b>I / J / K / L</b> или <b>Num 8,4,5,6</b>: Движение</div>
              <div>• <b>ENTER</b> или <b>O</b>: Способность P2</div>
              <div>• <b>Сенсорный экран</b>: Экранный джойстик</div>
            </div>
          </div>
        </div>

        {/* Section 4: Reset All Progress */}
        <div className="bg-slate-900/90 border border-rose-500/30 rounded-3xl p-5 shadow-xl flex items-center justify-between">
          <div>
            <div className="text-sm font-black text-rose-400 uppercase tracking-wide">
              Сбросить весь прогресс
            </div>
            <div className="text-xs text-slate-400 mt-0.5">
              Сбрасывает купленных бойцов, монеты и статистику побед к исходному состоянию.
            </div>
          </div>
          <button
            onClick={() => setShowResetConfirm(true)}
            className="py-2.5 px-4 rounded-2xl bg-rose-950 hover:bg-rose-900 border border-rose-600/50 text-rose-300 font-bold text-xs uppercase tracking-wider transition-all cursor-pointer flex items-center gap-1.5 active:scale-95"
          >
            <RotateCcw className="w-4 h-4" />
            Сброс
          </button>
        </div>
      </div>

      {/* Reset Confirmation Modal */}
      {showResetConfirm && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-rose-500/50 rounded-3xl p-6 max-w-sm w-full flex flex-col items-center text-center shadow-2xl animate-in zoom-in-95 duration-200">
            <AlertTriangle className="w-12 h-12 text-rose-400 mb-2 animate-bounce" />
            <h3 className="text-lg font-black text-white uppercase">Вы уверены?</h3>
            <p className="text-xs text-slate-300 mt-2 leading-relaxed">
              Все разблокированные персонажи и монеты будут сброшены до начальных настроек.
            </p>

            <div className="grid grid-cols-2 gap-3 w-full mt-6">
              <button
                onClick={() => setShowResetConfirm(false)}
                className="py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold uppercase cursor-pointer"
              >
                Отмена
              </button>
              <button
                onClick={handleConfirmReset}
                className="py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-black uppercase cursor-pointer shadow-lg shadow-rose-600/30 flex items-center justify-center gap-1"
              >
                <Check className="w-4 h-4" />
                Да, сбросить
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
