import React, { useEffect } from 'react';
import { Character } from '../../types/game';
import { CharacterPreviewCanvas } from '../Selection/CharacterPreviewCanvas';
import { soundManager } from '../../audio/soundManager';
import confetti from 'canvas-confetti';
import { Trophy, Skull, Coins, RefreshCw, Users, Home } from 'lucide-react';

interface VictoryModalProps {
  winner: 'player' | 'bot' | 'p2';
  playerChar: Character;
  botChar: Character;
  coinsEarned: number;
  stats: { hits: number; damage: number };
  kills?: number;
  mode?: string;
  onPlayAgain: () => void;
  onChangeFighter: () => void;
  onGoToMenu: () => void;
}

export const VictoryModal: React.FC<VictoryModalProps> = ({
  winner,
  playerChar,
  botChar,
  coinsEarned,
  stats,
  kills,
  mode,
  onPlayAgain,
  onChangeFighter,
  onGoToMenu
}) => {
  const isTwoPlayer = mode === 'two_player';
  const isPlayerWinner = winner === 'player';
  const isEndless = mode === 'endless';
  const winningChar = isPlayerWinner ? playerChar : botChar;

  useEffect(() => {
    if (isTwoPlayer) {
      soundManager.playVictory();
      confetti({ particleCount: 90, spread: 75, origin: { y: 0.6 } });
    } else if (isPlayerWinner) {
      soundManager.playVictory();
      confetti({
        particleCount: 120,
        spread: 80,
        origin: { y: 0.6 }
      });
    } else {
      soundManager.playDefeat();
    }
  }, [isPlayerWinner]);

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4 select-none animate-in fade-in zoom-in-95 duration-200">
      <div className="max-w-md w-full bg-slate-900 border border-slate-700 rounded-3xl p-6 flex flex-col items-center text-center shadow-2xl relative overflow-hidden">
        {/* Glow Background */}
        <div
          className={`absolute -top-16 inset-x-0 h-40 opacity-20 blur-3xl pointer-events-none ${
            isPlayerWinner ? 'bg-amber-500' : 'bg-rose-500'
          }`}
        />

        {/* Header Icon */}
        <div className="flex items-center justify-center mb-2">
          {isPlayerWinner ? (
            <div className="w-16 h-16 rounded-full bg-amber-500/20 border-2 border-amber-400 flex items-center justify-center text-amber-400 animate-bounce">
              <Trophy className="w-8 h-8" />
            </div>
          ) : (
            <div className="w-16 h-16 rounded-full bg-rose-500/20 border-2 border-rose-500 flex items-center justify-center text-rose-400">
              <Skull className="w-8 h-8" />
            </div>
          )}
        </div>

        {/* Title */}
        <h2 className="text-2xl font-black uppercase tracking-wider text-white">
          {isTwoPlayer
            ? winner === 'player' ? 'ИГРОК 1 ПОБЕДИЛ!' : 'ИГРОК 2 ПОБЕДИЛ!'
            : isEndless
            ? `ВОЛНЫ ПРОЙДЕНЫ: ${kills || 0}`
            : isPlayerWinner
            ? 'ПОБЕДА В ДУЭЛИ!'
            : 'ПОРАЖЕНИЕ...'}
        </h2>
        <p className="text-xs text-slate-400 mt-0.5">
          {isEndless
            ? `Ты продержался до ${kills || 0} волны и отправил на тот свет ${kills || 0} противников! Монеты за каждого каска!`
            : isPlayerWinner
            ? isTwoPlayer
              ? winner === 'player' ? 'Первый игрок забрал победу в локальной дуэли!' : 'Второй игрок оказался сильнее — реванш?'
              : 'Отличный бой! Противник повержен!'
            : 'Бот оказался сильнее. Попробуйте другую тактику!'}
        </p>

        {/* Winner Character Preview */}
        <div className="my-4 bg-slate-950/80 p-2.5 rounded-2xl border border-slate-800 shadow-inner">
          <CharacterPreviewCanvas character={winningChar} size={130} />
        </div>

        <div className="text-sm font-black text-white uppercase tracking-wide">
          Победитель: {winningChar.name}
        </div>

        {/* Rewards & Stats Box */}
        <div className="grid grid-cols-2 gap-2.5 w-full mt-4 bg-slate-950/60 p-3 rounded-2xl border border-slate-800 text-xs">
          <div className="flex flex-col items-center justify-center bg-slate-900/80 p-2 rounded-xl border border-slate-800">
            <span className="text-[10px] uppercase font-bold text-slate-400">{isTwoPlayer ? 'Победитель' : 'Награда'}</span>
            <span className="text-base font-black text-amber-300 flex items-center gap-1 mt-0.5">
              {isTwoPlayer ? (winner === 'player' ? 'ИГРОК 1' : 'ИГРОК 2') : <><Coins className="w-4 h-4 text-amber-400" />+{coinsEarned}</>}
            </span>
          </div>

          <div className="flex flex-col items-center justify-center bg-slate-900/80 p-2 rounded-xl border border-slate-800">
            <span className="text-[10px] uppercase font-bold text-slate-400">Урон / Удары</span>
            <span className="text-base font-black text-sky-400 mt-0.5">
              {stats.damage} HP / {stats.hits} уд.
            </span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col gap-2.5 w-full mt-6">
          <button
            onClick={() => {
              soundManager.playClick();
              onPlayAgain();
            }}
            className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-sky-500 via-blue-600 to-indigo-600 hover:brightness-110 text-white font-black text-xs uppercase tracking-wider shadow-lg shadow-sky-500/20 flex items-center justify-center gap-2 cursor-pointer active:scale-95"
          >
            <RefreshCw className="w-4 h-4" />
            Реванш (Играть Снова)
          </button>

          <div className="grid grid-cols-2 gap-2 w-full">
            <button
              onClick={() => {
                soundManager.playClick();
                onChangeFighter();
              }}
              className="py-3 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-600 text-slate-200 font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 cursor-pointer transition-all"
            >
              <Users className="w-4 h-4" />
              Выбрать Бойца
            </button>

            <button
              onClick={() => {
                soundManager.playClick();
                onGoToMenu();
              }}
              className="py-3 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-600 text-slate-200 font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 cursor-pointer transition-all"
            >
              <Home className="w-4 h-4" />
              Главное Меню
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
