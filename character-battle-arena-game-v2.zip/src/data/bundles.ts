import { Bundle } from '../types/game';
import { ALL_CHARACTERS, SECRET_CHARACTER_IDS } from './characters';

export const STORE_BUNDLES: Bundle[] = [
  {
    id: 'bundle_minecraft',
    title: 'Minecraft Universe Bundle',
    description: 'Легендарные персонажи кубического мира: Стив, Хранитель Глубин (Warden) и Дракон Края!',
    characterIds: ['steve', 'warden', 'ender_dragon'],
    originalPrice: 5000,
    discountPrice: 3800,
    bannerColor: 'from-emerald-900 to-teal-950 border-emerald-500',
    badge: 'MINECRAFT'
  },
  {
    id: 'bundle_subnautica',
    title: 'Subnautica Leviathans Bundle',
    description: 'Владыки океанских глубин 4546B: ГИГАНТСКИЙ Левиафан Жнец (18 HP) и МЕГА-КОЛОССАЛЬНЫЙ Левиафан Гаргантюа (30 HP, выходит за карту!) + Сингулярность •!',
    characterIds: ['leviathan', 'gargantua_leviathan', 'the_dot'],
    originalPrice: 34000,
    discountPrice: 25900,
    bannerColor: 'from-cyan-950 via-teal-900 to-blue-950 border-cyan-400',
    badge: 'SUBNAUTICA'
  },
  {
    id: 'bundle_doors',
    title: 'Doors Horror Mega Bundle',
    description: 'Все жуткие сущности отеля Doors: Seek, Figure, Gramble, Screech, Halt и Black Figure!',
    characterIds: ['seek_doors', 'figure_doors', 'gramble_doors', 'screech_doors', 'halt_doors', 'black_figure'],
    originalPrice: 7500,
    discountPrice: 5600,
    bannerColor: 'from-neutral-950 via-red-950 to-neutral-900 border-red-500',
    badge: 'DOORS HORROR'
  },
  {
    id: 'bundle_dr_nowhere',
    title: 'Doctor Nowhere Horror Pack',
    description: 'Сущности аналоговых кошмаров Доктора Ноувхэа: The Locust, The Boiled One и The Guilt!',
    characterIds: ['the_locust', 'the_boiled_one', 'the_guilt_entity'],
    originalPrice: 10600,
    discountPrice: 7900,
    bannerColor: 'from-stone-950 via-red-950 to-zinc-950 border-red-600',
    badge: 'DR. NOWHERE'
  },
  {
    id: 'bundle_slap_legends',
    title: 'Glove & Slap Masters Bundle',
    description: 'Величайшие перчатки: Непобедимый OVERKILL, БОСС Dave с руками, Робот Меха, Bob и Untouchable!',
    characterIds: ['overkill_glove', 'dave', 'robot_user', 'glove_bob', 'untouchable'],
    originalPrice: 49150,
    discountPrice: 36000,
    bannerColor: 'from-amber-950 via-orange-950 to-red-950 border-amber-500',
    badge: 'OVERKILL GLOVES'
  },
  {
    id: 'bundle_undertale',
    title: 'Undertale Souls Trio',
    description: 'Санс с Гастер-бластерами, Чара с решимостью и Фриск со щитом души!',
    characterIds: ['sans', 'chara', 'frisk'],
    originalPrice: 10100,
    discountPrice: 7500,
    bannerColor: 'from-blue-950 via-indigo-950 to-purple-950 border-blue-400',
    badge: 'UNDERTALE'
  },
  {
    id: 'bundle_os_wars',
    title: 'OS Wars System Bundle',
    description: 'Битва операционных систем: Windows User с BSOD, Linux User со скриптом Bash и Comp Head!',
    characterIds: ['windows_user', 'linux_user', 'comp_head'],
    originalPrice: 2500,
    discountPrice: 1850,
    bannerColor: 'from-slate-900 via-sky-950 to-emerald-950 border-sky-400',
    badge: 'OS WARS'
  },
  {
    id: 'bundle_anime_gods',
    title: 'Anime & Cosmic Powers Bundle',
    description: 'Годжо Сатору (Infinity), Канеки (1000-7), Владыка Солнца и Владыка Пустоты!',
    characterIds: ['gojo', 'kaneki_1000_7', 'sun_user', 'void_user', 'dragon_user'],
    originalPrice: 19800,
    discountPrice: 14800,
    bannerColor: 'from-purple-950 via-fuchsia-950 to-indigo-950 border-fuchsia-400',
    badge: 'ANIME POWERS'
  },
  {
    id: 'bundle_gods_admin',
    title: 'Omnipotent Gods & Admin Tier',
    description: 'Абсолютная власть: Бог (God), Админ с бан-хаммером, Гига-Флекс и Читер!',
    characterIds: ['god', 'admin', 'flex', 'cheater'],
    originalPrice: 53000,
    discountPrice: 39000,
    bannerColor: 'from-yellow-950 via-amber-900 to-red-950 border-yellow-400',
    badge: 'GODLY TIER'
  }
];

/** SECRET BUNDLE: все секретные бойцы разом. Цена = сумма их цен минус 10%. */
const SECRET_TOTAL = SECRET_CHARACTER_IDS.reduce(
  (sum, id) => sum + (ALL_CHARACTERS.find(c => c.id === id)?.price || 0),
  0
);

STORE_BUNDLES.push({
  id: 'bundle_secret_vault',
  title: 'SECRET BUNDLE — Хранилище Секретов',
  description: 'Всё секретное сразу: GLITCH, LIGHTING, ULTRAKILL, STELLAR, GOD OF WAR и SWORD GLITCHER. Самый дорогой набор в игре — скидка 10% от суммарной цены.',
  characterIds: [...SECRET_CHARACTER_IDS],
  originalPrice: SECRET_TOTAL,
  discountPrice: Math.round(SECRET_TOTAL * 0.9),
  bannerColor: 'from-fuchsia-950 via-indigo-950 to-cyan-950 border-fuchsia-400',
  badge: 'SECRET VAULT'
});
