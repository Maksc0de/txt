import { CrateTier } from '../types/game';

export const CRATE_TIERS: CrateTier[] = [
  {
    id: 'bronze',
    name: 'Wooden Bronze Crate',
    nameRu: 'Бронзовый Деревянный Ящик',
    cost: 150,
    description: 'Отличный стартовый ящик с базовыми бойцами и монетами!',
    accentColor: '#d97706',
    borderColor: 'border-amber-700',
    rarityWeights: {
      starter: 30,
      common: 45,
      rare: 20,
      epic: 5,
      legendary: 0,
      mythic: 0,
      godly: 0,
      secret: 0,
      boss: 0,
      ultimate: 0
    },
    coinRewardRange: [100, 300]
  },
  {
    id: 'silver',
    name: 'Cyber Gold Crate',
    nameRu: 'Золотой Кибер-Ящик',
    cost: 500,
    description: 'Увеличенный шанс на эпических и легендарных мастеров боя!',
    accentColor: '#eab308',
    borderColor: 'border-yellow-400',
    rarityWeights: {
      starter: 5,
      common: 20,
      rare: 40,
      epic: 25,
      legendary: 9,
      mythic: 1,
      godly: 0,
      secret: 0,
      boss: 0,
      ultimate: 0
    },
    coinRewardRange: [400, 900]
  },
  {
    id: 'gold',
    name: 'Cosmic Diamond Crate',
    nameRu: 'Космический Алмазный Ящик',
    cost: 1500,
    description: 'Премиум ящик с высочайшим шансом на Мифических и Божественных персонажей (OVERKILL, Годжо, Левиафаны)!',
    accentColor: '#38bdf8',
    borderColor: 'border-cyan-400',
    rarityWeights: {
      starter: 0,
      common: 5,
      rare: 20,
      epic: 35,
      legendary: 25,
      mythic: 12,
      godly: 3,
      secret: 0,
      boss: 0,
      ultimate: 0
    },
    coinRewardRange: [1200, 3000]
  }
];
