import { getCharacterById } from '../data/characters';

// Рейд-боссы: hp — НАСТОЯЩЕЕ здоровье босса на арене (именно оно и показывается в полосе).
// charHp — здоровье их играбельной копии, которая открывается за победу.
export const RAID_BOSSES = [
  { id: 'figure_doors', hp: 120, charHp: 9, tier: 'I', title: 'Хранитель библиотеки' },
  { id: 'warden', hp: 200, charHp: 11, tier: 'II', title: 'Голос тёмных глубин' },
  { id: 'the_boiled_one', hp: 260, charHp: 10, tier: 'II', title: 'Неподвижный ужас' },
  { id: 'ender_dragon', hp: 340, charHp: 13, tier: 'III', title: 'Повелитель Края' },
  { id: 'dave', hp: 420, charHp: 15, tier: 'III', title: 'Сокрушительные перчатки' },
  { id: 'grumble', hp: 520, charHp: 16, tier: 'IV', title: 'Властелин подземелья' },
  { id: 'overkill_glove', hp: 620, charHp: 14, tier: 'IV', title: 'Пылающий приговор' },
  { id: 'leviathan', hp: 700, charHp: 18, tier: 'V', title: 'Хищник бездны' },
  { id: 'eclipse_boss', hp: 850, charHp: 30, tier: 'VI', title: 'Пожиратель света' },
  { id: 'gargantua_leviathan', hp: 900, charHp: 26, tier: 'VII', title: 'Древний колосс' },
  { id: 'volcanic_ash', hp: 1000, charHp: 35, tier: 'VIII', title: 'Сердце погасшего вулкана' },
  { id: 'war_lord_omega', hp: 2400, charHp: 0, tier: 'IX', title: 'Падший Абсолют (персонаж НЕ выдаётся)' },
] as const;

export type RaidBoss = { id: string; hp: number; charHp: number; tier: string; title: string };

export const RAID_BOSS_LIST: RaidBoss[] = RAID_BOSSES.map(b => ({ ...b }));

export function isRaidBoss(id: string): boolean {
  return RAID_BOSSES.some(b => b.id === id);
}

export function bossBaseHp(id: string): number {
  return RAID_BOSSES.find(b => b.id === id)?.hp ?? Math.max(80, getCharacterById(id).maxHp * 12);
}

/** Множитель здоровья босса от числа игроков: 1 игрок = x1, 2 игрока = x1.9. */
export function raidScale(players: number): number {
  return players >= 2 ? 1.9 : 1;
}

export function bossHealth(id: string, players = 1): number {
  return Math.round(bossBaseHp(id) * raidScale(players));
}

/**
 * Рейдовый пробой брони игрока. Он ВИДИМЫЙ: значение показывается в HUD,
 * поэтому полоса HP босса всегда отражает настоящий урон и настоящее здоровье.
 */
export function raidDamageBonus(bossId: string): number {
  return Math.max(2, Math.round(bossBaseHp(bossId) / 90));
}
