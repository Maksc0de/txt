import { useState, useEffect, useCallback } from 'react';
import { PlayerProgress, GameSettings, GameMode } from '../types/game';
import { ALL_CHARACTERS, STARTER_CHARACTER_IDS } from '../data/characters';
import { STORE_BUNDLES } from '../data/bundles';
import { soundManager } from '../audio/soundManager';

const STORAGE_KEY = 'arena_game_save_v1';

export interface NetworkProgress {
  matchId: string;
  characterId: string;
  mode: GameMode;
  kills: number;
  waves: number;
  damage: number;
  coins: number;
  finished: boolean;
  won: boolean;
}

const DEFAULT_SETTINGS: GameSettings = {
  soundVolume: 0.7,
  musicEnabled: true,
  screenShake: true,
  particleDensity: 'high',
  dynamicArenaZoom: true,
  showHitboxes: false,
  touchControls: false,
  bgTheme: 'cosmic'
};

const DEFAULT_SAVE: PlayerProgress = {
  coins: 350, // Starting bonus coins
  unlockedCharacters: [...STARTER_CHARACTER_IDS],
  selectedPlayerCharId: 'steve',
  selectedBotCharId: 'sword_master',
  matchesPlayed: 0,
  wins: 0,
  losses: 0,
  highestWinStreak: 0,
  currentWinStreak: 0,
  favoriteCharacter: 'steve',
  openedCrates: 0,
  secretDlcActivationsLeft: 100, // 100 activations left for user's personal secret DLC code
  hasUsedMasterDlc: false,
  settings: DEFAULT_SETTINGS,
  gojoDamage: 0,
  gojoWins: 0,
  gojoAscended: false,
  totalKills: 0,
  totalWaves: 0,
  overkillMastery: false,
  defeatedBosses: [],
  masteries: {
    lighting: { abilities: 0, distance: 0, kills: 0, unlocked: false },
    hahaha: { abilities: 0, survive: 0, secret: 0, unlocked: false },
  },
  masteryToggle: { gojo: true, overkill: true, lighting: true, hahaha: true },
  daily: {
    day: todayStr(), claimed: false, streak: 0, lastClaimDay: '',
    quests: { wins: 0, matches: 0, crates: 0, claimed: {} }, allQuestsDays: 0, freeHeroClaimed: false,
  },
  bundleRotation: { window: bundleWindow(), ids: defaultBundlePick() }
};

// Окно ротации бандлов — меняется каждые 4 дня.
function bundleWindow(): string {
  return String(Math.floor(Date.now() / (4 * 86400000)));
}
function defaultBundlePick(): string[] {
  const pool = STORE_BUNDLES.map(b => b.id);
  const picked: string[] = [];
  while (picked.length < 3 && pool.length) {
    const idx = Math.floor(Math.random() * pool.length);
    picked.push(pool.splice(idx, 1)[0]);
  }
  return picked;
}

// Локальная дата для ежедневных наград/квестов.
export function todayStr(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

// Пороговые значения пробуждения Годжо (3 квеста — достижимые)
export const GOJO_QUESTS = {
  damageRequired: 300,
  winsRequired: 5,
  cratesRequired: 3
};

// Мастери OVERKILL (3 ОЧЕНЬ сложных квеста, накапливаются между играми)
export const OVERKILL_QUESTS = {
  killsRequired: 1000,
  winsRequired: 99,
  wavesRequired: 1000
};

// --- Ежедневные награды и квесты ---
export const DAILY_QUESTS = [
  { id: 'win', goal: 1, reward: 120, label: 'Одержи 1 победу' },
  { id: 'match', goal: 2, reward: 90, label: 'Сыграй 2 матча' },
  { id: 'crate', goal: 1, reward: 140, label: 'Открой 1 ящик' },
];
export const ALL_QUESTS_BONUS = 200;
// Скромная ежедневная лесенка (не щедрая).
export const DAILY_REWARDS = [100, 110, 125, 140, 160, 180, 220];
// Персонаж, который дарится за «полные» квест-дни.
export const FREE_HERO_POOL = ['kid', 'ping_master', 'game_bug', 'boom_bomb', 'spamer', 'number_67', 'spectate', 'dual_user'];
export const FREE_HERO_NEED_DAYS = 3;

function freshDaily() {
  return {
    day: todayStr(), claimed: false, streak: 0, lastClaimDay: '',
    quests: { wins: 0, matches: 0, crates: 0, claimed: {} }, allQuestsDays: 0, freeHeroClaimed: false,
  };
}
function normalizeDaily(daily: PlayerProgress['daily']): PlayerProgress['daily'] {
  if (daily.day !== todayStr()) return { ...freshDaily(), streak: daily.streak, allQuestsDays: daily.allQuestsDays, freeHeroClaimed: daily.freeHeroClaimed };
  return daily;
}
function addDays(dateStr: string, n: number): string {
  const d = new Date(dateStr + 'T12:00:00');
  d.setDate(d.getDate() + n);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

export const useGameSave = () => {
  const [save, setSave] = useState<PlayerProgress>(() => {
    if (typeof window === 'undefined') return DEFAULT_SAVE;
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        // Ensure all starter characters are always present
        const mergedUnlocked = Array.from(new Set([...STARTER_CHARACTER_IDS, ...(parsed.unlockedCharacters || [])]));
        return {
          ...DEFAULT_SAVE,
          ...parsed,
          unlockedCharacters: mergedUnlocked,
          settings: {
            ...DEFAULT_SETTINGS,
            ...(parsed.settings || {})
          },
          // Глубокий мерж новых полей, чтобы старые сохранения не ломались.
          daily: { ...DEFAULT_SAVE.daily, ...(parsed.daily || {}) },
          masteries: {
            ...DEFAULT_SAVE.masteries,
            ...(parsed.masteries || {}),
            lighting: { ...DEFAULT_SAVE.masteries.lighting, ...((parsed.masteries || {}).lighting || {}) },
            hahaha: { ...DEFAULT_SAVE.masteries.hahaha, ...((parsed.masteries || {}).hahaha || {}) },
          },
          masteryToggle: { ...DEFAULT_SAVE.masteryToggle, ...(parsed.masteryToggle || {}) },
          bundleRotation: parsed.bundleRotation || DEFAULT_SAVE.bundleRotation,
        };
      }
    } catch {
      // Fallback
    }
    return DEFAULT_SAVE;
  });

  // Ротация бандлов: автоматически пересоздаёт 3 набора при наступлении нового 4-дневного окна.
  useEffect(() => {
    const win = bundleWindow();
    if (save.bundleRotation.window !== win) {
      setSave(prev => ({ ...prev, bundleRotation: { window: win, ids: defaultBundlePick() } }));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [save.bundleRotation.window]);

  // Сбросить ротацию вручную (для теста/по требованию).
  const rerollBundles = useCallback(() => {
    setSave(prev => ({ ...prev, bundleRotation: { window: bundleWindow(), ids: defaultBundlePick() } }));
  }, []);

  // Save to localStorage whenever state changes
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(save));
    } catch {
      // Ignore quota errors
    }
    // Update audio manager settings
    soundManager.setVolume(save.settings.soundVolume);
  }, [save]);

  const updateSettings = useCallback((newSettings: Partial<GameSettings>) => {
    setSave(prev => ({
      ...prev,
      settings: {
        ...prev.settings,
        ...newSettings
      }
    }));
  }, []);

  const addCoins = useCallback((amount: number) => {
    setSave(prev => ({
      ...prev,
      coins: Math.max(0, prev.coins + amount)
    }));
  }, []);

  const selectPlayerCharacter = useCallback((id: string) => {
    setSave(prev => ({
      ...prev,
      selectedPlayerCharId: id,
      favoriteCharacter: id
    }));
  }, []);

  const selectBotCharacter = useCallback((id: string) => {
    setSave(prev => ({
      ...prev,
      selectedBotCharId: id
    }));
  }, []);

  const unlockCharacter = useCallback((id: string, cost: number = 0): boolean => {
    let success = false;
    setSave(prev => {
      if (prev.unlockedCharacters.includes(id)) return prev;
      if (prev.coins < cost) return prev;
      success = true;
      return {
        ...prev,
        coins: prev.coins - cost,
        unlockedCharacters: [...prev.unlockedCharacters, id]
      };
    });
    return success;
  }, []);

  const unlockMultipleCharacters = useCallback((ids: string[], totalCost: number): boolean => {
    let success = false;
    setSave(prev => {
      if (prev.coins < totalCost) return prev;
      success = true;
      const combined = Array.from(new Set([...prev.unlockedCharacters, ...ids]));
      return {
        ...prev,
        coins: prev.coins - totalCost,
        unlockedCharacters: combined
      };
    });
    return success;
  }, []);

  // kills — убийства за матч (бот = 1, Endless = число волн), waves — пройденные волны Endless
  const recordMatchResult = useCallback((won: boolean, coinsEarned: number, kills: number = 0, waves: number = 0) => {
    setSave(prev => {
      const daily = normalizeDaily(prev.daily);
      daily.quests.matches += 1;
      if (won) daily.quests.wins += 1;
      const newWins = won ? prev.wins + 1 : prev.wins;
      const newLosses = won ? prev.losses : prev.losses + 1;
      const newStreak = won ? prev.currentWinStreak + 1 : 0;
      const newHighStreak = Math.max(prev.highestWinStreak, newStreak);
      const totalKills = (prev.totalKills || 0) + kills;
      const totalWaves = (prev.totalWaves || 0) + waves;
      const mastery =
        prev.overkillMastery ||
        (totalKills >= OVERKILL_QUESTS.killsRequired &&
          newWins >= OVERKILL_QUESTS.winsRequired &&
          totalWaves >= OVERKILL_QUESTS.wavesRequired);

      return {
        ...prev,
        coins: prev.coins + coinsEarned,
        matchesPlayed: prev.matchesPlayed + 1,
        wins: newWins,
        losses: newLosses,
        currentWinStreak: newStreak,
        highestWinStreak: newHighStreak,
        totalKills,
        totalWaves,
        overkillMastery: mastery,
        daily
      };
    });
  }, []);

  const recordCrateOpen = useCallback(() => {
    setSave(prev => {
      const daily = normalizeDaily(prev.daily);
      daily.quests.crates += 1;
      return { ...prev, openedCrates: prev.openedCrates + 1, daily };
    });
  }, []);

  // Победа над боссом открывает его как играбельного персонажа.
  const recordDefeatedBoss = useCallback((bossId: string) => {
    setSave(prev => ({
      ...prev,
      defeatedBosses: prev.defeatedBosses.includes(bossId) ? prev.defeatedBosses : [...prev.defeatedBosses, bossId],
      unlockedCharacters: prev.unlockedCharacters.includes(bossId) ? prev.unlockedCharacters : [...prev.unlockedCharacters, bossId],
    }));
  }, []);

  // Накопление прогресса мастери (Lighting: способности/дистанция/убийства; hahaha: способности/выживание/секрет).
  const recordMasteryProgress = useCallback((progress: {
    lightingAbilities?: number; lightingDistance?: number; lightingKills?: number;
    hahahaAbilities?: number; hahahaSurvive?: number; hahahaSecret?: number;
  }) => {
    setSave(prev => {
      const lighting = prev.masteries.lighting;
      const hahaha = prev.masteries.hahaha;
      const newLightingAbilities = lighting.abilities + (progress.lightingAbilities || 0);
      const newLightingDistance = lighting.distance + (progress.lightingDistance || 0);
      const newLightingKills = lighting.kills + (progress.lightingKills || 0);
      const newHahahaAbilities = hahaha.abilities + (progress.hahahaAbilities || 0);
      const newHahahaSurvive = hahaha.survive + (progress.hahahaSurvive || 0);
      const newHahahaSecret = hahaha.secret + (progress.hahahaSecret || 0);
      return {
        ...prev,
        masteries: {
          lighting: {
            abilities: newLightingAbilities,
            distance: Math.round(newLightingDistance * 100) / 100,
            kills: newLightingKills,
            unlocked: lighting.unlocked || (newLightingAbilities >= 150 && newLightingDistance >= 10 && newLightingKills >= 100),
          },
          hahaha: {
            abilities: newHahahaAbilities,
            survive: Math.round(newHahahaSurvive * 100) / 100,
            secret: newHahahaSecret,
            unlocked: hahaha.unlocked || (newHahahaAbilities >= 50 && newHahahaSurvive >= 25 && newHahahaSecret >= 1),
          },
        },
      };
    });
  }, []);

  // Cumulative checkpoints prevent duplicate rewards and retain waves on disconnect.
  const recordNetworkProgress = useCallback((progress: NetworkProgress) => {
    if (progress.mode === 'training') return;
    setSave(prev => {
      const runs = prev.networkRuns || {};
      const old = runs[progress.matchId] || { kills: 0, waves: 0, damage: 0, coins: 0, finished: false };
      if (old.finished) return prev;
      const next = {
        kills: Math.max(old.kills, progress.kills), waves: Math.max(old.waves, progress.waves),
        damage: Math.max(old.damage, Math.round(progress.damage)), coins: Math.max(old.coins, progress.coins), finished: progress.finished,
      };
      if (next.kills === old.kills && next.waves === old.waves && next.damage === old.damage && next.coins === old.coins && next.finished === old.finished) return prev;
      const totalKills = (prev.totalKills || 0) + next.kills - old.kills;
      const totalWaves = (prev.totalWaves || 0) + next.waves - old.waves;
      const won = progress.finished && progress.won;
      const wins = prev.wins + Number(won);
      const gojoDamage = (prev.gojoDamage || 0) + (progress.characterId === 'gojo' ? next.damage - old.damage : 0);
      const gojoWins = (prev.gojoWins || 0) + Number(progress.characterId === 'gojo' && won);
      const streak = progress.finished ? won ? prev.currentWinStreak + 1 : 0 : prev.currentWinStreak;
      return {
        ...prev,
        coins: prev.coins + next.coins - old.coins, totalKills, totalWaves,
        wins, losses: prev.losses + Number(progress.finished && !progress.won),
        matchesPlayed: prev.matchesPlayed + Number(progress.finished),
        currentWinStreak: streak, highestWinStreak: Math.max(prev.highestWinStreak, streak),
        gojoDamage, gojoWins,
        gojoAscended: prev.gojoAscended || (gojoDamage >= GOJO_QUESTS.damageRequired && gojoWins >= GOJO_QUESTS.winsRequired && prev.openedCrates >= GOJO_QUESTS.cratesRequired),
        overkillMastery: prev.overkillMastery || (totalKills >= OVERKILL_QUESTS.killsRequired && wins >= OVERKILL_QUESTS.winsRequired && totalWaves >= OVERKILL_QUESTS.wavesRequired),
        networkRuns: { ...Object.fromEntries(Object.entries(runs).slice(-39)), [progress.matchId]: next },
      };
    });
  }, []);

  // Забрать ежедневную награду. Возвращает сколько монет получено.
  const claimDaily = useCallback((): { coins: number; freeHero?: string } => {
    const today = todayStr();
    const result: { coins: number; freeHero?: string } = { coins: 0 };
    setSave(prev => {
      if (prev.daily.day === today && prev.daily.claimed) return prev;
      const yesterday = addDays(today, -1);
      const sameOrConsecutive = prev.daily.day === today || prev.daily.day === yesterday || !prev.daily.lastClaimDay;
      const streak = sameOrConsecutive ? prev.daily.streak + 1 : 1;
      const reward = DAILY_REWARDS[(streak - 1) % DAILY_REWARDS.length];
      result.coins = reward;
      let freeHero: string | undefined;
      // На 7-й подряд день — скромный подарок персонажем.
      if (streak % 7 === 0) {
        freeHero = FREE_HERO_POOL.find(id => !prev.unlockedCharacters.includes(id));
      }
      result.freeHero = freeHero;
      return {
        ...prev,
        coins: prev.coins + reward,
        unlockedCharacters: freeHero ? [...prev.unlockedCharacters, freeHero] : prev.unlockedCharacters,
        daily: {
          ...prev.daily, day: today, claimed: true, streak, lastClaimDay: today,
        },
      };
    });
    return result;
  }, []);

  // Забрать награду за ежедневный квест.
  const claimDailyQuest = useCallback((questId: string): { coins: number } => {
    const result: { coins: number } = { coins: 0 };
    setSave(prev => {
      const daily = normalizeDaily(prev.daily);
      if (daily.quests.claimed[questId]) return prev;
      const quest = DAILY_QUESTS.find(q => q.id === questId);
      if (!quest) return prev;
      const goalMet = questId === 'win' ? daily.quests.wins >= quest.goal
        : questId === 'match' ? daily.quests.matches >= quest.goal
        : daily.quests.crates >= quest.goal;
      if (!goalMet) return prev;
      result.coins = quest.reward;
      const claimed = { ...daily.quests.claimed, [questId]: true };
      // Бонус за выполнение всех трёх квестов дня.
      let allDone = DAILY_QUESTS.every(q => claimed[q.id]);
      let allQuestsDays = daily.allQuestsDays;
      let freeHero: string | undefined;
      if (allDone) {
        result.coins += ALL_QUESTS_BONUS;
        allQuestsDays += 1;
        // Первый персонаж за квесты: после N «полных» дней.
        if (!daily.freeHeroClaimed && allQuestsDays >= FREE_HERO_NEED_DAYS) {
          freeHero = FREE_HERO_POOL.find(id => !prev.unlockedCharacters.includes(id));
          if (freeHero) { daily.freeHeroClaimed = true; result.coins += 0; }
        }
      }
      return {
        ...prev,
        coins: prev.coins + result.coins,
        unlockedCharacters: freeHero ? [...prev.unlockedCharacters, freeHero] : prev.unlockedCharacters,
        daily: { ...daily, quests: { ...daily.quests, claimed }, allQuestsDays, freeHeroClaimed: daily.freeHeroClaimed },
      };
    });
    return result;
  }, []);

  // Включение/выключение мастери (прогресс сохраняется).
  const setMasteryToggle = useCallback((key: 'lighting' | 'hahaha', value: boolean) => {
    setSave(prev => ({ ...prev, masteryToggle: { ...prev.masteryToggle, [key]: value } }));
  }, []);

  // Квесты Годжо: учёт урона и побед при игре за Годжо — 3 квеста открывают Hollow Purple и Infinity Void
  const updateGojoStats = useCallback((damageDealt: number, wonMatch: boolean) => {
    setSave(prev => {
      const gojoDamage = prev.gojoDamage + Math.round(damageDealt);
      const gojoWins = prev.gojoWins + (wonMatch ? 1 : 0);
      const ascended =
        gojoDamage >= GOJO_QUESTS.damageRequired &&
        gojoWins >= GOJO_QUESTS.winsRequired &&
        prev.openedCrates >= GOJO_QUESTS.cratesRequired;
      return { ...prev, gojoDamage, gojoWins, gojoAscended: prev.gojoAscended || ascended };
    });
  }, []);

  // Redeem Promo & DLC Codes
  const redeemCode = useCallback((rawCode: string): { success: boolean; message: string; coinsAdded?: number } => {
    const code = rawCode.trim().toUpperCase();
    if (!code) return { success: false, message: 'Введите код!' };

    // Master DLC (private). Старые варианты кода отключены — действует только новый.
    // Действуют и новый мастер-код, и старые варианты.
    if (code === 'OMEGA-FINAL-MASTERY-∞' || code === 'OMEGA-FINAL-MASTERY-INF' || code === 'OMEGA-FINAL-MASTERY-8'
      || code === 'DEV-GOD-INFINITY-71' || code === 'ADMIN-SECRET-DLC-2026' || code === 'GIGA-GOD-MASTER-71') {
      let result: { success: boolean; message: string; coinsAdded?: number } = { success: false, message: '' };
      setSave(prev => {
        if (prev.secretDlcActivationsLeft <= 0) {
          result = { success: false, message: 'Лимит активаций этого кода исчерпан (0/100)!' };
          return prev;
        }

        const allCharIds = ALL_CHARACTERS.map(c => c.id);
        const remainingActivations = prev.secretDlcActivationsLeft - 1;

        result = {
          success: true,
          message: `MASTER DLC АКТИВИРОВАН! Открыты ВСЕ персонажи, ВСЕ боссы и ВСЕ мастери (Годжо, OVERKILL, LIGHTING GOD, HAHAHA) и +999,999 монет! (Осталось активаций: ${remainingActivations})`,
          coinsAdded: 999999
        };

        return {
          ...prev,
          coins: prev.coins + 999999,
          unlockedCharacters: allCharIds,
          secretDlcActivationsLeft: remainingActivations,
          hasUsedMasterDlc: true,
          // Все мастери — выполнены
          gojoAscended: true,
          gojoDamage: Math.max(prev.gojoDamage, GOJO_QUESTS.damageRequired),
          gojoWins: Math.max(prev.gojoWins, GOJO_QUESTS.winsRequired),
          openedCrates: Math.max(prev.openedCrates, GOJO_QUESTS.cratesRequired),
          overkillMastery: true,
          totalKills: Math.max(prev.totalKills || 0, OVERKILL_QUESTS.killsRequired),
          totalWaves: Math.max(prev.totalWaves || 0, OVERKILL_QUESTS.wavesRequired),
          wins: Math.max(prev.wins, OVERKILL_QUESTS.winsRequired),
          // Мастери Lighting и hahaha — выполнены.
          masteries: {
            lighting: { abilities: 150, distance: 10, kills: 100, unlocked: true },
            hahaha: { abilities: 50, survive: 25, secret: 1, unlocked: true },
          },
          masteryToggle: { gojo: true, overkill: true, lighting: true, hahaha: true },
          // Все боссы открыты.
          defeatedBosses: Array.from(new Set([...prev.defeatedBosses, 'figure_doors', 'dave', 'volcanic_ash', 'warden', 'the_boiled_one', 'ender_dragon', 'grumble', 'overkill_glove', 'leviathan', 'gargantua_leviathan', 'eclipse_boss']))
        };
      });
      return result;
    }

    // Public Bonus Promo Codes
    if (code === 'FREE-COINS' || code === 'ARENA2026') {
      addCoins(500);
      return { success: true, message: 'Промокод принят! +500 монет начислено!', coinsAdded: 500 };
    }

    if (code === 'STARTER-PACK') {
      addCoins(1000);
      return { success: true, message: 'Стартовый набор активирован! +1000 монет!', coinsAdded: 1000 };
    }

    if (code === 'SLAP-ARENA') {
      addCoins(750);
      return { success: true, message: 'Бонус арены! +750 монет!', coinsAdded: 750 };
    }

    return { success: false, message: 'Неверный код или срок действия истек.' };
  }, [addCoins]);

  const resetAllProgress = useCallback(() => {
    setSave({
      ...DEFAULT_SAVE,
      unlockedCharacters: [...STARTER_CHARACTER_IDS]
    });
    localStorage.removeItem(STORAGE_KEY);
  }, []);

  return {
    save,
    updateSettings,
    addCoins,
    selectPlayerCharacter,
    selectBotCharacter,
    unlockCharacter,
    unlockMultipleCharacters,
    recordMatchResult,
    recordCrateOpen,
    recordNetworkProgress,
    recordDefeatedBoss,
    recordMasteryProgress,
    setMasteryToggle,
    claimDaily,
    claimDailyQuest,
    rerollBundles,
    updateGojoStats,
    redeemCode,
    resetAllProgress
  };
};
