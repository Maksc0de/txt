import { useState, useMemo, useCallback } from 'react';
import { GameMode, EndlessSubmode, Character } from './types/game';
import { getCharacterById, ALL_CHARACTERS } from './data/characters';
import { useGameSave } from './hooks/useGameSave';
import { MainMenu } from './components/Menu/MainMenu';
import { CharacterSelect } from './components/Selection/CharacterSelect';
import { ShopModal } from './components/Shop/ShopModal';
import { SettingsModal } from './components/Settings/SettingsModal';
import { GameCanvas } from './components/Arena/GameCanvas';
import { LocalBossRaid } from './components/Arena/LocalBossRaid';
import { VictoryModal } from './components/Modals/VictoryModal';
import { soundManager } from './audio/soundManager';
import { ArrowLeft, Pause, Play } from 'lucide-react';
import { RAID_BOSSES } from './game/raidRules';

type ScreenState = 'menu' | 'select' | 'shop' | 'settings' | 'game';

export default function App() {
  const {
    save,
    updateSettings,
    addCoins,
    selectPlayerCharacter,
    selectBotCharacter,
    unlockCharacter,
    unlockMultipleCharacters,
    recordMatchResult,
    recordCrateOpen,
    updateGojoStats,
    redeemCode,
    resetAllProgress,
    recordDefeatedBoss,
    recordMasteryProgress,
    setMasteryToggle,
    claimDaily,
    claimDailyQuest,
  } = useGameSave();

  const [currentScreen, setCurrentScreen] = useState<ScreenState>('menu');
  const [currentMode, setCurrentMode] = useState<GameMode>('standard');
  const [endlessSubmode, setEndlessSubmode] = useState<EndlessSubmode>('standard');
  const [matchResult, setMatchResult] = useState<{
    winner: 'player' | 'bot' | 'p2';
    coinsEarned: number;
    stats: { hits: number; damage: number };
    kills?: number;
  } | null>(null);
  const [isGamePaused, setIsGamePaused] = useState<boolean>(false);
  const [gameKey, setGameKey] = useState<number>(0);
  const [teamSize, setTeamSize] = useState<1 | 2>(1);
  const [raidBossId, setRaidBossId] = useState(() => RAID_BOSSES.some(b => b.id === save.selectedBotCharId) ? save.selectedBotCharId : 'figure_doors');
  const [raidFriendId, setRaidFriendId] = useState(() => {
    const candidate = ALL_CHARACTERS.find(c => c.id !== save.selectedPlayerCharId && c.id !== 'volcanic_ash' && save.unlockedCharacters.includes(c.id));
    return candidate?.id || 'steve';
  });
  const [localRaid, setLocalRaid] = useState<{ heroes: Character[]; names: string[]; boss: Character } | null>(null);
  const [raidKey, setRaidKey] = useState(0);

  // Active characters
  const playerChar = useMemo(() => getCharacterById(save.selectedPlayerCharId === 'volcanic_ash' ? 'steve' : save.selectedPlayerCharId), [save.selectedPlayerCharId]);

  const botChar = useMemo(() => {
    if (currentMode === 'boss_raid') return getCharacterById(raidBossId);
    return getCharacterById(save.selectedBotCharId);
  }, [save.selectedBotCharId, currentMode, raidBossId]);
  const raidFriendChar = useMemo(() => getCharacterById(raidFriendId), [raidFriendId]);

  const handleMatchEnd = useCallback((winner: 'player' | 'bot' | 'p2', stats: { hits: number; damage: number; kills?: number; duration?: number }) => {
    // В локальном мультиплеере (два игрока) результат дуэли друзей не влияет на прогресс.
    if (currentMode === 'two_player') {
      setMatchResult({ winner, coinsEarned: 0, stats: { hits: stats.hits, damage: stats.damage }, kills: undefined });
      return;
    }
    const isPlayerWin = winner === 'player';
    const isEndless = currentMode === 'endless';
    const kills = stats.kills || 0;

    // ЗАЩИТА ОТ ФАРМА: мгновенные победы не засчитываются и не приносят монет.
    const duration = stats.duration || 0;
    const tooFast = duration < (currentMode === 'final_health' ? 4 : 2.5);
    if (tooFast && isPlayerWin) {
      setMatchResult(null);
      setIsGamePaused(false);
      setGameKey(prev => prev + 1); // Перезапуск без записи результата и наград.
      return;
    }
    const baseCoins = isPlayerWin ? (currentMode === 'final_health' ? 150 : 120) : 35;
    const streakBonus = isPlayerWin ? Math.min(100, save.currentWinStreak * 15) : 0;
    const endlessBonus = isEndless ? Math.round(kills * 30 * (endlessSubmode === 'last' ? 1.5 : 1)) : 0;
    const totalCoinsEarned = baseCoins + streakBonus + endlessBonus;

    const killsThisMatch = isEndless ? kills : isPlayerWin ? 1 : 0;
    recordMatchResult(isPlayerWin, totalCoinsEarned, killsThisMatch, isEndless ? kills : 0);
    if (playerChar.id === 'gojo') updateGojoStats(stats.damage, isPlayerWin);

    // Boss Raid victory unlocks the defeated boss as a playable character —
    // КРОМЕ War Lord Omega: это финальный босс без награды-персонажа.
    if (currentMode === 'boss_raid' && isPlayerWin) {
      recordDefeatedBoss(raidBossId);
      if (raidBossId !== 'war_lord_omega') unlockCharacter(raidBossId, 0);
    }

    setMatchResult({ winner, coinsEarned: totalCoinsEarned, stats: { hits: stats.hits, damage: stats.damage }, kills });
  }, [currentMode, recordMatchResult, save.currentWinStreak, endlessSubmode, playerChar.id, updateGojoStats, raidBossId, recordDefeatedBoss, unlockCharacter]);

  const handlePlayAgain = () => {
    setMatchResult(null);
    setIsGamePaused(false);
    setGameKey(prev => prev + 1);
  };

  const startGameFlow = () => {
    // Локальный мультиплеер доступен только в Boss Raid.
    if (currentMode === 'boss_raid' && teamSize === 2) { startLocalRaid(); return; }
    startRaidSolo();
  };

  const bgTheme = save.settings.bgTheme || 'cosmic';
  const bgThemeClasses: Record<string, string> = {
    cosmic: 'bg-slate-950',
    abyss: 'bg-gradient-to-b from-slate-950 via-sky-950 to-cyan-950',
    sunset: 'bg-gradient-to-b from-orange-950 via-rose-950 to-slate-950',
    candy: 'bg-gradient-to-b from-fuchsia-950 via-pink-950 to-purple-950',
    matrix: 'bg-gradient-to-b from-slate-950 via-emerald-950 to-green-950',
    volcano: 'bg-gradient-to-b from-red-950 via-orange-950 to-stone-950',
  };

  const changeBoss = (id: string) => {
    setRaidBossId(id);
    if (save.unlockedCharacters.includes(id)) selectBotCharacter(id);
  };

  const changeMode = (mode: GameMode) => {
    setCurrentMode(mode);
    if (mode !== 'boss_raid') setTeamSize(1);
  };

  const startRaidSolo = () => {
    setMatchResult(null);
    setIsGamePaused(false);
    setGameKey(prev => prev + 1);
    setCurrentScreen('game');
  };

  const startLocalRaid = () => {
    if (currentMode !== 'boss_raid') return;
    const friend = raidFriendChar.id === playerChar.id
      ? ALL_CHARACTERS.find(c => c.id !== playerChar.id && c.id !== 'volcanic_ash' && save.unlockedCharacters.includes(c.id)) || getCharacterById('steve')
      : raidFriendChar;
    setLocalRaid({ heroes: [playerChar, friend], names: ['ТЫ', 'ДРУГ'], boss: getCharacterById(raidBossId) });
  };

  if (localRaid) {
    return <LocalBossRaid
      key={raidKey}
      heroes={localRaid.heroes}
      heroNames={localRaid.names}
      boss={localRaid.boss}
      onWin={() => {
        recordDefeatedBoss(localRaid.boss.id);
        if (localRaid.boss.id !== 'war_lord_omega') unlockCharacter(localRaid.boss.id, 0);
      }}
      onExit={() => { setLocalRaid(null); setCurrentScreen('menu'); }}
      onRematch={() => setRaidKey(k => k + 1)}
    />;
  }

  return (
    <div className={`w-screen h-screen ${bgThemeClasses[bgTheme]} text-white flex flex-col select-none overflow-hidden font-sans`}>
      {/* 1. MAIN MENU SCREEN */}
      {currentScreen === 'menu' && (
        <MainMenu
          save={save}
          selectedPlayerChar={playerChar}
          selectedBotChar={botChar}
          currentMode={currentMode}
          endlessSubmode={endlessSubmode}
          onChangeEndlessSubmode={setEndlessSubmode}
          onChangeMode={changeMode}
          onChangeBoss={changeBoss}
          selectedFriendChar={raidFriendChar}
          onChangeFriend={setRaidFriendId}
          teamSize={teamSize}
          onTeamSize={setTeamSize}
          onStartGame={startGameFlow}
          onOpenCharacterSelect={() => setCurrentScreen('select')}
          onOpenShop={() => setCurrentScreen('shop')}
          onOpenCrates={() => setCurrentScreen('shop')}
          onOpenSettings={() => setCurrentScreen('settings')}
          onOpenBosses={() => setCurrentScreen('select')}
          onClaimDaily={claimDaily}
          onClaimDailyQuest={claimDailyQuest}
        />
      )}

      {/* 2. CHARACTER SELECTION SCREEN */}
      {currentScreen === 'select' && (
        <CharacterSelect
          unlockedCharacterIds={save.unlockedCharacters}
          selectedPlayerCharId={save.selectedPlayerCharId}
          selectedBotCharId={save.selectedBotCharId}
          userCoins={save.coins}
          gojoQuest={{
            damage: save.gojoDamage, wins: save.gojoWins, crates: save.openedCrates, ascended: save.gojoAscended,
          }}
          overkillQuest={{
            kills: save.totalKills || 0, wins: save.wins, waves: save.totalWaves || 0, mastery: save.overkillMastery,
          }}
          lightingQuest={{
            kills: save.masteries.lighting.kills,
            distance: save.masteries.lighting.distance,
            abilities: save.masteries.lighting.abilities,
            unlocked: save.masteries.lighting.unlocked,
            enabled: save.masteryToggle.lighting,
          }}
          hahahaQuest={{
            abilities: save.masteries.hahaha.abilities,
            survive: save.masteries.hahaha.survive,
            secret: save.masteries.hahaha.secret,
            unlocked: save.masteries.hahaha.unlocked,
            enabled: save.masteryToggle.hahaha,
          }}
          onToggleMastery={setMasteryToggle}
          onSelectPlayer={id => selectPlayerCharacter(id)}
          onSelectBot={id => selectBotCharacter(id)}
          onUnlockCharacter={(id, cost) => unlockCharacter(id, cost)}
          onBackToMenu={() => setCurrentScreen('menu')}
          onGoToShop={() => setCurrentScreen('shop')}
        />
      )}

      {/* 3. SHOP & CRATES SCREEN */}
      {currentScreen === 'shop' && (
        <ShopModal
          unlockedCharacterIds={save.unlockedCharacters}
          userCoins={save.coins}
          onUnlockCharacter={(id, cost) => unlockCharacter(id, cost)}
          onUnlockMultiple={(ids, cost) => unlockMultipleCharacters(ids, cost)}
          onAddCoins={amount => addCoins(amount)}
          onRecordCrateOpen={() => recordCrateOpen()}
          activeBundleIds={save.bundleRotation.ids}
          onClose={() => setCurrentScreen('menu')}
          onOpenPromoModal={() => setCurrentScreen('settings')}
        />
      )}

      {/* 4. SETTINGS & DLC CODE SCREEN */}
      {currentScreen === 'settings' && (
        <SettingsModal
          settings={save.settings}
          onUpdateSettings={newSettings => updateSettings(newSettings)}
          onRedeemCode={code => redeemCode(code)}
          onResetProgress={() => resetAllProgress()}
          onClose={() => setCurrentScreen('menu')}
        />
      )}

      {/* 5. GAME COMBAT ARENA SCREEN */}
      {currentScreen === 'game' && (
        <div className="relative w-full h-full flex flex-col bg-slate-950">
          <div className="absolute top-3 left-4 z-40 flex items-center gap-2 pointer-events-auto">
            <button onClick={() => { soundManager.playClick(); setCurrentScreen('menu'); }} className="p-2 rounded-xl bg-slate-900/85 hover:bg-slate-800 border border-slate-700 text-slate-300 hover:text-white transition-all cursor-pointer shadow-lg" title="Выйти в меню"><ArrowLeft className="w-5 h-5" /></button>
            <button onClick={() => { soundManager.playClick(); setIsGamePaused(!isGamePaused); }} className="p-2 rounded-xl bg-slate-900/85 hover:bg-slate-800 border border-slate-700 text-slate-300 hover:text-white transition-all cursor-pointer shadow-lg" title={isGamePaused ? 'Продолжить' : 'Пауза'}>{isGamePaused ? <Play className="w-5 h-5 text-emerald-400" /> : <Pause className="w-5 h-5 text-amber-400" />}</button>
          </div>

          {isGamePaused && !matchResult && (
            <div className="absolute inset-0 z-30 bg-slate-950/75 backdrop-blur-sm flex items-center justify-center">
              <div className="bg-slate-900 border border-slate-700 rounded-3xl p-6 text-center max-w-xs w-full shadow-2xl">
                <h3 className="text-xl font-black uppercase text-white mb-4">ПАУЗА</h3>
                <div className="flex flex-col gap-2">
                  <button onClick={() => { soundManager.playClick(); setIsGamePaused(false); }} className="w-full py-3 rounded-xl bg-sky-600 hover:bg-sky-500 font-black text-xs uppercase cursor-pointer">Продолжить</button>
                  <button onClick={() => { soundManager.playClick(); handlePlayAgain(); }} className="w-full py-3 rounded-xl bg-slate-800 hover:bg-slate-700 font-bold text-xs uppercase cursor-pointer">Перезапустить бой</button>
                  <button onClick={() => { soundManager.playClick(); setCurrentScreen('menu'); }} className="w-full py-3 rounded-xl bg-slate-800 hover:bg-slate-700 font-bold text-xs uppercase cursor-pointer text-slate-300">Главное меню</button>
                </div>
              </div>
            </div>
          )}

          <GameCanvas
            key={gameKey}
            playerChar={playerChar}
            botChar={botChar}
            gameMode={currentMode}
            p2Char={currentMode === 'two_player' ? botChar : undefined}
            settings={save.settings}
            matchesPlayed={save.matchesPlayed}
            onMatchEnd={handleMatchEnd}
            isPaused={isGamePaused}
            gojoAscended={save.gojoAscended}
            overkillMastery={save.overkillMastery}
            enableLightingMastery={save.masteryToggle.lighting}
            enableHahahaMastery={save.masteryToggle.hahaha}
            lightingMasteryUnlocked={save.masteries.lighting.unlocked}
            hahahaMasteryUnlocked={save.masteries.hahaha.unlocked}
            onMasteryProgress={recordMasteryProgress}
            onSetMasteryToggle={setMasteryToggle}
          />

          {matchResult && (
            <VictoryModal
              winner={matchResult.winner}
              playerChar={playerChar}
              botChar={botChar}
              coinsEarned={matchResult.coinsEarned}
              stats={matchResult.stats}
              kills={matchResult.kills}
              mode={currentMode}
              onPlayAgain={handlePlayAgain}
              onChangeFighter={() => { setMatchResult(null); setCurrentScreen('select'); }}
              onGoToMenu={() => { setMatchResult(null); setCurrentScreen('menu'); }}
            />
          )}
        </div>
      )}
    </div>
  );
}
