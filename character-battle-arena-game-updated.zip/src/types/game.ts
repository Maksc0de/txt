export type Rarity = 'starter' | 'common' | 'rare' | 'epic' | 'legendary' | 'mythic' | 'godly' | 'secret' | 'boss';

export type GameMode = 'standard' | 'final_health' | 'boss_raid' | 'two_player' | 'training' | 'endless';

export type EndlessSubmode = 'standard' | 'duo' | 'last';

export type WeaponType = 
  | 'sword' 
  | 'swords_ring' 
  | 'spikes' 
  | 'guns' 
  | 'sniper' 
  | 'rpg' 
  | 'flamethrower' 
  | 'boss_gloves' 
  | 'robot_arm' 
  | 'overkill_fist' 
  | 'dragon_head' 
  | 'sonic_horns' 
  | 'tentacles' 
  | 'blaster' 
  | 'shield_barrier' 
  | 'terminal' 
  | 'magic_orb' 
  | 'claws' 
  | 'knife' 
  | 'bomb' 
  | 'custom';

export type AbilityEffectType = 
  | 'dash_strike' 
  | 'sonic_boom' 
  | 'dragon_breath' 
  | 'gaster_blaster' 
  | 'hollow_purple' 
  | 'boss_slam' 
  | 'robot_transform' 
  | 'overkill_inferno' 
  | 'tnt_block' 
  | 'freeze_wave' 
  | 'slash_9999' 
  | 'black_hole' 
  | 'glitch_clone' 
  | 'bsod_error' 
  | 'sudo_rm' 
  | 'hadouken' 
  | 'spawn_minions' 
  | 'vent_ambush' 
  | 'flame_cone' 
  | 'rocket_barrage' 
  | 'sniper_pierce' 
  | 'repulsion_pulse' 
  | 'solar_flare' 
  | 'void_collapse' 
  | 'admin_ban' 
  | 'speed_hack' 
  | 'knife_storm' 
  | 'emergency_meeting' 
  | 'jumpscare' 
  | 'kagune_frenzy'
  | 'divine_smite'
  | 'mystery_chaos'
  | 'sonic_ring'
  | 'math_strike'
  | 'tentacle_grasp'
  | 'plasma_overdrive'
  | 'sugarok_revive'
  | 'final_ritual'
  | 'circle_barrage'
  | 'circle_nova'
  | 'gojo_blue'
  | 'gojo_red'
  | 'hollow_purple'
  | 'domain_infinite'
  | 'time_freeze'
  | 'katana_cut'
  | 'error_corrupt'
  | 'god_smite_rework'
  | 'flex_overpower'
  | 'ender_cataclysm'
  | 'sans_blaster_wall'
  | 'sans_bone_zone'
  | 'sans_blue_soul'
  | 'sans_bad_time'
  | 'singularity_devour'
  | 'glitch_rewrite'
  | 'lightning_tempest'
  | 'ultra_slam'
  | 'ultra_railcoin'
  | 'ultra_parry_dash'
  | 'ultra_ascend'
  | 'ultra_sword'
  | 'ultra_rainbow_blaster'
  | 'ultra_arena_cut'
  | 'star_fall'
  | 'stellar_guard'
  | 'magma_burst'
  | 'royal_slash'
  | 'war_shockwave'
  | 'blade_tempest'
  | 'glitch_slash'
  | 'glitch_dash_impale'
  | 'glitch_sword_rain'
  | 'glitch_orbit_storm'
  | 'glitch_teleport_cut'
  | 'glitch_mirror_clone'
  | 'glitch_final_barrage';

export interface Ability {
  id: string;
  name: string;
  nameRu: string;
  description: string;
  cooldown: number; // in seconds
  effectType: AbilityEffectType;
  damage: number;
  duration?: number;
  particleColor?: string;
  iconName?: string;
}

export interface Character {
  id: string;
  num: number;
  name: string;
  titleRu: string;
  category: 'Minecraft' | 'Undertale' | 'FNAF' | 'Analog Horror' | 'Subnautica' | 'Combat Masters' | 'Anime & Gods' | 'Glitch & Chaos' | 'Doors' | 'Vehicles & Mechs' | 'OS Wars' | 'Memes & Special';
  rarity: Rarity;
  price: number; // in coins
  isStarter?: boolean;
  
  // Visual & Model properties
  avatarColor: string;
  glowColor: string;
  secondaryColor?: string;
  iconEmoji?: string;
  isGiant?: boolean;
  giantMultiplier?: number; // scale > 1 (e.g. 1.8 for leviathan, 4.6 for gargantua mega)
  segmentLength?: number; // number of body segments for serpentine leviathans (higher = longer)
  modelType: 'circle' | 'segmented_leviathan' | 'boss_dave' | 'mech_titan' | 'dragon' | 'bus' | 'horror_creature' | 'orb_core' | 'robot' | 'volcanic_ash';
  
  // Weapon attachments & Spikes
  weaponType: WeaponType;
  weaponCount: number; // e.g. 1 sword, 4 orbiting swords, 8 spikes, 2 boss hands
  weaponColor: string;
  spikeRadiusOffset?: number;
  hasSpikes?: boolean;
  
  // Combat stats
  maxHp: number; // default 7, unless god or special
  baseSpeed: number; // default ~4-5
  speedBonus?: number; // e.g. knife master +10 speed
  speedMultiplier?: number; // e.g. Lighting SECRET x3.5
  weight: number; // mass for physics collisions
  knockbackForce: number;
  weaponReach: number;

  /** SECOND LIFE: если задано — при смерти боец распадается на частицы и возрождается в новой форме (Артём -> САХАРОК) */
  secondLife?: {
    name: string;
    nameRu: string;
    maxHp: number;
    speedMul: number; // velocity multiplier of the reborn form (faster!)
    damageMul?: number; // weaker second form for balanced revivals such as ANGEL
    sizeMul: number;  // radius multiplier of the reborn form
    avatarColor: string;
    glowColor: string;
    avatarEmoji: string;
  };
  passiveDesc: string;
  
  // Special Ability
  ability: Ability;
  /** Дополнительные способности циклируются после основной (Годжо, FINAL и др.) */
  extraAbilities?: Ability[];
  /** У FINAL имя рисуется глитч-шрифтом с дёрганием */
  glitchName?: boolean;
}

export interface Bundle {
  id: string;
  title: string;
  description: string;
  characterIds: string[];
  originalPrice: number;
  discountPrice: number;
  bannerColor: string;
  badge: string;
}

export interface CrateTier {
  id: 'bronze' | 'silver' | 'gold';
  name: string;
  nameRu: string;
  cost: number;
  description: string;
  accentColor: string;
  borderColor: string;
  rarityWeights: {
    starter: number;
    common: number;
    rare: number;
    epic: number;
    legendary: number;
    mythic: number;
    godly: number;
    secret: number;
    boss: number;
  };
  coinRewardRange: [number, number];
}

export interface PowerUpOrb {
  id: string;
  x: number;
  y: number;
  radius: number;
  type: 'spike_armor' | 'energy_shield' | 'speed_boost' | 'heal' | 'rage_sword';
  duration: number;
  pulseTimer: number;
}

export interface Projectile {
  id: string;
  owner: 'player' | 'bot' | 'p2';
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  damage: number;
  color: string;
  glowColor: string;
  life: number;
  maxLife: number;
  type: 'bullet' | 'laser' | 'rocket' | 'fireball' | 'bone' | 'bsod' | 'tnt' | 'sonic_ring' | 'kagune' | 'minion' | 'slash_wave' | 'gojo_blue' | 'gojo_red' | 'hollow_purple' | 'spiral' | 'shade';
  homing?: boolean;
  piercing?: boolean;
  /** Задержка вылета (круги FINAL выходят по очереди) */
  delay?: number;
  /** Кадр жизни, после которого снаряд возвращается к хозяину */
  returnAt?: number;
  // Спиральное движение (Семеричная Нова)
  spiralAngle?: number;
  spiralDist?: number;
  // Годжо Синий: точка, куда вернуть захваченную цель
  captureX?: number;
  captureY?: number;
  /** Угол орбиты для gojo_blue */
  orbitAngle?: number;
  /** Накопитель для периодического урона-притяжения */
  drainAcc?: number;
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  alpha: number;
  decay: number;
  shape?: 'circle' | 'square' | 'spark' | 'ring' | 'text' | 'star';
  text?: string;
}

export interface FloatingText {
  id: string;
  x: number;
  y: number;
  text: string;
  color: string;
  alpha: number;
  vy: number;
  fontSize: number;
}

export interface FighterEntity {
  id: 'player' | 'bot' | 'p2';
  character: Character;
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  angle: number; // facing angle
  weaponAngle: number; // orbiting weapon rotation
  hp: number;
  maxHp: number;
  
  // Buff states
  hasSpikesBuff: boolean;
  spikesBuffTimer: number;
  hasShield: boolean;
  shieldHitsRemaining: number;
  speedBoostTimer: number;
  freezeTimer: number;
  invulnerableTimer: number;
  
  // Ability state
  abilityCooldownTimer: number;
  abilityActiveTimer: number;
  isTransformed: boolean; // For Robot User etc.
  transformationMeter: number; // 0 to 100
  
  // Boss/Multi-segment state
  segments?: Array<{ x: number; y: number; radius: number }>;
  bossHands?: Array<{ x: number; y: number; targetX: number; targetY: number; angle: number; isSlamming: boolean }>;
  
  // Stats
  hitsDealt: number;
  damageDealt: number;
  kills: number;

  // Second-life (Артём -> САХАРОК) runtime flags
  secondLifeUsed?: boolean;
  sugarokForm?: boolean;

  // FINAL и циклические способности
  /** Постоянный множитель урона (x1.3 у FINAL после ритуала) */
  damageMultiplier?: number;
  /** Ставшие частью бойца 7 кругов FINAL */
  finalCircles?: boolean;
  /** Текущий индекс способности в цепочке (основная + extra) */
  abilitySlot?: number;
  /** STELLAR STR: многослойный щит (по умолчанию ломается за 1 удар, у STELLAR — 5 "хитов") */
  stellarShieldHp?: number;
}

export interface GameSettings {
  soundVolume: number;
  musicEnabled: boolean;
  screenShake: boolean;
  particleDensity: 'low' | 'medium' | 'high';
  dynamicArenaZoom: boolean;
  showHitboxes: boolean;
  touchControls: boolean;
  /** Custom background theme id chosen by the player */
  bgTheme?: 'cosmic' | 'abyss' | 'sunset' | 'candy' | 'matrix' | 'volcano';
}

export interface PlayerProgress {
  coins: number;
  unlockedCharacters: string[];
  selectedPlayerCharId: string;
  selectedBotCharId: string;
  matchesPlayed: number;
  wins: number;
  losses: number;
  highestWinStreak: number;
  currentWinStreak: number;
  favoriteCharacter: string;
  openedCrates: number;
  secretDlcActivationsLeft: number;
  hasUsedMasterDlc: boolean;
  settings: GameSettings;

  // Квесты пробуждения Годжо (Hollow Purple + Infinity Void)
  gojoDamage: number;
  gojoWins: number;
  gojoAscended: boolean;

  // Мастери OVERKILL (3 квеста): суммарные убийства, победы и волны Endless (накапливаются между играми)
  totalKills: number;
  totalWaves: number;
  overkillMastery: boolean;
  networkRuns?: Record<string, { kills: number; waves: number; damage: number; coins: number; finished: boolean }>;

  // Заблокированные/открытые рейд-боссы (получаются победой над ними)
  unlockedBosses: string[];

  // Мастери (квесты копятся между боями) и переключатели включено/выключено
  lightingKills: number;
  lightingAbility: number;
  lightingDistance: number; // в метрах (примерно миры)
  lightingMastery: boolean;
  hahaUses: number;
  hahaSurvive: number; // лучший раз, сколько секунд продержался в одном бою
  hahaSecretDone: boolean; // секретный 3-й квест: сработал редкий 0.5% эффект при использовании способности
  hahaMastery: boolean;
  masteries: Record<string, boolean>;
}
