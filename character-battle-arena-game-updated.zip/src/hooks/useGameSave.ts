import { useState, useEffect, useCallback } from 'react';
import { PlayerProgress, GameSettings, GameMode } from '../types/game';
import { ALL_CHARACTERS, STARTER_CHARACTER_IDS } from '../data/characters';
import { soundManager } from '../audio/soundManager';

const STORAGE_KEY = 'arena_game_save_v1';

export interface NetworkProgress {
  matchId: string;
  characterId: string;
  mode: GameMode;
  kills: number;
  waves: number;
  damage: number;
  coins: number;
  finished: boolean;
  won: boolean;
}

const DEFAULT_SETTINGS: GameSettings = {
  soundVolume: 0.7,
  musicEnabled: true,
  screenShake: true,
  particleDensity: 'high',
  dynamicArenaZoom: true,
  showHitboxes: false,
  touchControls: false,
  bgTheme: 'cosmic'
};

const DEFAULT_SAVE: PlayerProgress = {
  coins: 350, // Starting bonus coins
  unlockedCharacters: [...STARTER_CHARACTER_IDS],
  selectedPlayerCharId: 'steve',
  selectedBotCharId: 'sword_master',
  matchesPlayed: 0,
  wins: 0,
  losses: 0,
  highestWinStreak: 0,
  currentWinStreak: 0,
  favoriteCharacter: 'steve',
  openedCrates: 0,
  secretDlcActivationsLeft: 100, // 100 activations left for user's personal secret DLC code
  hasUsedMasterDlc: false,
  settings: DEFAULT_SETTINGS,
  gojoDamage: 0,
  gojoWins: 0,
  gojoAscended: false,
  totalKills: 0,
  totalWaves: 0,
  overkillMastery: false,
  unlockedBosses: ['figure_doors'],
  lightingKills: 0,
  lightingAbility: 0,
  lightingDistance: 0,
  lightingMastery: false,
  hahaUses: 0,
  hahaSurvive: 0,
  hahaSecretDone: false,
  hahaMastery: false,
  masteries: {}
};

// Пороговые значения пробуждения Годжо (3 квеста — достижимые)
export const GOJO_QUESTS = {
  damageRequired: 300,
  winsRequired: 5,
  cratesRequired: 3
};

// Мастери OVERKILL (3 ОЧЕНЬ сложных квеста, накапливаются между играми)
export const OVERKILL_QUESTS = {
  killsRequired: 1000,
  winsRequired: 99,
  wavesRequired: 1000
};

// Мастери LIGHTING: 100 убийств, 10 км суммарно, 150 использ. способности
export const LIGHTING_QUESTS = { killsRequired: 100, distanceRequired: 10, abilityRequired: 150 };
// Мастери HAHAHA: 50 использ. способности, выжить 25с в раунде, секретный третий квест
export const HAHA_QUESTS = { abilityRequired: 50, surviveRequired: 25 };

export const useGameSave = () => {
  const [save, setSave] = useState<PlayerProgress>(() => {
    if (typeof window === 'undefined') return DEFAULT_SAVE;
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        // Ensure all starter characters are always present
        const mergedUnlocked = Array.from(new Set([...STARTER_CHARACTER_IDS, ...(parsed.unlockedCharacters || [])]));
        return {
          ...DEFAULT_SAVE,
          ...parsed,
          unlockedCharacters: mergedUnlocked,
          settings: {
            ...DEFAULT_SETTINGS,
            ...(parsed.settings || {})
          }
        };
      }
    } catch {
      // Fallback
    }
    return DEFAULT_SAVE;
  });

  // Save to localStorage whenever state changes
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(save));
    } catch {
      // Ignore quota errors
    }
    // Update audio manager settings
    soundManager.setVolume(save.settings.soundVolume);
  }, [save]);

  const updateSettings = useCallback((newSettings: Partial<GameSettings>) => {
    setSave(prev => ({
      ...prev,
      settings: {
        ...prev.settings,
        ...newSettings
      }
    }));
  }, []);

  const addCoins = useCallback((amount: number) => {
    setSave(prev => ({
      ...prev,
      coins: Math.max(0, prev.coins + amount)
    }));
  }, []);

  const selectPlayerCharacter = useCallback((id: string) => {
    setSave(prev => ({
      ...prev,
      selectedPlayerCharId: id,
      favoriteCharacter: id
    }));
  }, []);

  const selectBotCharacter = useCallback((id: string) => {
    setSave(prev => ({
      ...prev,
      selectedBotCharId: id
    }));
  }, []);

  const unlockCharacter = useCallback((id: string, cost: number = 0): boolean => {
    let success = false;
    setSave(prev => {
      if (prev.unlockedCharacters.includes(id)) return prev;
      if (prev.coins < cost) return prev;
      success = true;
      return {
        ...prev,
        coins: prev.coins - cost,
        unlockedCharacters: [...prev.unlockedCharacters, id]
      };
    });
    return success;
  }, []);

  const unlockMultipleCharacters = useCallback((ids: string[], totalCost: number): boolean => {
    let success = false;
    setSave(prev => {
      if (prev.coins < totalCost) return prev;
      success = true;
      const combined = Array.from(new Set([...prev.unlockedCharacters, ...ids]));
      return {
        ...prev,
        coins: prev.coins - totalCost,
        unlockedCharacters: combined
      };
    });
    return success;
  }, []);

  // kills — убийства за матч (бот = 1, Endless = число волн), waves — пройденные волны Endless
  const recordMatchResult = useCallback((won: boolean, coinsEarned: number, kills: number = 0, waves: number = 0) => {
    setSave(prev => {
      const newWins = won ? prev.wins + 1 : prev.wins;
      const newLosses = won ? prev.losses : prev.losses + 1;
      const newStreak = won ? prev.currentWinStreak + 1 : 0;
      const newHighStreak = Math.max(prev.highestWinStreak, newStreak);
      const totalKills = (prev.totalKills || 0) + kills;
      const totalWaves = (prev.totalWaves || 0) + waves;
      const mastery =
        prev.overkillMastery ||
        (totalKills >= OVERKILL_QUESTS.killsRequired &&
          newWins >= OVERKILL_QUESTS.winsRequired &&
          totalWaves >= OVERKILL_QUESTS.wavesRequired);

      return {
        ...prev,
        coins: prev.coins + coinsEarned,
        matchesPlayed: prev.matchesPlayed + 1,
        wins: newWins,
        losses: newLosses,
        currentWinStreak: newStreak,
        highestWinStreak: newHighStreak,
        totalKills,
        totalWaves,
        overkillMastery: mastery
      };
    });
  }, []);

  const recordCrateOpen = useCallback(() => {
    setSave(prev => ({
      ...prev,
      openedCrates: prev.openedCrates + 1
    }));
  }, []);

  // Cumulative checkpoints prevent duplicate rewards and retain waves on disconnect.
  const recordNetworkProgress = useCallback((progress: NetworkProgress) => {
    if (progress.mode === 'training') return;
    setSave(prev => {
      const runs = prev.networkRuns || {};
      const old = runs[progress.matchId] || { kills: 0, waves: 0, damage: 0, coins: 0, finished: false };
      if (old.finished) return prev;
      const next = {
        kills: Math.max(old.kills, progress.kills), waves: Math.max(old.waves, progress.waves),
        damage: Math.max(old.damage, Math.round(progress.damage)), coins: Math.max(old.coins, progress.coins), finished: progress.finished,
      };
      if (next.kills === old.kills && next.waves === old.waves && next.damage === old.damage && next.coins === old.coins && next.finished === old.finished) return prev;
      const totalKills = (prev.totalKills || 0) + next.kills - old.kills;
      const totalWaves = (prev.totalWaves || 0) + next.waves - old.waves;
      const won = progress.finished && progress.won;
      const wins = prev.wins + Number(won);
      const gojoDamage = (prev.gojoDamage || 0) + (progress.characterId === 'gojo' ? next.damage - old.damage : 0);
      const gojoWins = (prev.gojoWins || 0) + Number(progress.characterId === 'gojo' && won);
      const streak = progress.finished ? won ? prev.currentWinStreak + 1 : 0 : prev.currentWinStreak;
      return {
        ...prev,
        coins: prev.coins + next.coins - old.coins, totalKills, totalWaves,
        wins, losses: prev.losses + Number(progress.finished && !progress.won),
        matchesPlayed: prev.matchesPlayed + Number(progress.finished),
        currentWinStreak: streak, highestWinStreak: Math.max(prev.highestWinStreak, streak),
        gojoDamage, gojoWins,
        gojoAscended: prev.gojoAscended || (gojoDamage >= GOJO_QUESTS.damageRequired && gojoWins >= GOJO_QUESTS.winsRequired && prev.openedCrates >= GOJO_QUESTS.cratesRequired),
        overkillMastery: prev.overkillMastery || (totalKills >= OVERKILL_QUESTS.killsRequired && wins >= OVERKILL_QUESTS.winsRequired && totalWaves >= OVERKILL_QUESTS.wavesRequired),
        networkRuns: { ...Object.fromEntries(Object.entries(runs).slice(-39)), [progress.matchId]: next },
      };
    });
  }, []);

  // Разблокировка рейд-боссов победами + переключатели мастери
  const unlockBoss = useCallback((id: string) => {
    setSave(prev => prev.unlockedBosses.includes(id) ? prev : { ...prev, unlockedBosses: [...prev.unlockedBosses, id] });
  }, []);
  const setMastery = useCallback((id: string, enabled: boolean) => {
    setSave(prev => ({ ...prev, masteries: { ...prev.masteries, [id]: enabled } }));
  }, []);
  // Мастери LIGHTING: убийства, дистанция (метры), использования способности
  const addLightingStats = useCallback((kills: number, ability: number, distance: number) => {
    setSave(prev => {
      const lightingKills = prev.lightingKills + kills;
      const lightingAbility = prev.lightingAbility + ability;
      const lightingDistance = prev.lightingDistance + Math.round(distance);
      const mastery = prev.lightingMastery ||
        (lightingKills >= LIGHTING_QUESTS.killsRequired && lightingDistance >= LIGHTING_QUESTS.distanceRequired && lightingAbility >= LIGHTING_QUESTS.abilityRequired);
      return { ...prev, lightingKills, lightingAbility, lightingDistance, lightingMastery: mastery };
    });
  }, []);
  // Мастери HAHAHA: использования + время выживания в одном раунде + секретный квест "HAHHAHAHAHAH"
  const addHahaStats = useCallback((ability: number, survive: number, secretTriggered: boolean = false) => {
    setSave(prev => {
      const hahaUses = prev.hahaUses + ability;
      const hahaSurvive = Math.max(prev.hahaSurvive, Math.round(survive));
      const hahaSecretDone = prev.hahaSecretDone || secretTriggered;
      const mastery = prev.hahaMastery || (hahaUses >= HAHA_QUESTS.abilityRequired && hahaSurvive >= HAHA_QUESTS.surviveRequired && hahaSecretDone);
      return { ...prev, hahaUses, hahaSurvive, hahaSecretDone, hahaMastery: mastery };
    });
  }, []);

  // Квесты Годжо: учёт урона и побед при игре за Годжо — 3 квеста открывают Hollow Purple и Infinity Void
  const updateGojoStats = useCallback((damageDealt: number, wonMatch: boolean) => {
    setSave(prev => {
      const gojoDamage = prev.gojoDamage + Math.round(damageDealt);
      const gojoWins = prev.gojoWins + (wonMatch ? 1 : 0);
      const ascended =
        gojoDamage >= GOJO_QUESTS.damageRequired &&
        gojoWins >= GOJO_QUESTS.winsRequired &&
        prev.openedCrates >= GOJO_QUESTS.cratesRequired;
      return { ...prev, gojoDamage, gojoWins, gojoAscended: prev.gojoAscended || ascended };
    });
  }, []);

  // Redeem Promo & DLC Codes
  const redeemCode = useCallback((rawCode: string): { success: boolean; message: string; coinsAdded?: number } => {
    const code = rawCode.trim().toUpperCase();
    if (!code) return { success: false, message: 'Введите код!' };

    // Мастери-код: выдаёт мастери Lighting (и возвращает тебе мастери по старому мастер-коду).
    if (code === 'LIGHTING-ASCEND' || code === 'LIGHT-ASCEND') {
      setSave(prev => ({
        ...prev,
        lightingKills: Math.max(prev.lightingKills, LIGHTING_QUESTS.killsRequired),
        lightingAbility: Math.max(prev.lightingAbility, LIGHTING_QUESTS.abilityRequired),
        lightingDistance: Math.max(prev.lightingDistance, LIGHTING_QUESTS.distanceRequired),
        lightingMastery: true,
      }));
      return { success: true, message: 'Мастери LIGHTING GOD раскрыто: +1.75x скорости, +1.5x урона, −25% КД и Speed GOD.' };
    }

    // Master DLC (private). Старые варианты кода отключены — действует только новый.
    if (code === 'OMEGA-FINAL-MASTERY-∞' || code === 'OMEGA-FINAL-MASTERY-INF' || code === 'OMEGA-FINAL-MASTERY-8') {
      let result: { success: boolean; message: string; coinsAdded?: number } = { success: false, message: '' };
      setSave(prev => {
        if (prev.secretDlcActivationsLeft <= 0) {
          result = { success: false, message: 'Лимит активаций этого кода исчерпан (0/100)!' };
          return prev;
        }

        const allCharIds = ALL_CHARACTERS.map(c => c.id);
        const remainingActivations = prev.secretDlcActivationsLeft - 1;

        result = {
          success: true,
          message: `MASTER DLC АКТИВИРОВАН! Открыты ВСЕ персонажи, ВСЕ мастери (Годжо + OVERKILL) и +999,999 монет! (Осталось активаций: ${remainingActivations})`,
          coinsAdded: 999999
        };

        return {
          ...prev,
          coins: prev.coins + 999999,
          unlockedCharacters: allCharIds,
          secretDlcActivationsLeft: remainingActivations,
          hasUsedMasterDlc: true,
          // Все мастери — выполнены
          gojoAscended: true,
          gojoDamage: Math.max(prev.gojoDamage, GOJO_QUESTS.damageRequired),
          gojoWins: Math.max(prev.gojoWins, GOJO_QUESTS.winsRequired),
          openedCrates: Math.max(prev.openedCrates, GOJO_QUESTS.cratesRequired),
          overkillMastery: true,
          totalKills: Math.max(prev.totalKills || 0, OVERKILL_QUESTS.killsRequired),
          totalWaves: Math.max(prev.totalWaves || 0, OVERKILL_QUESTS.wavesRequired),
          wins: Math.max(prev.wins, OVERKILL_QUESTS.winsRequired),
          unlockedBosses: ALL_CHARACTERS.filter(c => c.rarity === 'boss').map(c => c.id),
          lightingKills: Math.max(prev.lightingKills, LIGHTING_QUESTS.killsRequired),
          lightingAbility: Math.max(prev.lightingAbility, LIGHTING_QUESTS.abilityRequired),
          lightingDistance: Math.max(prev.lightingDistance, LIGHTING_QUESTS.distanceRequired),
          lightingMastery: true,
          hahaUses: Math.max(prev.hahaUses, HAHA_QUESTS.abilityRequired),
          hahaSurvive: Math.max(prev.hahaSurvive, HAHA_QUESTS.surviveRequired),
          hahaSecretDone: true,
          hahaMastery: true
        };
      });
      return result;
    }

    // Public Bonus Promo Codes
    if (code === 'FREE-COINS' || code === 'ARENA2026') {
      addCoins(500);
      return { success: true, message: 'Промокод принят! +500 монет начислено!', coinsAdded: 500 };
    }

    if (code === 'STARTER-PACK') {
      addCoins(1000);
      return { success: true, message: 'Стартовый набор активирован! +1000 монет!', coinsAdded: 1000 };
    }

    if (code === 'SLAP-ARENA') {
      addCoins(750);
      return { success: true, message: 'Бонус арены! +750 монет!', coinsAdded: 750 };
    }

    return { success: false, message: 'Неверный код или срок действия истек.' };
  }, [addCoins]);

  const resetAllProgress = useCallback(() => {
    setSave({
      ...DEFAULT_SAVE,
      unlockedCharacters: [...STARTER_CHARACTER_IDS]
    });
    localStorage.removeItem(STORAGE_KEY);
  }, []);

  return {
    save,
    updateSettings,
    addCoins,
    selectPlayerCharacter,
    selectBotCharacter,
    unlockCharacter,
    unlockMultipleCharacters,
    recordMatchResult,
    recordCrateOpen,
    recordNetworkProgress,
    unlockBoss,
    setMastery,
    addLightingStats,
    addHahaStats,
    updateGojoStats,
    redeemCode,
    resetAllProgress
  };
};
