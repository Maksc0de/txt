import { useState, useMemo, useCallback } from 'react';
import { GameMode, EndlessSubmode, Character } from './types/game';
import { getCharacterById, ALL_CHARACTERS } from './data/characters';
import { useGameSave } from './hooks/useGameSave';
import { MainMenu } from './components/Menu/MainMenu';
import { CharacterSelect } from './components/Selection/CharacterSelect';
import { ShopModal } from './components/Shop/ShopModal';
import { SettingsModal } from './components/Settings/SettingsModal';
import { GameCanvas } from './components/Arena/GameCanvas';
import { VictoryModal } from './components/Modals/VictoryModal';
import { soundManager } from './audio/soundManager';
import { ArrowLeft, Pause, Play } from 'lucide-react';
import { LocalBossRaid } from './components/Arena/LocalBossRaid';
import { RAID_BOSSES } from './game/raidRules';

type ScreenState = 'menu' | 'select' | 'shop' | 'settings' | 'game';

export default function App() {
  const {
    save,
    updateSettings,
    addCoins,
    selectPlayerCharacter,
    selectBotCharacter,
    unlockCharacter,
    unlockMultipleCharacters,
    recordMatchResult,
    recordCrateOpen,
    unlockBoss,
    setMastery,
    addLightingStats,
    addHahaStats,
    updateGojoStats,
    redeemCode,
    resetAllProgress
  } = useGameSave();

  const [currentScreen, setCurrentScreen] = useState<ScreenState>('menu');
  const [currentMode, setCurrentMode] = useState<GameMode>('standard');
  const [endlessSubmode, setEndlessSubmode] = useState<EndlessSubmode>('standard');
  const [matchResult, setMatchResult] = useState<{
    winner: 'player' | 'bot' | 'p2';
    coinsEarned: number;
    stats: { hits: number; damage: number };
    kills?: number;
  } | null>(null);
  const [isGamePaused, setIsGamePaused] = useState<boolean>(false);
  const [gameKey, setGameKey] = useState<number>(0);
  // Локальная игра на одном устройстве: максимум Дуо (1 или 2 игрока). Пати-коды убраны.
  const [teamSize, setTeamSize] = useState<1 | 2>(1);
  const [raidBossId, setRaidBossId] = useState(() => RAID_BOSSES.some(b => b.id === save.selectedBotCharId) ? save.selectedBotCharId : 'figure_doors');
  const [localRaid, setLocalRaid] = useState<{ heroes: Character[]; names: string[]; boss: Character } | null>(null);

  // Active characters
  const playerChar = useMemo(() => {
    return getCharacterById(save.selectedPlayerCharId === 'volcanic_ash' ? 'steve' : save.selectedPlayerCharId);
  }, [save.selectedPlayerCharId]);

  const botChar = useMemo(() => {
    if (currentMode === 'boss_raid') return getCharacterById(raidBossId);
    return getCharacterById(save.selectedBotCharId);
  }, [save.selectedBotCharId, currentMode, raidBossId]);

  const chooseTeam = (size: 1 | 2) => setTeamSize(size);
  const changeMode = (mode: GameMode) => setCurrentMode(mode);
  const changeBoss = (id: string) => setRaidBossId(id);

  const startLocalRaid = (players: 1 | 2) => {
    if (currentMode !== 'boss_raid') return;
    const picked: Character[] = [playerChar];
    const others = ALL_CHARACTERS.filter(c => c.id !== playerChar.id && c.id !== 'volcanic_ash' && save.unlockedCharacters.includes(c.id));
    for (let i = 1; i < players && others[i - 1]; i++) picked.push(others[i - 1]);
    const labels = players === 2 ? ['ИГРОК 1', 'ИГРОК 2'] : ['ИГРОК 1'];
    setLocalRaid({ heroes: picked.slice(0, players), names: labels.slice(0, players), boss: getCharacterById(raidBossId) });
  };

  // Handle Match End
  const handleMatchEnd = useCallback((winner: 'player' | 'bot' | 'p2', stats: { hits: number; damage: number; kills?: number }) => {
    const isPlayerWin = winner === 'player';
    const isEndless = currentMode === 'endless';
    const kills = stats.kills || 0;

    const baseCoins = isPlayerWin ? (currentMode === 'final_health' ? 150 : 120) : 35;
    const streakBonus = isPlayerWin ? Math.min(100, save.currentWinStreak * 15) : 0;
    // ENDLESS: награда масштабируется убийствами; подрежим 'last' платит x1.5
    const endlessBonus = isEndless ? Math.round(kills * 30 * (endlessSubmode === 'last' ? 1.5 : 1)) : 0;
    const totalCoinsEarned = baseCoins + streakBonus + endlessBonus;

    // Убийства: бот = 1 за победу, Endless = число волн; волны копятся между играми
    const killsThisMatch = isEndless ? kills : isPlayerWin ? 1 : 0;
    recordMatchResult(isPlayerWin, totalCoinsEarned, killsThisMatch, isEndless ? kills : 0);
    // Квесты Годжо: учёт урона и побед при игре за Годжо
    if (playerChar.id === 'gojo') {
      updateGojoStats(stats.damage, isPlayerWin);
    }
    // Победа над рейд-боссом открывает его в ростер
    if (currentMode === 'boss_raid' && isPlayerWin) {
      unlockBoss(botChar.id);
    }

    setMatchResult({
      winner,
      coinsEarned: totalCoinsEarned,
      stats: { hits: stats.hits, damage: stats.damage },
      kills
    });
  }, [currentMode, recordMatchResult, save.currentWinStreak, endlessSubmode, playerChar.id, updateGojoStats]);

  // Rematch
  const handlePlayAgain = () => {
    setMatchResult(null);
    setIsGamePaused(false);
    setGameKey(prev => prev + 1);
  };

  // Кастомный задний фон из настроек (Cosmic / Abyss / Sunset / Candy / Matrix / Volcano)
  const bgTheme = save.settings.bgTheme || 'cosmic';
  const bgThemeClasses: Record<string, string> = {
    cosmic: 'bg-slate-950',
    abyss: 'bg-gradient-to-b from-slate-950 via-sky-950 to-cyan-950',
    sunset: 'bg-gradient-to-b from-orange-950 via-rose-950 to-slate-950',
    candy: 'bg-gradient-to-b from-fuchsia-950 via-pink-950 to-purple-950',
    matrix: 'bg-gradient-to-b from-slate-950 via-emerald-950 to-green-950',
    volcano: 'bg-gradient-to-b from-red-950 via-orange-950 to-stone-950'
  };

  if (localRaid) {
    return <LocalBossRaid heroes={localRaid.heroes} heroNames={localRaid.names} boss={localRaid.boss} onExit={() => { setLocalRaid(null); setCurrentScreen('menu'); }} />;
  }

  return (
    <div className={`w-full h-[100dvh] ${bgThemeClasses[bgTheme]} text-white flex flex-col select-none overflow-hidden font-sans`}>
      {/* 1. MAIN MENU SCREEN */}
      {currentScreen === 'menu' && (
        <MainMenu
          save={save}
          selectedPlayerChar={playerChar}
          selectedBotChar={botChar}
          currentMode={currentMode}
          endlessSubmode={endlessSubmode}
          onChangeEndlessSubmode={setEndlessSubmode}
          onChangeMode={changeMode}
          onChangeBoss={changeBoss}
          teamSize={teamSize}
          onTeamSize={chooseTeam}
          onLocalRaid={startLocalRaid}
          onStartGame={() => {
            if (currentMode === 'boss_raid' && teamSize > 1) { startLocalRaid(teamSize); return; }
            setMatchResult(null);
            setIsGamePaused(false);
            setGameKey(prev => prev + 1);
            setCurrentScreen('game');
          }}
          onOpenCharacterSelect={() => setCurrentScreen('select')}
          onOpenShop={() => setCurrentScreen('shop')}
          onOpenCrates={() => setCurrentScreen('shop')}
          onOpenSettings={() => setCurrentScreen('settings')}
        />
      )}

      {/* 2. CHARACTER SELECTION SCREEN */}
      {currentScreen === 'select' && (
        <CharacterSelect
          unlockedCharacterIds={save.unlockedCharacters}
          selectedPlayerCharId={save.selectedPlayerCharId}
          selectedBotCharId={save.selectedBotCharId}
          userCoins={save.coins}
          gojoQuest={{
            damage: save.gojoDamage,
            wins: save.gojoWins,
            crates: save.openedCrates,
            ascended: save.gojoAscended
          }}
          overkillQuest={{
            kills: save.totalKills || 0,
            wins: save.wins,
            waves: save.totalWaves || 0,
            mastery: save.overkillMastery
          }}
          onSelectPlayer={id => selectPlayerCharacter(id)}
          onSelectBot={id => selectBotCharacter(id)}
          onUnlockCharacter={(id, cost) => unlockCharacter(id, cost)}
          onBackToMenu={() => setCurrentScreen('menu')}
          onGoToShop={() => setCurrentScreen('shop')}
        />
      )}

      {/* 3. SHOP & CRATES SCREEN */}
      {currentScreen === 'shop' && (
        <ShopModal
          unlockedCharacterIds={save.unlockedCharacters}
          userCoins={save.coins}
          onUnlockCharacter={(id, cost) => unlockCharacter(id, cost)}
          onUnlockMultiple={(ids, cost) => unlockMultipleCharacters(ids, cost)}
          onAddCoins={amount => addCoins(amount)}
          onRecordCrateOpen={() => recordCrateOpen()}
          onClose={() => setCurrentScreen('menu')}
          onOpenPromoModal={() => setCurrentScreen('settings')}
        />
      )}

      {/* 4. SETTINGS & DLC CODE SCREEN */}
      {currentScreen === 'settings' && (
        <SettingsModal
          settings={save.settings}
          onUpdateSettings={newSettings => updateSettings(newSettings)}
          onRedeemCode={code => redeemCode(code)}
          onResetProgress={() => resetAllProgress()}
          onClose={() => setCurrentScreen('menu')}
        />
      )}

      {/* 5. GAME COMBAT ARENA SCREEN */}
      {currentScreen === 'game' && (
        <div className="relative w-full h-full flex flex-col bg-slate-950">
          {/* In-game quick top bar */}
          <div className="absolute top-3 left-4 z-40 flex items-center gap-2 pointer-events-auto">
            <button
              onClick={() => {
                soundManager.playClick();
                setCurrentScreen('menu');
              }}
              className="p-2 rounded-xl bg-slate-900/85 hover:bg-slate-800 border border-slate-700 text-slate-300 hover:text-white transition-all cursor-pointer shadow-lg"
              title="Выйти в меню"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>

            <button
              onClick={() => {
                soundManager.playClick();
                setIsGamePaused(!isGamePaused);
              }}
              className="p-2 rounded-xl bg-slate-900/85 hover:bg-slate-800 border border-slate-700 text-slate-300 hover:text-white transition-all cursor-pointer shadow-lg"
              title={isGamePaused ? 'Продолжить' : 'Пауза'}
            >
              {isGamePaused ? <Play className="w-5 h-5 text-emerald-400" /> : <Pause className="w-5 h-5 text-amber-400" />}
            </button>
          </div>

          {/* Pause Overlay */}
          {isGamePaused && !matchResult && (
            <div className="absolute inset-0 z-30 bg-slate-950/75 backdrop-blur-sm flex items-center justify-center">
              <div className="bg-slate-900 border border-slate-700 rounded-3xl p-6 text-center max-w-xs w-full shadow-2xl">
                <h3 className="text-xl font-black uppercase text-white mb-4">ПАУЗА</h3>
                <div className="flex flex-col gap-2">
                  <button
                    onClick={() => {
                      soundManager.playClick();
                      setIsGamePaused(false);
                    }}
                    className="w-full py-3 rounded-xl bg-sky-600 hover:bg-sky-500 font-black text-xs uppercase cursor-pointer"
                  >
                    Продолжить
                  </button>
                  <button
                    onClick={() => {
                      soundManager.playClick();
                      handlePlayAgain();
                    }}
                    className="w-full py-3 rounded-xl bg-slate-800 hover:bg-slate-700 font-bold text-xs uppercase cursor-pointer"
                  >
                    Перезапустить бой
                  </button>
                  <button
                    onClick={() => {
                      soundManager.playClick();
                      setCurrentScreen('menu');
                    }}
                    className="w-full py-3 rounded-xl bg-slate-800 hover:bg-slate-700 font-bold text-xs uppercase cursor-pointer text-slate-300"
                  >
                    Главное меню
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* 60fps Battle Simulation Engine */}
          <GameCanvas
            key={gameKey}
            playerChar={playerChar}
            botChar={botChar}
            gameMode={currentMode}
            settings={save.settings}
            matchesPlayed={save.matchesPlayed}
            onMatchEnd={handleMatchEnd}
            isPaused={isGamePaused}
            gojoAscended={save.gojoAscended}
            overkillMastery={save.overkillMastery}
            endlessSubmode={endlessSubmode}
            masteries={save.masteries}
            onMasteryToggle={(id, enabled) => setMastery(id, enabled)}
            onQuestStats={stats => {
              if (playerChar.id === 'lighting_secret') addLightingStats(stats.lightingKills, stats.lightingAbility, stats.lightingDistance);
              if (playerChar.id === 'hahaha_troll') addHahaStats(stats.hahaUses, stats.hahaSurvive, stats.hahaSecret);
            }}
          />

          {/* Match Victory / Defeat Modal */}
          {matchResult && (
            <VictoryModal
              winner={matchResult.winner}
              playerChar={playerChar}
              botChar={botChar}
              coinsEarned={matchResult.coinsEarned}
              stats={matchResult.stats}
              kills={matchResult.kills}
              mode={currentMode}
              onPlayAgain={handlePlayAgain}
              onChangeFighter={() => {
                setMatchResult(null);
                setCurrentScreen('select');
              }}
              onGoToMenu={() => {
                setMatchResult(null);
                setCurrentScreen('menu');
              }}
            />
          )}
        </div>
      )}
    </div>
  );
}
