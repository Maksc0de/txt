import { getCharacterById } from '../data/characters';

export const RAID_BOSSES = [
  { id: 'figure_doors', hp: 50, tier: 'I', title: 'Хранитель библиотеки' },
  { id: 'warden', hp: 90, tier: 'II', title: 'Голос тёмных глубин' },
  { id: 'the_boiled_one', hp: 110, tier: 'II', title: 'Неподвижный ужас' },
  { id: 'ender_dragon', hp: 130, tier: 'III', title: 'Повелитель Края' },
  { id: 'dave', hp: 180, tier: 'III', title: 'Сокрушительные перчатки' },
  { id: 'grumble', hp: 220, tier: 'IV', title: 'Властелин подземелья' },
  { id: 'overkill_glove', hp: 240, tier: 'IV', title: 'Пылающий приговор' },
  { id: 'leviathan', hp: 350, tier: 'V', title: 'Хищник бездны' },
  { id: 'gargantua_leviathan', hp: 500, tier: 'VI', title: 'Древний колосс' },
  { id: 'volcanic_ash', hp: 1500, tier: 'VII', title: 'Сердце погасшего вулкана' },
  { id: 'magma_core', hp: 1000, tier: 'VI', title: 'Пылающее ядро бездны' },
] as const;

export function bossBaseHp(id: string): number {
  return RAID_BOSSES.find(b => b.id === id)?.hp ?? Math.max(50, Math.min(500, getCharacterById(id).maxHp * 12));
}

export function raidScale(players: number): number {
  return players >= 3 ? 2.9 : players === 2 ? 1.9 : 1;
}

export function bossHealth(id: string, players = 1): number {
  return Math.round(bossBaseHp(id) * raidScale(players));
}