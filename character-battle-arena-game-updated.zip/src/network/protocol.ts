import type { EndlessSubmode, GameMode } from '../types/game';

export const PROTOCOL_VERSION = 1;
export const INVITE_TTL = 180_000;
export const CODE_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
export const PLAYER_COLORS = ['#baf66a', '#7fbbff', '#df9eff'];

export interface Profile {
  name: string;
  characterId: string;
  gojoAscended: boolean;
  overkillMastery: boolean;
}

export interface PartyMember extends Profile {
  id: string;
  ready: boolean;
  slot: number;
}

export interface PartyConfig {
  mode: GameMode;
  enemyId: string;
  endless: EndlessSubmode;
  played: number;
}

export interface PartyRoom {
  id: string;
  hostId: string;
  capacity: 2 | 3;
  members: PartyMember[];
  config: PartyConfig;
  phase: 'lobby' | 'playing';
  matchId: string | null;
  paused: boolean;
  invitationExpiresAt: number;
}

export interface Invitation {
  code: string;
  token: string;
  expiresAt: number;
}

export interface PartyStatus {
  role: 'host' | 'guest' | null;
  selfId: string;
  connecting: boolean;
  signaling: boolean;
  room: PartyRoom | null;
  invitation: Invitation | null;
  error: string;
  notice: string;
  latency: number;
}

export interface PlayerInput {
  x: number;
  y: number;
  dash: boolean;
  ability: string | null;
  action: number;
  seq: number;
}

export function randomCode(length: number): string {
  const bytes = crypto.getRandomValues(new Uint8Array(length));
  return Array.from(bytes, b => CODE_ALPHABET[b % CODE_ALPHABET.length]).join('');
}

export function parseInvitation(raw: string): { room: string; token: string } | null {
  const normalized = raw.toUpperCase().replace(/[\s-]/g, '');
  if (normalized.length !== 12 || [...normalized].some(c => !CODE_ALPHABET.includes(c))) return null;
  return { room: normalized.slice(0, 8), token: normalized.slice(8) };
}

export function makeInvitation(roomId: string, now = Date.now(), previousToken = ''): Invitation {
  let token = randomCode(4);
  if (token === previousToken) token = token.slice(0, 3) + CODE_ALPHABET[(CODE_ALPHABET.indexOf(token[3]) + 1) % CODE_ALPHABET.length];
  return {
    code: `${roomId.slice(0, 4)}-${roomId.slice(4)}-${token}`,
    token,
    expiresAt: now + INVITE_TTL,
  };
}

export function invitationValid(invitation: Invitation | null, token: string, now = Date.now()): boolean {
  return !!invitation && now < invitation.expiresAt && token === invitation.token;
}

export function normalizeInput(value: unknown): PlayerInput | null {
  if (!value || typeof value !== 'object') return null;
  const v = value as Record<string, unknown>;
  if (typeof v.x !== 'number' || typeof v.y !== 'number' || !Number.isFinite(v.x) || !Number.isFinite(v.y) ||
      typeof v.seq !== 'number' || !Number.isSafeInteger(v.seq) || v.seq < 0 ||
      typeof v.action !== 'number' || !Number.isSafeInteger(v.action) || v.action < 0) return null;
  return {
    x: Math.max(-1, Math.min(1, v.x)), y: Math.max(-1, Math.min(1, v.y)),
    dash: v.dash === true, ability: typeof v.ability === 'string' ? v.ability.slice(0, 60) : null,
    action: v.action, seq: v.seq,
  };
}

export const MODE_INFO: Record<GameMode, { name: string; short: string; description: string }> = {
  standard: { name: 'Standard', short: 'Стандарт', description: 'Команда против команды ботов. Сферы дают щит или шипы на один удар.' },
  final_health: { name: 'Final Health', short: 'Один шанс', description: 'У каждого ровно 1 HP. Держитесь вместе: каждый удар может стать последним.' },
  boss_raid: { name: 'Boss Raid', short: 'Рейд на босса', description: 'Один босс против вашей команды. Его здоровье зависит от числа игроков.' },
  endless: { name: 'Endless', short: 'Бесконечные волны', description: 'После победы приходит новая волна. Бой продолжается, пока жив хотя бы один союзник.' },
  two_player: { name: 'Versus', short: 'Дуэль с друзьями', description: 'Каждый сам за себя. Побеждает последний выживший участник пати.' },
  training: { name: 'Training', short: 'Тренировка', description: 'Испытывайте техники вместе. Здоровье восстанавливается, наград и поражений нет.' },
};