import type { PartyConfig, PartyMember, PlayerInput } from './protocol';

export interface BattleFighter {
  id: string;
  characterId: string;
  name: string;
  slot: number;
  team: string;
  ai: boolean;
  boss: boolean;
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  angle: number;
  hp: number;
  maxHp: number;
  shield: number;
  spikes: boolean;
  invulnerable: number;
  frozen: number;
  cooldowns: Record<string, number>;
  charge: number;
  awakened: boolean;
  damageMultiplier: number;
  speedMultiplier: number;
  secondLife: boolean;
  emergencyShieldUsed: boolean;
  lastStand: boolean;
  shieldTimer: number;
  transformTime: number;
  regen: number;
  thought: number;
  attackTimer: number;
  castTimer: number;
  damage: number;
  hits: number;
  kills: number;
  action: number;
  departed: boolean;
  gojoAscended: boolean;
  overkillMastery: boolean;
}

export type ShotShape = 'orb' | 'bullet' | 'bone' | 'blade' | 'rocket' | 'pixel';
export interface BattleShot {
  id: number;
  owner: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  damage: number;
  life: number;
  color: string;
  homing: boolean;
  shape: ShotShape;
  explode: number;
}

export type EffectKind = 'hit' | 'ring' | 'beam' | 'slash' | 'bolt' | 'portal' | 'bones' | 'dome' | 'eruption' | 'glitch';
export interface BattleEffect {
  id: number;
  kind: EffectKind;
  owner: string;
  x: number;
  y: number;
  angle: number;
  size: number;
  width: number;
  color: string;
  text: string;
  age: number;
  duration: number;
  delay: number;
  damage: number;
  hitIds: string[];
}

export interface GravityField {
  owner: string;
  kind: 'blue' | 'red' | 'void' | 'domain';
  x: number;
  y: number;
  age: number;
  tick: number;
  duration: number;
  radius: number;
  captured: Record<string, { x: number; y: number }>;
}

export interface BattleFrame {
  matchId: string;
  config: PartyConfig;
  players: number;
  time: number;
  seed: number;
  serial: number;
  width: number;
  height: number;
  phase: 'countdown' | 'fighting' | 'intermission' | 'finished';
  phaseTimer: number;
  wave: number;
  completedWaves: number;
  teamKills: number;
  winner: string | null;
  fighters: BattleFighter[];
  shots: BattleShot[];
  effects: BattleEffect[];
  fields: GravityField[];
  orbs: { id: number; x: number; y: number; type: 'shield' | 'spikes' | 'heal'; age: number }[];
  orbTimer: number;
  cuts: { x: number; y: number; angle: number; color: string }[];
  cinematic: { kind: 'ultra' | 'erased' | 'final' | 'purple' | 'revive'; actor: string; age: number; duration: number } | null;
  timeStop: { owner: string; left: number } | null;
  shake: number;
  banner: { text: string; color: string; left: number } | null;
}

export interface TimedInput { value: PlayerInput; receivedAt: number }

export type PartyPacket =
  | { type: 'hello'; version: number; token: string; profile: Omit<PartyMember, 'id' | 'ready' | 'slot'> }
  | { type: 'room'; room: import('./protocol').PartyRoom }
  | { type: 'reject'; reason: string }
  | { type: 'profile'; profile: Omit<PartyMember, 'id' | 'ready' | 'slot'> }
  | { type: 'ready'; ready: boolean }
  | { type: 'leave' }
  | { type: 'closed'; reason: string }
  | { type: 'input'; matchId: string; input: PlayerInput }
  | { type: 'frame'; frame: BattleFrame }
  | { type: 'ping'; sent: number }
  | { type: 'pong'; sent: number };