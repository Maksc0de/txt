import { ALL_CHARACTERS, getCharacterById } from '../data/characters';
import type { Ability, Character } from '../types/game';
import { bossBaseHp, bossHealth } from '../game/raidRules';
import type { PartyMember, PartyRoom } from './protocol';
import type { BattleEffect, BattleFighter, BattleFrame, BattleShot, EffectKind, TimedInput } from './battleTypes';

const TAU = Math.PI * 2;
export const SPECTRUM = ['#ff637c', '#ff9f56', '#ffe17a', '#baf66a', '#6ee8dd', '#7aaaff', '#d39bff'];
const C = (f: BattleFighter) => getCharacterById(f.characterId);
const clamp = (x: number, min: number, max: number) => Math.max(min, Math.min(max, x));
const roundHp = (x: number) => Math.max(0, Math.round(x * 100) / 100);
const dist = (a: { x: number; y: number }, b: { x: number; y: number }) => Math.hypot(a.x - b.x, a.y - b.y);
const active = (f: BattleFighter) => f.hp > 0 && !f.departed;
const enemies = (w: BattleFrame, f: BattleFighter) => w.fighters.filter(v => active(v) && v.team !== f.team);
const nearest = (w: BattleFrame, f: BattleFighter) => enemies(w, f).sort((a, b) => dist(a, f) - dist(b, f))[0];
function random(w: BattleFrame) {
  w.seed = (Math.imul(1664525, w.seed) + 1013904223) >>> 0;
  return w.seed / 4294967296;
}

export function abilityOptions(f: BattleFighter): { ability: Ability; locked: string }[] {
  const c = C(f);
  const list = [c.ability, ...(c.extraAbilities || [])];
  return list.filter(ab => {
    if (c.id === 'ultrakill') {
      const post = ['ultra_sword', 'ultra_rainbow_blaster', 'ultra_arena_cut'].includes(ab.id);
      return f.awakened ? post : !post;
    }
    if (c.id === 'final') return f.awakened ? ab.id !== 'final_ritual' : ab.id === 'final_ritual';
    return true;
  }).map(ability => ({
    ability,
    locked: ['hollow_purple', 'infinity_void'].includes(ability.id) && !f.gojoAscended ? 'Нужно пробуждение'
      : ability.id === 'overkill_mastery' && !f.overkillMastery ? 'Нужно мастери'
      : ability.id === 'ultra_ascend' && f.charge < 100 ? `Ярость ${Math.floor(f.charge)} / 100` : '',
  }));
}

function fighter(character: Character, id: string, slot: number, team: string, w: BattleFrame, member?: PartyMember, boss = false): BattleFighter {
  const final = w.config.mode === 'final_health';
  const maxHp = final ? 1 : boss ? bossHealth(character.id, w.players)
    : w.config.mode === 'boss_raid' && member ? Math.max(16, character.maxHp * 2) : character.maxHp;
  return {
    id, characterId: character.id, name: member?.name || character.name, slot, team,
    ai: !member, boss, x: w.width * (member ? 0.28 : 0.72), y: w.height * (0.3 + slot * 0.2),
    vx: member ? 120 : -120, vy: 70 * (slot % 2 ? -1 : 1),
    radius: character.id === 'the_dot' ? 16 : 28 * (character.isGiant ? character.giantMultiplier || 1.5 : 1),
    angle: member ? 0 : Math.PI, hp: maxHp, maxHp, shield: 0, spikes: false, invulnerable: 0, frozen: 0,
    cooldowns: {}, charge: 0, awakened: false, damageMultiplier: 1, speedMultiplier: 1,
    secondLife: false, emergencyShieldUsed: false, lastStand: false, shieldTimer: 12,
    transformTime: 0, regen: 0, thought: 0.8 + random(w), attackTimer: 0, castTimer: 0,
    damage: 0, hits: 0, kills: 0, action: -1, departed: false,
    gojoAscended: member?.gojoAscended || false, overkillMastery: member?.overkillMastery || false,
  };
}

function arenaSize(w: BattleFrame, characters: string[]) {
  const giant = characters.includes('gargantua_leviathan') ? 7 : characters.includes('leviathan') ? 4 : 1;
  w.width = 960 * giant;
  w.height = 780 * giant;
}

export function createBattle(room: PartyRoom): BattleFrame {
  const w: BattleFrame = {
    matchId: room.matchId || `practice-${Date.now()}`, config: { ...room.config }, players: room.members.length,
    time: 0, seed: Date.now() >>> 0, serial: 0, width: 960, height: 780,
    phase: 'countdown', phaseTimer: 2.4, wave: 1, completedWaves: 0, teamKills: 0, winner: null,
    fighters: [], shots: [], effects: [], fields: [], orbs: [], orbTimer: 5, cuts: [], cinematic: null, timeStop: null, shake: 0, banner: null,
  };
  arenaSize(w, [...room.members.map(m => m.characterId), room.config.enemyId]);
  w.fighters = room.members.map(m => fighter(getCharacterById(m.characterId), m.id, m.slot,
    room.config.mode === 'two_player' ? m.id : 'heroes', w, m));
  if (w.config.mode === 'boss_raid') {
    w.fighters.push(fighter(getCharacterById(w.config.enemyId), 'raid-boss', 0, 'enemies', w, undefined, true));
    const boss = w.fighters[w.fighters.length - 1];
    boss.x = w.width * 0.68; boss.y = w.height * 0.5;
  } else if (w.config.mode !== 'two_player') spawnWave(w);
  else {
    w.fighters.forEach((f, i) => {
      const a = (i / w.players) * TAU;
      f.x = w.width / 2 + Math.cos(a) * 250;
      f.y = w.height / 2 + Math.sin(a) * 220;
    });
  }
  return w;
}

function spawnWave(w: BattleFrame) {
  w.fighters = w.fighters.filter(f => !f.ai);
  const tierLimit = Math.min(4, Math.floor((w.config.played + w.wave * 3) / 16));
  const ranks = ['starter', 'common', 'rare', 'epic', 'legendary'];
  const pool = ALL_CHARACTERS.filter(c => c.rarity !== 'secret' && ranks.indexOf(c.rarity) >= 0 && ranks.indexOf(c.rarity) <= Math.max(1, tierLimit));
  for (let i = 0; i < w.players; i++) {
    const base = pool[Math.floor(random(w) * pool.length)] || getCharacterById('steve');
    const bot = fighter(base, `wave-${w.wave}-bot-${i}`, i, 'enemies', w);
    if (w.config.mode === 'endless') bot.hp = bot.maxHp += Math.floor((w.wave - 1) / 3);
    w.fighters.push(bot);
  }
}

function effect(w: BattleFrame, f: BattleFighter, kind: EffectKind, options: Partial<BattleEffect> = {}) {
  const fx: BattleEffect = {
    id: ++w.serial, kind, owner: f.id, x: f.x, y: f.y, angle: f.angle,
    size: 130, width: 24, color: C(f).glowColor, text: '', age: 0, duration: 0.75, delay: 0, damage: 0, hitIds: [], ...options,
  };
  w.effects.push(fx);
  return fx;
}

function shot(w: BattleFrame, f: BattleFighter, angle: number, damage: number, shape: BattleShot['shape'] = 'orb', options: Partial<BattleShot> = {}) {
  w.shots.push({
    id: ++w.serial, owner: f.id, x: f.x + Math.cos(angle) * (f.radius + 9), y: f.y + Math.sin(angle) * (f.radius + 9),
    vx: Math.cos(angle) * 340, vy: Math.sin(angle) * 340, radius: 7, damage, life: 3.5,
    color: C(f).glowColor, homing: false, shape, explode: 0, ...options,
  });
}

function beginCinematic(w: BattleFrame, f: BattleFighter, kind: NonNullable<BattleFrame['cinematic']>['kind'], duration: number) {
  w.cinematic = { kind, actor: f.id, age: 0, duration };
  w.banner = null;
}

function registerDeath(w: BattleFrame, victim: BattleFighter, source: BattleFighter) {
  if (w.config.mode === 'training') {
    victim.hp = victim.maxHp;
    victim.invulnerable = 1.4;
    effect(w, victim, 'portal', { color: '#baf66a', text: 'ВОССТАНОВЛЕНИЕ', size: 90 });
    return;
  }
  const c = C(victim);
  if (w.config.mode !== 'final_health' && c.secondLife && !victim.secondLife) {
    victim.secondLife = true;
    victim.maxHp = victim.hp = c.secondLife.maxHp;
    victim.radius *= c.secondLife.sizeMul;
    victim.speedMultiplier *= c.secondLife.speedMul;
    victim.damageMultiplier *= c.secondLife.damageMul || 1;
    victim.invulnerable = 1.5;
    if (!w.cinematic) beginCinematic(w, victim, 'revive', 2.4);
    return;
  }
  victim.hp = 0;
  source.kills++;
  if (victim.ai && source.team === 'heroes') w.teamKills++;
  effect(w, victim, 'hit', { size: 160, width: 6, color: c.glowColor, duration: 1.2, text: 'KO' });
  if (c.id === 'ultrakill' && !w.cinematic) beginCinematic(w, victim, 'erased', 2.7);
}

function applyDamage(w: BattleFrame, victim: BattleFighter, raw: number, source: BattleFighter, bypass = false) {
  if (!active(victim) || !active(source) || victim.team === source.team || victim.invulnerable > 0 || raw <= 0) return;
  if (C(victim).id === 'sans' && random(w) < 0.22) {
    victim.invulnerable = 0.3;
    victim.x = clamp(victim.x + (random(w) - 0.5) * 110, victim.radius, w.width - victim.radius);
    effect(w, victim, 'portal', { text: 'MISS', size: 55, color: '#7fbbff' }); return;
  }
  if (C(victim).id === 'error' && random(w) < 0.2) {
    effect(w, victim, 'glitch', { text: 'EXCEPTION', size: 65 }); victim.invulnerable = 0.3; return;
  }
  const ultra = victim.characterId === 'ultrakill';
  if (victim.shield > 0 && !bypass) {
    victim.shield--;
    victim.invulnerable = 0.24;
    effect(w, victim, 'ring', { text: 'БЛОК', color: '#7fdfff', size: victim.radius * 1.7 });
    return;
  }
  let amount = raw * source.damageMultiplier;
  if (victim.boss && !source.ai) amount *= Math.max(2, Math.min(18, bossBaseHp(victim.characterId) / 50));
  if (source.boss) amount = Math.min(3, amount);
  if (C(victim).id === 'flex') amount = Math.max(0.5, amount - 1);
  const before = victim.hp;
  if (ultra && victim.awakened && victim.hp <= 1 && w.config.mode !== 'final_health') {
    victim.lastStand = true;
    victim.hp = [0.9, 0.7, 0.5, 0.3, 0.1, 0.01, 0].find(h => h < victim.hp - 0.0001) ?? 0;
  } else if (ultra && before > 1 && before - amount <= 1 && w.config.mode !== 'final_health') {
    victim.hp = 1;
  } else victim.hp = roundHp(victim.hp - amount);
  const actual = Math.max(0, before - victim.hp);
  source.damage += actual;
  source.hits++;
  if (source.characterId === 'ultrakill') source.charge = clamp(source.charge + actual * 8, 0, 100);
  if (ultra) victim.charge = clamp(victim.charge + actual * 10, 0, 100);
  if (source.characterId === 'flex') source.damageMultiplier = Math.min(2.5, source.damageMultiplier + 0.1);
  if (ultra && victim.hp > 0 && victim.hp <= 1 && !victim.emergencyShieldUsed && w.config.mode !== 'final_health') {
    victim.shield = 5; victim.emergencyShieldUsed = true;
    effect(w, victim, 'ring', { color: '#80dcff', size: 95, text: 'ЩИТ: 5' });
  }
  victim.invulnerable = victim.ai ? 0.28 : 0.52;
  const a = Math.atan2(victim.y - source.y, victim.x - source.x);
  victim.vx += Math.cos(a) * 125 / Math.max(1, C(victim).weight);
  victim.vy += Math.sin(a) * 125 / Math.max(1, C(victim).weight);
  w.shake = Math.min(15, 5 + actual * 2);
  effect(w, victim, 'hit', { color: '#f7c2cd', size: 48, text: `-${Number(actual.toFixed(2))}`, duration: 0.65 });
  if (victim.hp <= 0) registerDeath(w, victim, source);
}

export function activateAbility(w: BattleFrame, f: BattleFighter, id: string): boolean {
  if (!active(f) || f.frozen > 0 || f.castTimer > 0 || w.cinematic || w.phase !== 'fighting') return false;
  const option = abilityOptions(f).find(o => o.ability.id === id);
  if (!option || option.locked || (f.cooldowns[id] || 0) > 0) return false;
  const target = nearest(w, f);
  if (!target) return false;
  const ab = option.ability;
  const a = Math.atan2(target.y - f.y, target.x - f.x);
  f.angle = a;
  f.castTimer = 0.18;
  f.cooldowns[id] = ab.cooldown;
  const d = Math.max(1, ab.damage);
  const color = ab.particleColor || C(f).glowColor;
  w.banner = { text: ab.nameRu, color, left: 1.4 };
  const nova = (radius = 200, damage = d, delay = 0.25) => effect(w, f, 'ring', { size: radius, damage, delay, duration: 0.95, color });
  const beam = (angle = a, damage = d, delay = 0.38, width = 38, length = Math.hypot(w.width, w.height)) =>
    effect(w, f, 'beam', { angle, size: length, damage, delay, duration: delay + 0.45, width, color });
  const volley = (count = 3, shape: BattleShot['shape'] = 'orb', homing = false, spread = 0.22) => {
    for (let i = 0; i < count; i++) shot(w, f, a + (i - (count - 1) / 2) * spread, count > 6 ? 1 : d, shape, { homing, color });
  };
  const slash = (size = 230, damage = d, delay = 0.12) => effect(w, f, 'slash', { angle: a, size, width: 70, damage, delay, duration: 0.7, color });

  switch (ab.effectType) {
    case 'ultra_ascend': beginCinematic(w, f, 'ultra', 5.2); f.charge = 0; break;
    case 'final_ritual': beginCinematic(w, f, 'final', 3); break;
    case 'hollow_purple': beginCinematic(w, f, 'purple', 3.4); break;
    case 'ultra_sword': slash(270, d); break;
    case 'ultra_arena_cut':
      slash(Math.hypot(w.width, w.height), d, 0.42);
      w.cuts.push({ x: f.x, y: f.y, angle: a, color: '#d391ff' });
      if (w.cuts.length > 6) w.cuts.shift();
      w.shake = 23; break;
    case 'ultra_rainbow_blaster':
      for (let i = 0; i < 3; i++) {
        const fx = beam(a + (i - 1) * 0.1, d, 0.45 + i * 0.12, 44);
        fx.color = SPECTRUM[i * 2];
      } break;
    case 'ultra_railcoin':
      effect(w, f, 'portal', { x: f.x + Math.cos(a) * 70, y: f.y + Math.sin(a) * 70, size: 24, color: '#ffe27f', duration: 0.5 });
      beam(a, d, 0.28, 25); break;
    case 'ultra_parry_dash':
      w.shots = w.shots.filter(p => w.fighters.find(o => o.id === p.owner)?.team === f.team || dist(p, f) > 250);
      f.invulnerable = 0.75; f.vx = Math.cos(a) * 580; f.vy = Math.sin(a) * 580; slash(320); break;
    case 'ultra_slam': nova(250); f.vx = Math.cos(a) * 460; f.vy = Math.sin(a) * 460; break;
    case 'circle_barrage':
      for (let i = 0; i < 7; i++) {
        const ba = i / 7 * TAU;
        const x = target.x + Math.cos(ba) * 390, y = target.y + Math.sin(ba) * 390;
        effect(w, f, 'beam', { x, y, angle: ba + Math.PI, width: 38, size: 860, delay: 0.5 + i * 0.28, duration: 0.95 + i * 0.28, damage: d, color: SPECTRUM[i] });
      } break;
    case 'circle_nova':
      for (let i = 0; i < 7; i++) effect(w, f, 'ring', { size: 160 + i * 35, damage: d, delay: i * 0.14, duration: 0.9 + i * 0.14, color: SPECTRUM[i] });
      break;
    case 'gojo_blue':
    case 'gojo_red':
      w.fields.push({ owner: f.id, kind: ab.effectType === 'gojo_blue' ? 'blue' : 'red',
        x: f.x + Math.cos(a) * 145, y: f.y + Math.sin(a) * 145, age: 0, tick: 0,
        duration: ab.effectType === 'gojo_blue' ? 4.4 : 2.2, radius: 220, captured: {} }); break;
    case 'domain_infinite':
      w.fields.push({ owner: f.id, kind: 'domain', x: f.x, y: f.y, radius: 540, age: 0, tick: 0, duration: 4, captured: {} });
      effect(w, f, 'dome', { size: 540, duration: 4, color }); break;
    case 'time_freeze':
      w.timeStop = { owner: f.id, left: 2.5 };
      enemies(w, f).forEach(e => { e.frozen = 2.5; e.vx = 0; e.vy = 0; });
      effect(w, f, 'dome', { color: '#e8cb86', size: 360, duration: 2.5 }); break;
    case 'sans_blaster_wall':
    case 'sans_bad_time': {
      const n = ab.effectType === 'sans_bad_time' ? 6 : 4;
      for (let i = 0; i < n; i++) {
        const ba = i / n * TAU;
        effect(w, f, 'beam', { x: target.x + Math.cos(ba) * 290, y: target.y + Math.sin(ba) * 290,
          angle: ba + Math.PI, size: 640, width: 28, delay: 0.6 + i * 0.08, duration: 1.2 + i * 0.08, damage: d, color: '#84eaff' });
      }
      if (n === 6) volley(9, 'bone', false, 0.3);
      break;
    }
    case 'sans_bone_zone':
      for (let i = 0; i < 10; i++) {
        const ba = i / 10 * TAU;
        shot(w, f, ba + Math.PI, 1, 'bone', { x: target.x + Math.cos(ba) * 220, y: target.y + Math.sin(ba) * 220, color: '#e4f7ff' });
      }
      effect(w, f, 'bones', { x: target.x, y: target.y, size: 225, delay: 0.35, duration: 2, color: '#e4f7ff' }); break;
    case 'sans_blue_soul':
      target.frozen = 0.5;
      effect(w, f, 'bolt', { x: target.x, y: target.y, size: 90, damage: d, delay: 0.4, duration: 0.8, color: '#77a6ff' });
      target.vy = 460; break;
    case 'ender_cataclysm':
      volley(10, 'orb', true, 0.2); nova(220, 1);
      effect(w, f, 'portal', { size: 220, duration: 1.6, color: '#c275ff' }); break;
    case 'dragon_breath':
    case 'flame_cone':
      for (let i = 0; i < 5; i++) beam(a + (i - 2) * 0.13, 1, 0.4, 24, 340);
      break;
    case 'sonic_ring':
      for (let i = 0; i < 3; i++) effect(w, f, 'ring', { size: 180 + i * 95, delay: 0.15 + i * 0.3, duration: 0.8 + i * 0.3, damage: d, color }); break;
    case 'sonic_boom':
    case 'sniper_pierce':
    case 'sudo_rm':
    case 'gaster_blaster': beam(a, d, 0.45, 36); break;
    case 'math_strike':
      target.frozen = 1;
      effect(w, f, 'slash', { x: target.x, y: target.y, size: 160, angle: a, width: 80, damage: d, delay: 0.4, duration: 1, color, text: 'К ДОСКЕ' }); break;
    case 'boss_slam':
    case 'tentacle_grasp':
      target.vx = -Math.cos(a) * 240; target.vy = -Math.sin(a) * 240;
      effect(w, f, 'eruption', { x: target.x, y: target.y, size: 120, delay: 0.65, duration: 1.4, damage: d, color }); break;
    case 'singularity_devour':
    case 'black_hole':
    case 'void_collapse':
      w.fields.push({ owner: f.id, kind: 'void', x: f.x, y: f.y, radius: 280, age: 0, tick: 0, duration: 3, captured: {} });
      f.hp = Math.min(f.maxHp, f.hp + (ab.effectType === 'singularity_devour' ? 2 : 1));
      w.shots = w.shots.filter(p => w.fighters.find(o => o.id === p.owner)?.team === f.team || dist(p, f) > 270); break;
    case 'error_corrupt':
    case 'glitch_rewrite':
      target.frozen = 1;
      effect(w, f, 'glitch', { x: target.x, y: target.y, size: 180, delay: 0.4, duration: 1.4, damage: d, color });
      volley(6, 'pixel', true, 0.45); break;
    case 'god_smite_rework':
    case 'divine_smite':
      effect(w, f, 'bolt', { x: target.x, y: target.y, size: 140, damage: d, delay: 0.65, duration: 1.3, color: '#ffe6a5' });
      f.hp = Math.min(f.maxHp, f.hp + 2); f.shield = Math.min(2, f.shield + 1); break;
    case 'flex_overpower':
      f.damageMultiplier = Math.min(2.5, f.damageMultiplier + 0.25); f.shield = Math.min(2, f.shield + 1); nova(260); break;
    case 'lightning_tempest':
      f.invulnerable = 0.8;
      for (let i = 0; i < 5; i++) effect(w, f, 'bolt', { x: target.x + (random(w) - 0.5) * 180, y: target.y + (random(w) - 0.5) * 180,
        size: 90, damage: 1.5, delay: 0.2 + i * 0.14, duration: 0.8 + i * 0.14, color: i % 2 ? '#e6f8a6' : '#86eeff' }); break;
    case 'robot_transform':
      if (f.transformTime <= 0) { f.radius *= 1.6; f.damageMultiplier *= 1.4; f.transformTime = 7; f.charge = 0; }
      nova(210); break;
    case 'plasma_overdrive':
      for (let i = 0; i < (id === 'overkill_mastery' ? 12 : 8); i++) shot(w, f, i / (id === 'overkill_mastery' ? 12 : 8) * TAU, 2, 'rocket', { explode: 70, color });
      nova(170, 1); break;
    case 'overkill_inferno':
    case 'solar_flare': nova(340); break;
    case 'repulsion_pulse':
      if (id.includes('shield') || id.includes('determination')) { f.shield = 1; f.hp = Math.min(f.maxHp, f.hp + 1); }
      nova(240); break;
    case 'dash_strike':
    case 'slash_9999':
    case 'speed_hack':
    case 'kagune_frenzy':
      f.vx = Math.cos(a) * 530; f.vy = Math.sin(a) * 530; f.invulnerable = 0.25; slash(320); break;
    case 'katana_cut': slash(Math.hypot(w.width, w.height), d); break;
    case 'freeze_wave':
    case 'jumpscare':
    case 'emergency_meeting':
    case 'bsod_error':
      enemies(w, f).filter(e => dist(f, e) < 480).forEach(e => { e.frozen = 1.2; e.vx = e.vy = 0; });
      nova(420, 1); break;
    case 'vent_ambush':
    case 'glitch_clone':
      effect(w, f, 'portal', { size: 70, duration: 0.8 });
      f.x = clamp(target.x - Math.cos(a) * 100, f.radius, w.width - f.radius);
      f.y = clamp(target.y - Math.sin(a) * 100, f.radius, w.height - f.radius);
      f.invulnerable = 0.6; slash(170); break;
    case 'tnt_block':
      effect(w, f, 'eruption', { x: target.x, y: target.y, size: 170, delay: 1, duration: 1.6, damage: d, color: '#ffae67' }); break;
    case 'rocket_barrage':
      if (f.characterId === 'volcanic_ash') {
        for (const enemy of enemies(w, f)) effect(w, f, 'eruption', { x: enemy.x, y: enemy.y, size: 110, damage: 2, delay: 0.95, duration: 1.8, color: '#ff974f' });
        volley(9, 'rocket', false, 0.4);
      } else volley(5, 'rocket', false, 0.18);
      break;
    case 'knife_storm': volley(9, 'blade', false, 0.3); break;
    case 'spawn_minions': volley(3, 'orb', true, 1.5); break;
    case 'admin_ban': effect(w, f, 'beam', { angle: a, size: 900, width: 90, delay: 0.7, duration: 1.2, damage: d, color }); break;
    case 'hadouken': volley(3); break;
    case 'sugarok_revive': f.hp = Math.min(f.maxHp, f.hp + 2); nova(150, 1); break;
    case 'mystery_chaos':
      if (random(w) < 0.5) { f.shield = 1; volley(6, 'pixel', true); }
      else { nova(300); f.hp = Math.min(f.maxHp, f.hp + 1); }
      break;
    default: { const exhaustive: never = ab.effectType; void exhaustive; }
  }
  return true;
}

function finishCinematic(w: BattleFrame) {
  const cine = w.cinematic;
  if (!cine) return;
  const f = w.fighters.find(e => e.id === cine.actor);
  if (!f) { w.cinematic = null; return; }
  if (cine.kind === 'ultra') {
    f.awakened = true; f.hp = roundHp(f.maxHp * 0.9); f.damageMultiplier *= 1.25; f.speedMultiplier *= 1.25;
    f.invulnerable = 1.2; f.castTimer = 0; f.emergencyShieldUsed = false;
  } else if (cine.kind === 'final') {
    f.awakened = true; f.hp = f.maxHp; f.speedMultiplier *= 2.2; f.damageMultiplier = 1.6; f.invulnerable = 1;
  } else if (cine.kind === 'purple') {
    const foe = nearest(w, f);
    if (foe) effect(w, f, 'beam', { angle: Math.atan2(foe.y - f.y, foe.x - f.x), size: Math.hypot(w.width, w.height) * 2,
      width: 120, damage: 6, delay: 0, duration: 1.1, color: '#c287ff' });
    w.shake = 22;
  }
  w.cinematic = null;
}

function effectHits(fx: BattleEffect, target: BattleFighter): boolean {
  if (fx.kind === 'beam' || fx.kind === 'slash') {
    const dx = target.x - fx.x, dy = target.y - fx.y;
    const along = dx * Math.cos(fx.angle) + dy * Math.sin(fx.angle);
    const perpendicular = Math.abs(-dx * Math.sin(fx.angle) + dy * Math.cos(fx.angle));
    return along > -target.radius && along < fx.size && perpendicular < fx.width / 2 + target.radius;
  }
  return dist(fx, target) <= fx.size + target.radius;
}

function moveInBounds(w: BattleFrame, f: BattleFighter, dt: number) {
  f.x += f.vx * dt; f.y += f.vy * dt;
  const margin = Math.min(f.radius, w.width * 0.12, w.height * 0.12);
  if (f.x < margin) { f.x = margin; f.vx = Math.abs(f.vx); }
  if (f.x > w.width - margin) { f.x = w.width - margin; f.vx = -Math.abs(f.vx); }
  if (f.y < margin) { f.y = margin; f.vy = Math.abs(f.vy); }
  if (f.y > w.height - margin) { f.y = w.height - margin; f.vy = -Math.abs(f.vy); }
}

function checkEnd(w: BattleFrame) {
  if (w.config.mode === 'training') return;
  const humans = w.fighters.filter(f => !f.ai && active(f));
  if (w.config.mode === 'two_player') {
    if (humans.length <= 1) { w.phase = 'finished'; w.winner = humans[0]?.id || 'draw'; }
    return;
  }
  if (!humans.length) { w.phase = 'finished'; w.winner = 'enemies'; return; }
  if (w.fighters.some(f => f.ai && active(f))) return;
  if (w.config.mode !== 'endless') { w.phase = 'finished'; w.winner = 'heroes'; return; }
  w.completedWaves++;
  w.wave++;
  w.phase = 'intermission';
  w.phaseTimer = 2.1;
  w.shots = []; w.fields = []; w.orbs = [];
  w.banner = { text: `ВОЛНА ${w.wave} ПРИБЛИЖАЕТСЯ`, color: '#baf66a', left: 2.1 };
  for (const f of w.fighters.filter(f => !f.ai && !f.departed)) {
    if (w.config.endless !== 'last') {
      f.hp = f.hp <= 0 ? Math.ceil(f.maxHp * 0.5) : Math.min(f.maxHp, f.hp + (w.config.endless === 'standard' ? 2 : 1));
      f.invulnerable = 1.4;
    }
  }
}

export function stepBattle(w: BattleFrame, seconds: number, inputs: Map<string, TimedInput>, connectedMembers: Set<string>, now = Date.now()) {
  const dt = clamp(seconds, 0, 0.04);
  if (w.phase === 'finished') return;
  w.shake *= Math.exp(-dt * 8);
  // Disconnecting one member never silently transfers their fighter to another peer.
  for (const f of w.fighters) if (!f.ai && !connectedMembers.has(f.id)) { f.departed = true; f.hp = 0; }
  if (w.cinematic) {
    w.cinematic.age += dt;
    if (w.cinematic.age >= w.cinematic.duration) { finishCinematic(w); checkEnd(w); }
    return;
  }
  w.time += dt;
  if (w.banner) { w.banner.left -= dt; if (w.banner.left <= 0) w.banner = null; }
  if (w.timeStop) { w.timeStop.left -= dt; if (w.timeStop.left <= 0) w.timeStop = null; }
  if (w.phase === 'countdown' || w.phase === 'intermission') {
    w.phaseTimer -= dt;
    if (w.phaseTimer <= 0) {
      if (w.phase === 'intermission') spawnWave(w);
      w.phase = 'fighting';
    }
    return;
  }

  for (const f of w.fighters) {
    if (!active(f)) continue;
    const c = C(f);
    const stopped = w.timeStop && w.timeStop.owner !== f.id;
    f.invulnerable = Math.max(0, f.invulnerable - dt);
    f.frozen = Math.max(0, f.frozen - dt);
    f.castTimer = Math.max(0, f.castTimer - dt);
    if (stopped) continue;
    for (const key of Object.keys(f.cooldowns)) f.cooldowns[key] = Math.max(0, f.cooldowns[key] - dt);
    if (f.transformTime > 0) {
      f.transformTime -= dt;
      if (f.transformTime <= 0) { f.radius /= 1.6; f.damageMultiplier /= 1.4; }
    }
    f.regen += dt;
    if (c.id === 'god' && f.regen >= 6) { f.regen = 0; f.hp = Math.min(f.maxHp, f.hp + 1); }
    if (c.id === 'ultrakill' && f.awakened) {
      f.shieldTimer -= dt;
      if (f.shieldTimer <= 0) { f.shieldTimer = 15; if (random(w) < 0.2 && f.hp > 1) f.shield = Math.max(f.shield, 1); }
    }
    let ax = 0, ay = 0, dash = false;
    const foe = nearest(w, f);
    if (f.ai && foe) {
      if (w.config.mode !== 'training') {
        const a = Math.atan2(foe.y - f.y, foe.x - f.x) + Math.sin(w.time * 1.3 + f.slot) * 0.45;
        ax = Math.cos(a); ay = Math.sin(a);
        f.thought -= dt;
        if (f.thought <= 0) {
          f.thought = 1.2 + random(w) * Math.max(0.3, 1.8 - w.config.played / 50);
          const available = abilityOptions(f).filter(o => !o.locked && !(f.cooldowns[o.ability.id] > 0));
          const option = available[Math.floor(random(w) * available.length)];
          if (option) activateAbility(w, f, option.ability.id);
        }
      }
    } else if (!f.ai) {
      const entry = inputs.get(f.id);
      if (entry && now - entry.receivedAt < 450) {
        ax = entry.value.x; ay = entry.value.y; dash = entry.value.dash;
        if (entry.value.action > f.action) {
          f.action = entry.value.action;
          if (entry.value.ability) activateAbility(w, f, entry.value.ability);
        }
      }
    }
    if (w.cinematic) return;
    const norm = Math.max(1, Math.hypot(ax, ay));
    const speed = (c.baseSpeed + (c.speedBonus || 0) * 0.1) * (c.speedMultiplier || 1) * f.speedMultiplier;
    const maxV = speed * 38 * (dash ? 1.3 : 1) * (f.ai ? 0.78 : 1);
    if (f.frozen <= 0) {
      f.vx += ax / norm * 530 * dt; f.vy += ay / norm * 530 * dt;
      const v = Math.hypot(f.vx, f.vy);
      if (v > maxV) { f.vx *= maxV / v; f.vy *= maxV / v; }
      if (Math.hypot(ax, ay) < 0.1 && v > 55) { f.vx *= Math.exp(-dt * 0.35); f.vy *= Math.exp(-dt * 0.35); }
      moveInBounds(w, f, dt);
    }
    if (foe) f.angle = Math.atan2(foe.y - f.y, foe.x - f.x);
    f.attackTimer = Math.max(0, f.attackTimer - dt);
    // Ranged weapon users retain a passive attack, independent of their skill palette.
    if (foe && f.attackTimer <= 0 && f.frozen <= 0) {
      if (['guns', 'sniper', 'rpg', 'blaster', 'flamethrower', 'terminal'].includes(c.weaponType)) {
        f.attackTimer = f.ai ? 2.1 : 1.25;
        shot(w, f, f.angle, 1, c.weaponType === 'rpg' ? 'rocket' : c.weaponType === 'terminal' ? 'pixel' : 'bullet', { explode: c.weaponType === 'rpg' ? 65 : 0 });
      }
    }
  }

  for (let i = 0; i < w.fighters.length; i++) for (let j = i + 1; j < w.fighters.length; j++) {
    const a = w.fighters[i], b = w.fighters[j];
    if (!active(a) || !active(b)) continue;
    let dx = b.x - a.x, dy = b.y - a.y, distance = Math.hypot(dx, dy);
    if (distance < 0.001) { dx = 1; dy = 0; distance = 1; }
    if (distance < a.radius + b.radius) {
      const nx = dx / distance, ny = dy / distance, overlap = a.radius + b.radius - distance;
      a.x -= nx * overlap / 2; a.y -= ny * overlap / 2; b.x += nx * overlap / 2; b.y += ny * overlap / 2;
      const impact = (b.vx - a.vx) * nx + (b.vy - a.vy) * ny;
      if (impact < 0) { a.vx += nx * impact; a.vy += ny * impact; b.vx -= nx * impact; b.vy -= ny * impact; }
    }
    if (a.team === b.team) continue;
    for (const [f, victim] of [[a, b], [b, a]]) {
      if (f.frozen > 0) continue;
      const c = C(f);
      const armed = c.hasSpikes || f.spikes || ['sword', 'swords_ring', 'knife', 'claws', 'boss_gloves', 'robot_arm', 'overkill_fist'].includes(c.weaponType);
      const range = f.radius + victim.radius + c.weaponReach * 0.55;
      if (armed && distance < range && f.attackTimer <= 0) {
        let base = ['overkill_glove', 'final', 'god', 'error', 'flex'].includes(c.id) ? 3 : 1;
        if (f.spikes) { base++; f.spikes = false; }
        applyDamage(w, victim, base, f);
        f.attackTimer = 0.65;
      }
    }
  }

  for (const p of w.shots) {
    const source = w.fighters.find(f => f.id === p.owner);
    if (!source || !active(source)) { p.life = 0; continue; }
    if (w.timeStop && w.timeStop.owner !== p.owner) continue;
    p.life -= dt;
    if (p.homing) {
      const foe = nearest(w, { ...source, x: p.x, y: p.y });
      if (foe) {
        const a = Math.atan2(foe.y - p.y, foe.x - p.x);
        p.vx += Math.cos(a) * dt * 220; p.vy += Math.sin(a) * dt * 220;
        const v = Math.hypot(p.vx, p.vy); if (v > 410) { p.vx *= 410 / v; p.vy *= 410 / v; }
      }
    }
    p.x += p.vx * dt; p.y += p.vy * dt;
    for (const victim of enemies(w, source)) if (dist(p, victim) < p.radius + victim.radius) {
      applyDamage(w, victim, p.damage, source);
      if (p.explode) effect(w, source, 'eruption', { x: p.x, y: p.y, size: p.explode, damage: 1, color: p.color });
      p.life = 0; break;
    }
    if (p.x < -100 || p.y < -100 || p.x > w.width + 100 || p.y > w.height + 100) p.life = 0;
  }
  w.shots = w.shots.filter(p => p.life > 0).slice(-180);
  for (const fx of w.effects) {
    fx.age += dt;
    if (fx.damage <= 0 || fx.age < fx.delay) continue;
    const source = w.fighters.find(f => f.id === fx.owner);
    if (!source) continue;
    for (const victim of enemies(w, source)) if (!fx.hitIds.includes(victim.id) && effectHits(fx, victim)) {
      fx.hitIds.push(victim.id);
      applyDamage(w, victim, fx.damage, source);
    }
  }
  w.effects = w.effects.filter(e => e.age < e.duration).slice(-150);
  for (const field of w.fields) {
    const source = w.fighters.find(f => f.id === field.owner);
    if (!source || !active(source)) { field.age = field.duration; continue; }
    field.age += dt; field.tick += dt;
    if (field.kind === 'blue') {
      const a = field.age * 1.9;
      field.x = w.width / 2 + Math.cos(a) * w.width * 0.44;
      field.y = w.height / 2 + Math.sin(a) * w.height * 0.44;
    }
    for (const victim of enemies(w, source)) if (dist(field, victim) < field.radius + victim.radius) {
      if (!field.captured[victim.id]) field.captured[victim.id] = { x: victim.x, y: victim.y };
      if (field.kind === 'domain') victim.frozen = 0.2;
      else { victim.vx += (field.x - victim.x) * dt * 4; victim.vy += (field.y - victim.y) * dt * 4; }
      if (field.tick >= 0.8 && field.kind !== 'red') applyDamage(w, victim, 1, source);
    }
    if (field.tick >= 0.8) field.tick = 0;
    if (field.age >= field.duration) {
      if (field.kind === 'blue') for (const victim of w.fighters) {
        const position = field.captured[victim.id];
        if (position && active(victim)) { victim.x = position.x; victim.y = position.y; victim.vx = victim.vy = 0; }
      }
      if (field.kind === 'red') effect(w, source, 'ring', { x: field.x, y: field.y, size: 230, color: '#ff6486', damage: 3, duration: 0.65 });
    }
  }
  w.fields = w.fields.filter(f => f.age < f.duration);

  if (w.config.mode !== 'final_health') {
    w.orbTimer -= dt;
    if (w.orbTimer <= 0 && w.orbs.length < 4) {
      w.orbTimer = w.config.mode === 'boss_raid' ? 4.5 : 7;
      const types: ('shield' | 'spikes' | 'heal')[] = w.config.mode === 'boss_raid' ? ['heal', 'shield', 'heal'] : ['spikes', 'shield'];
      w.orbs.push({ id: ++w.serial, x: w.width * (0.2 + random(w) * 0.6), y: w.height * (0.2 + random(w) * 0.6), type: types[Math.floor(random(w) * types.length)], age: 0 });
    }
    for (const orb of w.orbs) {
      orb.age += dt;
      const collector = w.fighters.find(f => active(f) && !f.boss && dist(f, orb) < f.radius + 16);
      if (collector) {
        if (orb.type === 'shield') collector.shield = Math.max(1, collector.shield);
        if (orb.type === 'spikes') collector.spikes = true;
        if (orb.type === 'heal') collector.hp = Math.min(collector.maxHp, collector.hp + 3);
        effect(w, collector, 'ring', { size: 75, color: '#baf66a', text: orb.type === 'heal' ? '+3 HP' : orb.type === 'shield' ? 'ЩИТ' : 'ШИПЫ' });
        orb.age = 99;
      }
    }
    w.orbs = w.orbs.filter(o => o.age < 18);
  }
  if (!w.cinematic) checkEnd(w);
}