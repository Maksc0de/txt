import { getCharacterById } from '../data/characters';
import { drawCharacterAvatar } from '../utils/characterRenderer';
import type { GameSettings } from '../types/game';
import type { BattleEffect, BattleFighter, BattleFrame } from './battleTypes';
import { PLAYER_COLORS } from './protocol';
import { SPECTRUM } from './battleEngine';

const TAU = Math.PI * 2;
const clamp = (x: number, a: number, b: number) => Math.min(b, Math.max(a, x));
export interface BattleCamera { x: number; y: number; zoom: number; overview: boolean }
export const newCamera = (): BattleCamera => ({ x: 480, y: 390, zoom: 0.8, overview: false });

function rgba(hex: string, opacity: number) {
  if (!/^#[0-9a-f]{6}$/i.test(hex)) return `rgba(186,246,106,${opacity})`;
  const value = Number.parseInt(hex.slice(1), 16);
  return `rgba(${(value >> 16) & 255},${(value >> 8) & 255},${value & 255},${opacity})`;
}
function circle(ctx: CanvasRenderingContext2D, x: number, y: number, r: number) {
  ctx.beginPath(); ctx.arc(x, y, Math.max(0.1, r), 0, TAU);
}

function actor(ctx: CanvasRenderingContext2D, f: BattleFighter, time: number, alpha = 1) {
  let c = getCharacterById(f.characterId);
  if (f.secondLife && c.secondLife) c = { ...c, name: c.secondLife.name, avatarColor: c.secondLife.avatarColor, glowColor: c.secondLife.glowColor };
  if (f.awakened && c.id === 'ultrakill') c = { ...c, weaponType: 'sword', weaponColor: SPECTRUM[Math.floor(time / 180) % 7] };
  ctx.save();
  ctx.globalAlpha = alpha;
  drawCharacterAvatar(ctx, c, f.x, f.y, f.radius, f.angle, time / 420, {
    hp: f.hp, maxHp: f.maxHp, hasShield: f.shield > 0, hasSpikesBuff: f.spikes,
    sugarokForm: f.secondLife, finalCircles: f.awakened, isTransformed: false,
  });
  if (f.frozen > 0) {
    ctx.fillStyle = '#96d6ff26'; ctx.strokeStyle = '#b2e4ff'; ctx.lineWidth = 2;
    circle(ctx, f.x, f.y, f.radius * 1.16); ctx.fill(); ctx.stroke();
  }
  if (f.awakened && c.id === 'final') for (let i = 0; i < 7; i++) {
    const a = time / 440 + i / 7 * TAU;
    ctx.fillStyle = SPECTRUM[i]; ctx.shadowColor = SPECTRUM[i]; ctx.shadowBlur = 12;
    circle(ctx, f.x + Math.cos(a) * f.radius * 1.85, f.y + Math.sin(a) * f.radius * 1.85, 7);
    ctx.fill();
  }
  if (c.id === 'lighting_secret' && Math.hypot(f.vx, f.vy) > 40) {
    ctx.strokeStyle = '#a9f4ff'; ctx.lineWidth = 2;
    for (let k = 0; k < 2; k++) {
      ctx.beginPath(); ctx.moveTo(f.x, f.y);
      for (let i = 1; i < 8; i++) ctx.lineTo(f.x - f.vx * i * 0.025 + Math.sin(time / 70 + i * 4 + k) * 10, f.y - f.vy * i * 0.025 + Math.cos(i * 3 + time / 90 + k) * 10);
      ctx.stroke();
    }
  }
  ctx.restore();
}

function skull(ctx: CanvasRenderingContext2D, color: string, size: number) {
  ctx.fillStyle = '#e9f0f2'; ctx.strokeStyle = color; ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(-size * 0.8, -size * 0.7);
  ctx.quadraticCurveTo(-size * 1.4, 0, -size * 0.55, size * 0.7);
  ctx.lineTo(size * 0.65, size * 0.42); ctx.lineTo(size, 0); ctx.lineTo(size * 0.65, -size * 0.42); ctx.closePath(); ctx.fill(); ctx.stroke();
  ctx.fillStyle = '#09101c';
  ctx.beginPath(); ctx.ellipse(-size * 0.1, -size * 0.31, size * 0.34, size * 0.19, 0.25, 0, TAU); ctx.fill();
  ctx.beginPath(); ctx.ellipse(-size * 0.1, size * 0.31, size * 0.34, size * 0.19, -0.25, 0, TAU); ctx.fill();
}

function drawEffect(ctx: CanvasRenderingContext2D, fx: BattleEffect, time: number, high: boolean) {
  const telegraph = fx.age < fx.delay;
  const progress = clamp((fx.age - fx.delay) / Math.max(0.1, fx.duration - fx.delay), 0, 1);
  const opacity = telegraph ? 0.32 + 0.18 * Math.sin(time / 65) : 1 - progress * 0.85;
  ctx.save(); ctx.globalAlpha = opacity;
  ctx.translate(fx.x, fx.y); ctx.rotate(fx.angle);
  ctx.strokeStyle = fx.color; ctx.fillStyle = fx.color;
  ctx.shadowColor = fx.color; ctx.shadowBlur = high && !telegraph ? 16 : 0;
  if (telegraph) ctx.setLineDash([9, 10]);
  if (fx.kind === 'beam') {
    skull(ctx, fx.color, 27);
    if (telegraph) {
      ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(25, 0); ctx.lineTo(fx.size, 0); ctx.stroke();
    } else {
      const g = ctx.createLinearGradient(0, 0, fx.size, 0);
      g.addColorStop(0, fx.color); g.addColorStop(0.7, rgba(fx.color, 0.7)); g.addColorStop(1, rgba(fx.color, 0));
      ctx.fillStyle = g; ctx.fillRect(24, -fx.width / 2, fx.size, fx.width);
      ctx.fillStyle = '#ffffff'; ctx.fillRect(24, -fx.width * 0.17, fx.size * 0.92, fx.width * 0.34);
    }
  } else if (fx.kind === 'slash') {
    ctx.lineWidth = telegraph ? 2 : 2 + (1 - progress) * 6;
    ctx.beginPath(); ctx.moveTo(-20, -9); ctx.lineTo(fx.size, 9); ctx.stroke();
    if (!telegraph) { ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(-20, 0); ctx.lineTo(fx.size, 0); ctx.stroke(); }
  } else if (fx.kind === 'bolt') {
    ctx.lineWidth = 3;
    ctx.beginPath(); ctx.moveTo(0, -500);
    for (let i = 1; i <= 10; i++) ctx.lineTo(Math.sin(i * 13 + time / 70) * 30, -500 + i * 50);
    ctx.stroke(); circle(ctx, 0, 0, telegraph ? fx.size : fx.size * progress); ctx.stroke();
  } else if (fx.kind === 'glitch') {
    for (let i = 0; i < 9; i++) {
      ctx.fillStyle = i % 2 ? '#ff598d' : fx.color;
      ctx.fillRect(Math.sin(i * 5 + time / 85) * fx.size, Math.cos(i * 2 + time / 110) * fx.size, 20 + i * 5, 5);
    }
  } else if (fx.kind === 'hit') {
    if (high) for (let i = 0; i < 9; i++) {
      const a = i / 9 * TAU;
      ctx.fillRect(Math.cos(a) * fx.size * progress, Math.sin(a) * fx.size * progress, 3, 3);
    }
  } else {
    const radius = fx.kind === 'portal' || fx.kind === 'dome' || telegraph ? fx.size : Math.max(8, fx.size * progress);
    ctx.lineWidth = fx.kind === 'eruption' ? 5 : 2;
    ctx.fillStyle = rgba(fx.color, 0.06);
    circle(ctx, 0, 0, radius); ctx.fill(); ctx.stroke();
    if (fx.kind === 'bones') for (let i = 0; i < 16; i++) {
      const a = i / 16 * TAU;
      ctx.save(); ctx.rotate(a); ctx.fillStyle = '#eaf6ff'; ctx.fillRect(radius - 14, -4, 28, 8); ctx.restore();
    }
    if (fx.kind === 'eruption' && !telegraph) {
      ctx.beginPath();
      for (let i = 0; i < 10; i++) { const a = i / 10 * TAU; ctx.moveTo(0, 0); ctx.lineTo(Math.cos(a) * radius, Math.sin(a) * radius); }
      ctx.stroke();
    }
  }
  ctx.restore();
  if (fx.text) {
    ctx.save(); ctx.globalAlpha = Math.max(0, 1 - fx.age / fx.duration);
    ctx.font = '700 16px system-ui'; ctx.textAlign = 'center'; ctx.fillStyle = fx.color;
    ctx.fillText(fx.text, fx.x, fx.y - 48 - fx.age * 20); ctx.restore();
  }
}

export function drawOnlineBattle(
  ctx: CanvasRenderingContext2D, w: BattleFrame, camera: BattleCamera,
  localId: string, width: number, height: number, time: number, settings: GameSettings,
) {
  ctx.clearRect(0, 0, width, height);
  ctx.fillStyle = '#080c11'; ctx.fillRect(0, 0, width, height);
  const high = settings.particleDensity !== 'low';
  const focus = w.fighters.find(f => f.id === localId) || w.fighters[0];
  if (!focus) return;
  const alive = w.fighters.filter(f => f.hp > 0);
  const viewFocus = focus.hp > 0 ? focus : alive.find(f => f.team === focus.team) || focus;
  const enemy = alive.filter(f => f.team !== viewFocus.team).sort((a, b) => Math.hypot(a.x - viewFocus.x, a.y - viewFocus.y) - Math.hypot(b.x - viewFocus.x, b.y - viewFocus.y))[0];
  const giant = w.width > 1600;
  let zoom = camera.overview || !giant ? Math.min((width - 42) / w.width, (height - 38) / w.height) : Math.min(width / 850, height / 730);
  zoom = Math.max(0.07, Math.min(1.35, zoom));
  const targetX = giant && !camera.overview ? viewFocus.x + (enemy && Math.abs(enemy.x - viewFocus.x) < 520 ? (enemy.x - viewFocus.x) * 0.28 : 0) : w.width / 2;
  const targetY = giant && !camera.overview ? viewFocus.y + (enemy && Math.abs(enemy.y - viewFocus.y) < 520 ? (enemy.y - viewFocus.y) * 0.28 : 0) : w.height / 2;
  camera.x += (targetX - camera.x) * 0.13; camera.y += (targetY - camera.y) * 0.13; camera.zoom += (zoom - camera.zoom) * 0.13;

  if (w.cinematic) {
    const cine = w.cinematic;
    const f = w.fighters.find(e => e.id === cine.actor) || focus;
    const t = cine.age;
    ctx.fillStyle = '#000'; ctx.fillRect(0, 0, width, height);
    const hx = width / 2, hy = height / 2;
    if (cine.kind === 'ultra') {
      const fade = clamp((t - 1.15) / 3.6, 0, 1);
      if (fade > 0) {
        const g = ctx.createLinearGradient(0, height, width, 0);
        for (let i = 0; i < 7; i++) g.addColorStop(i / 6, `hsla(${(t * 75 + i * 55) % 360},${25 + fade * 75}%,${15 + fade * 42}%,${fade * 0.9})`);
        ctx.fillStyle = g; ctx.fillRect(0, 0, width, height);
      }
      actor(ctx, { ...f, x: hx + Math.sin(time / 23) * fade * 4, y: hy, radius: Math.max(36, f.radius) }, time);
    } else if (cine.kind === 'erased' || cine.kind === 'revive') {
      const dissolve = clamp((t - 0.8) / 1.5, 0, 1);
      actor(ctx, { ...f, x: hx + Math.sin(time * 0.075) * (1 - dissolve) * 10, y: hy, radius: Math.max(36, f.radius) }, time, 1 - dissolve);
      if (high) for (let i = 0; i < 80; i++) {
        const a = i * 2.4;
        ctx.fillStyle = rgba(SPECTRUM[i % 7], (1 - dissolve) * 0.8);
        ctx.fillRect(hx + Math.cos(a) * (20 + dissolve * i * 3), hy + Math.sin(a) * (20 + dissolve * i * 3), 2.5, 2.5);
      }
    } else if (cine.kind === 'final') {
      actor(ctx, { ...f, x: hx, y: hy }, time);
      const r = 55 + Math.min(width, height) * 0.38 * (1 - t / cine.duration);
      for (let i = 0; i < 7; i++) {
        const a = i / 7 * TAU + t * (1.5 + t);
        ctx.fillStyle = SPECTRUM[i]; ctx.shadowColor = SPECTRUM[i]; ctx.shadowBlur = high ? 22 : 0;
        circle(ctx, hx + Math.cos(a) * r, hy + Math.sin(a) * r, 10); ctx.fill();
      }
      ctx.shadowBlur = 0;
    } else {
      const p = clamp((t - 0.5) / 2.1, 0, 1);
      actor(ctx, { ...f, x: hx, y: hy }, time);
      for (const side of [-1, 1]) {
        ctx.fillStyle = p > 0.85 ? '#b57aff' : side === -1 ? '#73b9ff' : '#ff597d';
        ctx.shadowColor = ctx.fillStyle; ctx.shadowBlur = 26;
        circle(ctx, hx + side * 120 * (1 - p), hy - 30 * (1 - p), 21 + p * 12); ctx.fill();
      }
      ctx.shadowBlur = 0;
    }
    return;
  }

  ctx.save();
  if (settings.screenShake && w.shake > 0.4) ctx.translate(Math.sin(time / 13) * w.shake * 0.35, Math.cos(time / 11) * w.shake * 0.35);
  ctx.translate(width / 2, height / 2); ctx.scale(camera.zoom, camera.zoom); ctx.translate(-camera.x, -camera.y);
  const floors: Record<string, string> = { cosmic: '#101720', abyss: '#0a1c23', sunset: '#24141b', candy: '#1e1328', matrix: '#0e221c', volcano: '#241610' };
  ctx.fillStyle = floors[settings.bgTheme || 'cosmic'] || '#101720'; ctx.fillRect(0, 0, w.width, w.height);
  const arenaColor = w.config.mode === 'boss_raid' ? '#f6ad72' : '#baf66a';
  ctx.strokeStyle = '#ffffff09'; ctx.lineWidth = 1 / camera.zoom;
  const visibleW = width / camera.zoom, visibleH = height / camera.zoom;
  const left = Math.max(0, Math.floor((camera.x - visibleW / 2) / 50) * 50), top = Math.max(0, Math.floor((camera.y - visibleH / 2) / 50) * 50);
  ctx.beginPath();
  for (let x = left; x < Math.min(w.width, camera.x + visibleW / 2); x += 50) { ctx.moveTo(x, 0); ctx.lineTo(x, w.height); }
  for (let y = top; y < Math.min(w.height, camera.y + visibleH / 2); y += 50) { ctx.moveTo(0, y); ctx.lineTo(w.width, y); }
  ctx.stroke();
  ctx.strokeStyle = rgba(arenaColor, 0.4); ctx.lineWidth = 2.2 / camera.zoom; ctx.strokeRect(0, 0, w.width, w.height);
  ctx.strokeStyle = rgba(arenaColor, 0.9); ctx.lineWidth = 4 / camera.zoom;
  const corners = [[0, 0, 1, 1], [w.width, 0, -1, 1], [0, w.height, 1, -1], [w.width, w.height, -1, -1]];
  for (const [x, y, sx, sy] of corners) { ctx.beginPath(); ctx.moveTo(x + sx * 35, y); ctx.lineTo(x, y); ctx.lineTo(x, y + sy * 35); ctx.stroke(); }
  ctx.textAlign = 'center'; ctx.font = '900 42px system-ui'; ctx.fillStyle = '#ffffff05';
  ctx.fillText('CIRCLE ARENA', w.width / 2, w.height / 2 + 12);
  for (const cut of w.cuts) {
    ctx.save(); ctx.beginPath(); ctx.rect(0, 0, w.width, w.height); ctx.clip(); ctx.translate(cut.x, cut.y); ctx.rotate(cut.angle);
    ctx.fillStyle = '#030509'; ctx.fillRect(-w.width * 2, -7, w.width * 4, 14);
    ctx.strokeStyle = cut.color; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(-w.width * 2, -8); ctx.lineTo(w.width * 2, -8); ctx.moveTo(-w.width * 2, 8); ctx.lineTo(w.width * 2, 8); ctx.stroke(); ctx.restore();
  }
  for (const field of w.fields) {
    const color = field.kind === 'blue' ? '#78baff' : field.kind === 'red' ? '#ff6284' : '#b89dff';
    ctx.fillStyle = rgba(color, 0.07); ctx.strokeStyle = rgba(color, 0.3); ctx.lineWidth = 2;
    circle(ctx, field.x, field.y, field.radius); ctx.fill(); ctx.stroke();
    for (let i = 0; i < 3; i++) {
      ctx.save(); ctx.translate(field.x, field.y); ctx.rotate(time / 600 + i);
      ctx.beginPath(); ctx.ellipse(0, 0, 34 + i * 7, 13 + i * 6, 0, 0, TAU); ctx.stroke(); ctx.restore();
    }
    ctx.fillStyle = color; circle(ctx, field.x, field.y, 20); ctx.fill();
  }
  for (const orb of w.orbs) {
    ctx.save(); ctx.translate(orb.x, orb.y); ctx.rotate(time / 900);
    ctx.fillStyle = orb.type === 'heal' ? '#baf66a' : orb.type === 'shield' ? '#8fdfff' : '#ffaf7d';
    ctx.shadowColor = ctx.fillStyle; ctx.shadowBlur = 18;
    ctx.fillRect(-6, -6, 12, 12); ctx.strokeStyle = ctx.fillStyle; ctx.lineWidth = 1.5; circle(ctx, 0, 0, 17); ctx.stroke(); ctx.restore();
  }
  for (const f of w.fighters) {
    if (!f.hp || f.departed) continue;
    actor(ctx, f, time);
    const color = f.ai ? '#f4938d' : PLAYER_COLORS[f.slot] || '#baf66a';
    if (!f.ai) {
      ctx.strokeStyle = rgba(color, f.id === localId ? 0.8 : 0.25); ctx.lineWidth = 2;
      circle(ctx, f.x, f.y, f.radius + 8); ctx.stroke();
    }
    ctx.fillStyle = color; ctx.font = '600 13px system-ui'; ctx.fillText(f.ai ? getCharacterById(f.characterId).name : f.name, f.x, f.y - f.radius - 25);
    const bar = Math.max(52, f.radius * 1.5);
    ctx.fillStyle = '#ffffff18'; ctx.fillRect(f.x - bar / 2, f.y - f.radius - 17, bar, 3.5);
    ctx.fillStyle = color; ctx.fillRect(f.x - bar / 2, f.y - f.radius - 17, bar * Math.min(1, f.hp / f.maxHp), 3.5);
  }
  for (const p of w.shots) {
    ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(Math.atan2(p.vy, p.vx));
    ctx.fillStyle = p.color; ctx.strokeStyle = p.color; ctx.shadowColor = p.color; ctx.shadowBlur = high ? 10 : 0;
    if (p.shape === 'bone') {
      ctx.fillStyle = '#eaf6ff'; ctx.fillRect(-14, -3, 28, 6);
      for (const side of [-1, 1]) { circle(ctx, side * 12, -3, 4.5); ctx.fill(); circle(ctx, side * 12, 3, 4.5); ctx.fill(); }
    } else if (p.shape === 'pixel') ctx.fillRect(-7, -5, 14, 10);
    else if (p.shape === 'blade') { ctx.beginPath(); ctx.moveTo(15, 0); ctx.lineTo(-10, -5); ctx.lineTo(-6, 0); ctx.lineTo(-10, 5); ctx.closePath(); ctx.fill(); }
    else if (p.shape === 'bullet' || p.shape === 'rocket') { ctx.fillRect(-10, -p.radius / 2, 20, p.radius); }
    else { circle(ctx, 0, 0, p.radius); ctx.fill(); }
    ctx.restore();
  }
  for (const fx of w.effects) drawEffect(ctx, fx, time, high);
  ctx.restore();

  if (w.phase === 'countdown') {
    ctx.fillStyle = '#070b1170'; ctx.fillRect(0, 0, width, height);
    ctx.textAlign = 'center'; ctx.font = '900 80px system-ui'; ctx.fillStyle = '#e7eedf';
    ctx.fillText(String(Math.max(1, Math.ceil(w.phaseTimer))), width / 2, height / 2 + 24);
    ctx.font = '500 11px ui-monospace'; ctx.fillStyle = '#baf66a'; ctx.fillText('СИНХРОНИЗАЦИЯ ЗАВЕРШЕНА', width / 2, height / 2 + 61);
  }
  if (w.banner && w.phase !== 'countdown') {
    ctx.save(); ctx.globalAlpha = Math.min(1, w.banner.left * 2);
    ctx.font = `700 ${width < 500 ? 13 : 16}px system-ui`; ctx.textAlign = 'center'; ctx.fillStyle = w.banner.color;
    ctx.fillText(w.banner.text, width / 2, 40, width - 40); ctx.restore();
  }
  if (giant) {
    // Minimap keeps the boss and distant teammates discoverable on colossal arenas.
    const mw = 102, mh = 80, x = width - mw - 15, y = height - mh - 15;
    ctx.fillStyle = '#090e18db'; ctx.fillRect(x, y, mw, mh); ctx.strokeStyle = '#ffffff22'; ctx.strokeRect(x, y, mw, mh);
    for (const f of alive) { ctx.fillStyle = f.ai ? '#ef857c' : PLAYER_COLORS[f.slot]; circle(ctx, x + f.x / w.width * mw, y + f.y / w.height * mh, f.boss ? 4 : 2.4); ctx.fill(); }
  }
}