import Peer, { type DataConnection } from 'peerjs';
import { ALL_CHARACTERS } from '../data/characters';
import {
  PROTOCOL_VERSION, invitationValid, makeInvitation, normalizeInput, parseInvitation, randomCode,
  type PartyConfig, type PartyRoom, type PartyStatus, type PlayerInput, type Profile,
} from './protocol';
import type { BattleFrame, PartyPacket, TimedInput } from './battleTypes';

const initialStatus = (): PartyStatus => ({
  role: null, selfId: '', connecting: false, signaling: false,
  room: null, invitation: null, error: '', notice: '', latency: 0,
});
const profileOf = (raw: unknown): Profile | null => {
  if (!raw || typeof raw !== 'object') return null;
  const p = raw as Record<string, unknown>;
  if (typeof p.name !== 'string' || typeof p.characterId !== 'string' ||
      !ALL_CHARACTERS.some(c => c.id === p.characterId && c.id !== 'volcanic_ash')) return null;
  return {
    name: p.name.trim().slice(0, 20) || 'Игрок', characterId: p.characterId,
    gojoAscended: p.gojoAscended === true, overkillMastery: p.overkillMastery === true,
  };
};

// The host validates invitations and runs combat. Peers send only their own input.
export class PartyClient {
  private peer: Peer | null = null;
  private hostConnection: DataConnection | null = null;
  private connections = new Map<string, DataConnection>();
  private lastSeen = new Map<string, number>();
  private listeners = new Set<() => void>();
  private frameListeners = new Set<(frame: BattleFrame) => void>();
  private status: PartyStatus = initialStatus();
  private timer: ReturnType<typeof setInterval> | null = null;
  private timeout: ReturnType<typeof setTimeout> | null = null;
  private epoch = 0;
  private lastFrameAt = 0;
  readonly inputs = new Map<string, TimedInput>();
  frame: BattleFrame | null = null;

  getSnapshot = () => this.status;
  subscribe = (listener: () => void) => { this.listeners.add(listener); return () => { this.listeners.delete(listener); }; };
  subscribeFrames = (listener: (frame: BattleFrame) => void) => {
    this.frameListeners.add(listener);
    return () => { this.frameListeners.delete(listener); };
  };
  private update(patch: Partial<PartyStatus>) {
    this.status = { ...this.status, ...patch };
    this.listeners.forEach(l => l());
  }
  clearMessage = () => this.update({ error: '', notice: '' });

  private send(connection: DataConnection | null | undefined, packet: PartyPacket, skippable = false) {
    if (!connection?.open) return;
    if (skippable && connection.dataChannel?.bufferedAmount > 64_000) return;
    try {
      const pending = connection.send(packet);
      if (pending instanceof Promise) void pending.catch(() => { /* The connection error handler reports failures. */ });
    } catch { /* The close/error event owns cleanup. */ }
  }
  private broadcast(packet: PartyPacket, skippable = false) {
    for (const connection of this.connections.values()) this.send(connection, packet, skippable);
  }
  private publishRoom(room: PartyRoom) {
    this.update({ room });
    this.broadcast({ type: 'room', room });
  }

  private cleanup() {
    this.epoch++;
    if (this.timeout) clearTimeout(this.timeout);
    if (this.timer) clearInterval(this.timer);
    this.timeout = null;
    this.timer = null;
    this.hostConnection?.close();
    for (const c of this.connections.values()) c.close();
    this.connections.clear();
    this.hostConnection = null;
    this.peer?.destroy();
    this.peer = null;
    this.frame = null;
    this.inputs.clear();
    this.lastSeen.clear();
  }
  leave = (notice = '') => {
    if (this.status.role === 'host') this.broadcast({ type: 'closed', reason: 'Лидер вышел. Создайте новую пати.' });
    else this.send(this.hostConnection, { type: 'leave' });
    this.cleanup();
    this.status = { ...initialStatus(), notice };
    this.listeners.forEach(l => l());
  };
  dispose = () => { this.leave(); this.listeners.clear(); this.frameListeners.clear(); };
  private fail(message: string) {
    this.cleanup();
    this.status = { ...initialStatus(), error: message };
    this.listeners.forEach(l => l());
  }

  private createPeer(id?: string): Peer | null {
    if (!window.RTCPeerConnection) {
      this.fail('Этот браузер не поддерживает WebRTC. Откройте игру в актуальном Chrome, Safari или Firefox.');
      return null;
    }
    try {
      // PeerJS Cloud handles signaling; battle packets travel over WebRTC.
      const p = id ? new Peer(id, { debug: 0 }) : new Peer({ debug: 0 });
      this.peer = p;
      const epoch = this.epoch;
      p.on('error', (error: { type?: string }) => {
        if (epoch !== this.epoch) return;
        if (this.status.room && !this.status.connecting && ['network', 'socket-error', 'socket-closed'].includes(error.type || '')) {
          this.update({ signaling: false, notice: 'Сервер приглашений недоступен. Уже установленные соединения продолжают работать.' });
          return;
        }
        const messages: Record<string, string> = {
          'peer-unavailable': 'Пати не найдена. Проверьте код и попросите лидера оставить игру открытой.',
          'unavailable-id': 'Не удалось создать адрес пати. Попробуйте создать код ещё раз.',
          'network': 'Нет связи с сервером приглашений. Проверьте интернет и попробуйте снова.',
          'browser-incompatible': 'Этот браузер не поддерживает сетевую игру. Обновите браузер.',
          'webrtc': 'Устройства не смогли установить WebRTC-соединение. Попробуйте другую сеть без VPN.',
        };
        this.fail(messages[error.type || ''] || 'Не удалось подключиться. Проверьте интернет и повторите попытку.');
      });
      p.on('disconnected', () => {
        if (epoch !== this.epoch || p.destroyed) return;
        this.update({ signaling: false });
        try { p.reconnect(); } catch { /* Existing data channels remain usable. */ }
      });
      p.on('open', () => {
        if (epoch !== this.epoch) return;
        this.update({ signaling: true, notice: '' });
      });
      this.timeout = setTimeout(() => {
        if (epoch === this.epoch && this.status.connecting) {
          this.fail('Подключение заняло слишком много времени. Оставьте игру открытой на обоих устройствах и попробуйте другую сеть.');
        }
      }, 25_000);
      return p;
    } catch {
      this.fail('Не удалось запустить сетевое соединение. Используйте HTTPS и актуальный браузер.');
      return null;
    }
  }

  create = (capacity: 2 | 3, profile: Profile, config: PartyConfig) => {
    this.leave();
    this.update({ connecting: true, role: 'host' });
    const roomId = randomCode(8);
    const peer = this.createPeer(`circle-party-${roomId}`);
    if (!peer) return;
    const epoch = this.epoch;
    peer.on('open', (selfId: string) => {
      if (epoch !== this.epoch || this.status.room) return;
      if (this.timeout) clearTimeout(this.timeout);
      const invitation = makeInvitation(roomId);
      const room: PartyRoom = {
        id: roomId, hostId: selfId, capacity, config: { ...config },
        phase: 'lobby', matchId: null, paused: false, invitationExpiresAt: invitation.expiresAt,
        members: [{ ...profile, id: selfId, ready: false, slot: 0 }],
      };
      this.update({ selfId, room, invitation, connecting: false, signaling: true });
      this.startHeartbeat();
    });
    peer.on('connection', connection => {
      if (epoch !== this.epoch) { connection.close(); return; }
      const helloTimeout = setTimeout(() => {
        if (!this.connections.has(connection.peer)) connection.close();
      }, 10_000);
      connection.on('data', raw => {
        if (epoch !== this.epoch) return;
        this.receiveHost(connection, raw);
      });
      connection.on('error', () => { connection.close(); if (epoch === this.epoch) this.removeMember(connection.peer); });
      connection.on('close', () => {
        clearTimeout(helloTimeout);
        if (epoch === this.epoch && this.connections.get(connection.peer) === connection) this.removeMember(connection.peer);
      });
    });
  };

  join = (rawCode: string, profile: Profile) => {
    const invitation = parseInvitation(rawCode);
    if (!invitation) { this.update({ error: 'Введите полный код из 12 символов, например ABCD-EFGH-2345.' }); return; }
    this.leave();
    this.update({ connecting: true, role: 'guest' });
    const peer = this.createPeer();
    if (!peer) return;
    const epoch = this.epoch;
    peer.on('open', (selfId: string) => {
      if (epoch !== this.epoch || this.hostConnection) return;
      this.update({ selfId });
      const connection = peer.connect(`circle-party-${invitation.room}`, { reliable: true, serialization: 'json', label: 'circle-party-v1' });
      this.hostConnection = connection;
      connection.on('open', () => this.send(connection, { type: 'hello', version: PROTOCOL_VERSION, token: invitation.token, profile }));
      connection.on('data', raw => { if (epoch === this.epoch) this.receiveGuest(raw); });
      connection.on('close', () => {
        if (epoch === this.epoch) this.fail('Соединение с лидером закрыто. Вернитесь в пати по новому приглашению.');
      });
      connection.on('error', () => {
        if (epoch === this.epoch) this.fail('Соединение прервано. Проверьте сеть и запросите код у лидера.');
      });
    });
  };

  private receiveHost(connection: DataConnection, raw: unknown) {
    if (!raw || typeof raw !== 'object') return;
    const packet = raw as PartyPacket;
    const room = this.status.room;
    if (!room) return;
    if (packet.type === 'hello') {
      if (this.connections.has(connection.peer)) return;
      let reason = '';
      const profile = profileOf(packet.profile);
      if (packet.version !== PROTOCOL_VERSION) reason = 'Версии игры отличаются. Обновите страницу на обоих устройствах.';
      else if (!invitationValid(this.status.invitation, packet.token)) reason = 'Код истёк или обновлён. Попросите лидера создать новый код.';
      else if (room.phase !== 'lobby') reason = 'Бой уже начался. Дождитесь возвращения команды в лобби.';
      else if (room.members.length >= room.capacity) reason = 'Пати заполнена. В дуо два места, в трио три.';
      else if (!profile) reason = 'Не удалось проверить профиль игрока. Выберите бойца и повторите вход.';
      if (reason || !profile) {
        this.send(connection, { type: 'reject', reason });
        setTimeout(() => connection.close(), 500);
        return;
      }
      this.connections.set(connection.peer, connection);
      this.lastSeen.set(connection.peer, Date.now());
      const slot = [0, 1, 2].find(s => !room.members.some(m => m.slot === s)) ?? 2;
      this.publishRoom({ ...room, members: [...room.members, { ...profile, id: connection.peer, slot, ready: false }] });
      return;
    }
    if (this.connections.get(connection.peer) !== connection) return;
    this.lastSeen.set(connection.peer, Date.now());
    if (packet.type === 'ping') this.send(connection, { type: 'pong', sent: packet.sent });
    else if (packet.type === 'leave') { this.removeMember(connection.peer); connection.close(); }
    else if (packet.type === 'ready' && room.phase === 'lobby') {
      this.publishRoom({ ...room, members: room.members.map(m => m.id === connection.peer ? { ...m, ready: packet.ready === true } : m) });
    } else if (packet.type === 'profile' && room.phase === 'lobby') {
      const profile = profileOf(packet.profile);
      if (profile) this.publishRoom({ ...room, members: room.members.map(m => m.id === connection.peer ? { ...m, ...profile, ready: false } : m) });
    } else if (packet.type === 'input' && room.phase === 'playing' && packet.matchId === room.matchId) {
      const input = normalizeInput(packet.input);
      if (input && input.seq > (this.inputs.get(connection.peer)?.value.seq ?? -1)) {
        this.inputs.set(connection.peer, { value: input, receivedAt: Date.now() });
      }
    }
  }

  private receiveGuest(raw: unknown) {
    if (!raw || typeof raw !== 'object') return;
    const packet = raw as PartyPacket;
    this.lastSeen.set('host', Date.now());
    if (packet.type === 'reject' || packet.type === 'closed') { this.fail(packet.reason); return; }
    if (packet.type === 'room') {
      const room = packet.room;
      if (!room || !Array.isArray(room.members) || !room.members.some(m => m.id === this.status.selfId) || room.members.length > 3) return;
      if (this.timeout) clearTimeout(this.timeout);
      if (room.matchId !== this.status.room?.matchId) this.frame = null;
      this.update({ room, connecting: false, error: '' });
      if (!this.timer) this.startHeartbeat();
    } else if (packet.type === 'frame' && packet.frame?.matchId === this.status.room?.matchId) {
      if (!Array.isArray(packet.frame.fighters) || packet.frame.fighters.length > 12) return;
      this.frame = packet.frame;
      this.lastFrameAt = Date.now();
      this.frameListeners.forEach(l => l(packet.frame));
    } else if (packet.type === 'ping') this.send(this.hostConnection, { type: 'pong', sent: packet.sent });
    else if (packet.type === 'pong' && typeof packet.sent === 'number') this.update({ latency: Math.max(0, Math.round(Date.now() - packet.sent)) });
  }

  private startHeartbeat() {
    if (this.timer) clearInterval(this.timer);
    this.timer = setInterval(() => {
      const now = Date.now();
      if (this.status.role === 'host') {
        for (const [id, c] of this.connections) {
          if (now - (this.lastSeen.get(id) || now) > 30_000) { this.removeMember(id); c.close(); }
          else this.send(c, { type: 'ping', sent: now });
        }
      } else if (this.status.room) {
        if (now - (this.lastSeen.get('host') || now) > 30_000) { this.fail('Лидер не отвечает. Пати закрыта, можно создать новую.'); return; }
        this.send(this.hostConnection, { type: 'ping', sent: now });
      }
    }, 3_000);
  }
  private removeMember(id: string) {
    this.connections.delete(id);
    this.lastSeen.delete(id);
    this.inputs.delete(id);
    const room = this.status.room;
    if (room?.members.some(m => m.id === id)) {
      const remaining = room.members.filter(m => m.id !== id);
      this.publishRoom({ ...room, members: room.phase === 'lobby' ? remaining.map((m, slot) => ({ ...m, slot })) : remaining });
    }
  }

  refreshCode = () => {
    const room = this.status.room;
    if (this.status.role !== 'host' || !room || !this.status.signaling) return;
    const invitation = makeInvitation(room.id, Date.now(), this.status.invitation?.token);
    this.update({ invitation, error: '' });
    this.publishRoom({ ...room, invitationExpiresAt: invitation.expiresAt });
  };
  setCapacity = (capacity: 2 | 3) => {
    const room = this.status.room;
    if (this.status.role !== 'host' || !room || room.phase !== 'lobby') return;
    if (room.members.length > capacity) { this.update({ error: 'В пати уже три участника. Нельзя переключить её на дуо.' }); return; }
    this.publishRoom({ ...room, capacity, members: room.members.map(m => ({ ...m, ready: false })) });
  };
  setConfig = (config: PartyConfig) => {
    const room = this.status.room;
    if (this.status.role !== 'host' || !room || room.phase !== 'lobby') return;
    this.publishRoom({ ...room, config, members: room.members.map(m => ({ ...m, ready: false })) });
  };
  setProfile = (profile: Profile) => {
    const room = this.status.room;
    if (!room || room.phase !== 'lobby') return;
    if (this.status.role === 'host') this.publishRoom({ ...room, members: room.members.map(m => m.id === this.status.selfId ? { ...m, ...profile, ready: false } : m) });
    else this.send(this.hostConnection, { type: 'profile', profile });
  };
  setReady = (ready: boolean) => {
    const room = this.status.room;
    if (!room || room.phase !== 'lobby') return;
    if (this.status.role === 'host') this.publishRoom({ ...room, members: room.members.map(m => m.id === this.status.selfId ? { ...m, ready } : m) });
    else this.send(this.hostConnection, { type: 'ready', ready });
  };
  startMatch = () => {
    const room = this.status.room;
    if (this.status.role !== 'host' || !room || room.phase !== 'lobby') return;
    if (room.members.length !== room.capacity || !room.members.every(m => m.ready)) {
      this.update({ error: 'Дождитесь полного состава и готовности всех игроков.' }); return;
    }
    this.inputs.clear(); this.frame = null;
    this.publishRoom({ ...room, phase: 'playing', paused: false, matchId: `${room.id}-${randomCode(8)}` });
  };
  returnToLobby = () => {
    const room = this.status.room;
    if (this.status.role === 'host' && room) {
      // Deliver the terminal snapshot before the ordered lobby transition.
      if (this.frame?.phase === 'finished') this.broadcast({ type: 'frame', frame: this.frame });
      this.publishRoom({ ...room, phase: 'lobby', matchId: null, paused: false, members: room.members.map((m, slot) => ({ ...m, slot, ready: false })) });
    }
  };
  pause = (paused: boolean) => {
    const room = this.status.room;
    if (this.status.role === 'host' && room?.phase === 'playing') this.publishRoom({ ...room, paused });
  };
  sendInput = (input: PlayerInput) => {
    const room = this.status.room;
    if (!room || room.phase !== 'playing' || !room.matchId) return;
    if (this.status.role === 'host') this.inputs.set(this.status.selfId, { value: input, receivedAt: Date.now() });
    else this.send(this.hostConnection, { type: 'input', matchId: room.matchId, input });
  };
  publishFrame = (frame: BattleFrame) => {
    if (this.status.role !== 'host') return;
    this.frame = frame;
    this.lastFrameAt = Date.now();
    this.broadcast({ type: 'frame', frame }, true);
    this.frameListeners.forEach(l => l(frame));
  };
  frameAge = () => this.lastFrameAt ? Date.now() - this.lastFrameAt : 0;
}