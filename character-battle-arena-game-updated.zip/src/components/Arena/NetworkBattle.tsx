import { useCallback, useEffect, useRef, useState } from 'react';
import { ArrowLeft, ArrowRight, Check, ChevronUp, Crown, LoaderCircle, Lock, Maximize2, Pause, Play, Radio, Shield, Skull, Swords, Trophy, Volume2, WifiOff, Zap } from 'lucide-react';
import type { GameSettings } from '../../types/game';
import type { PartyClient } from '../../network/PartyClient';
import { MODE_INFO, PLAYER_COLORS, type PartyStatus, type PlayerInput } from '../../network/protocol';
import type { BattleFrame } from '../../network/battleTypes';
import { abilityOptions, createBattle, stepBattle } from '../../network/battleEngine';
import { drawOnlineBattle, newCamera } from '../../network/battleRenderer';
import { getCharacterById } from '../../data/characters';
import { CharacterName } from '../Party/CharacterName';
import { soundManager } from '../../audio/soundManager';
import type { NetworkProgress } from '../../hooks/useGameSave';

interface Props { client: PartyClient; status: PartyStatus; settings: GameSettings; onProgress: (progress: NetworkProgress) => void; onLeave: () => void }

export function NetworkBattle({ client, status, settings, onProgress, onLeave }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const stageRef = useRef<HTMLDivElement>(null);
  const input = useRef<PlayerInput>({ x: 0, y: 0, dash: false, ability: null, action: 0, seq: 0 });
  const camera = useRef(newCamera());
  const keys = useRef(new Set<string>());
  const progressRef = useRef(onProgress);
  progressRef.current = onProgress;
  const settingsRef = useRef(settings);
  settingsRef.current = settings;
  const worldRef = useRef<BattleFrame | null>(null);
  const [hud, setHud] = useState<BattleFrame | null>(null);
  const [stale, setStale] = useState(false);
  const [overview, setOverview] = useState(false);
  const [leaveConfirm, setLeaveConfirm] = useState(false);
  const [soundOn, setSoundOn] = useState(true);
  const room = status.room!;
  const matchId = room.matchId!;
  const isHost = status.role === 'host';
  const selfId = status.selfId;

  const requestAbility = useCallback((id: string) => {
    input.current.ability = id;
    input.current.action++;
    input.current.seq++;
    client.sendInput({ ...input.current });
  }, [client]);
  const stopInput = useCallback(() => {
    keys.current.clear();
    input.current = { ...input.current, x: 0, y: 0, dash: false, ability: null, seq: input.current.seq + 1 };
    client.sendInput({ ...input.current });
  }, [client]);

  useEffect(() => {
    let raf = 0;
    let last = performance.now(), accumulator = 0, lastSent = 0, lastSnapshot = 0, lastHud = 0, lastSound = 0, seenFx = 0;
    let lastCinematic = '';
    const smooth = new Map<string, { x: number; y: number }>();
    const startRoom = client.getSnapshot().room;
    if (!startRoom) return;
    const host = client.getSnapshot().role === 'host';
    const id = client.getSnapshot().selfId;
    const checkpoint = (frame: BattleFrame) => {
      const own = frame.fighters.find(f => f.id === id);
      if (!own || frame.config.mode === 'training') return;
      progressRef.current({
        matchId, characterId: own.characterId, mode: frame.config.mode,
        damage: own.damage, kills: frame.config.mode === 'two_player' ? own.kills : frame.teamKills,
        waves: frame.completedWaves, finished: frame.phase === 'finished',
        won: frame.winner === 'heroes' || frame.winner === own.id,
        coins: frame.completedWaves * (frame.config.endless === 'last' ? 45 : 30) + (frame.phase === 'finished' ? frame.winner === 'heroes' || frame.winner === own.id ? 120 : 25 : 0),
      });
    };
    const world = host ? client.frame?.matchId === matchId ? client.frame : createBattle(startRoom) : null;
    if (world) { worldRef.current = world; client.publishFrame(world); }
    let checkpointedWaves = -1;
    const unsubscribe = client.subscribeFrames(frame => {
      worldRef.current = frame;
      if (frame.phase === 'finished' || frame.completedWaves > checkpointedWaves) {
        checkpointedWaves = frame.completedWaves;
        checkpoint(frame);
      }
    });
    const loop = (now: number) => {
      const elapsed = Math.min(0.075, (now - last) / 1000);
      last = now;
      const current = client.getSnapshot();
      if (current.room?.matchId !== matchId) return;
      const paused = current.room.paused;
      if (now - lastSent >= 40) {
        input.current.seq++;
        client.sendInput({ ...input.current });
        lastSent = now;
      }
      if (host && world) {
        if (!paused) {
          accumulator += elapsed;
          while (accumulator >= 1 / 60) {
            stepBattle(world, 1 / 60, client.inputs, new Set(current.room.members.map(m => m.id)));
            accumulator -= 1 / 60;
          }
        } else accumulator = 0;
        if (now - lastSnapshot >= 50) { client.publishFrame(world); lastSnapshot = now; }
      }
      const frame = worldRef.current || client.frame;
      const cv = canvasRef.current, stage = stageRef.current;
      if (cv && stage && frame) {
        const width = stage.clientWidth, height = stage.clientHeight, dpr = Math.min(2, window.devicePixelRatio || 1);
        if (cv.width !== Math.round(width * dpr) || cv.height !== Math.round(height * dpr)) { cv.width = Math.round(width * dpr); cv.height = Math.round(height * dpr); }
        const ctx = cv.getContext('2d');
        if (ctx && width > 0 && height > 0) {
          ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
          const visible = host ? frame : {
            ...frame,
            fighters: frame.fighters.map(f => {
              const previous = smooth.get(f.id) || { x: f.x, y: f.y };
              const teleport = Math.hypot(previous.x - f.x, previous.y - f.y) > 300;
              const blend = teleport ? 1 : 1 - Math.exp(-elapsed * 25);
              previous.x += (f.x - previous.x) * blend;
              previous.y += (f.y - previous.y) * blend;
              smooth.set(f.id, previous);
              return { ...f, x: previous.x, y: previous.y };
            }),
          };
          if (smooth.size > 40) for (const key of smooth.keys()) if (!frame.fighters.some(f => f.id === key)) smooth.delete(key);
          drawOnlineBattle(ctx, visible, camera.current, id, width, height, now, settingsRef.current);
        }
        const fx = frame.effects.find(e => e.id > seenFx && e.kind === 'hit');
        if (fx && now - lastSound > 180 && !paused) { soundManager.playHit(false); lastSound = now; }
        seenFx = frame.serial;
        const cinematicId = frame.cinematic ? `${frame.cinematic.actor}-${frame.cinematic.kind}` : '';
        if (cinematicId && cinematicId !== lastCinematic && frame.cinematic?.kind === 'ultra' && settingsRef.current.musicEnabled) soundManager.playSevenSoulsTheme();
        lastCinematic = cinematicId;
      }
      if (now - lastHud >= 90 && frame) {
        setHud({ ...frame, fighters: frame.fighters.map(f => ({ ...f, cooldowns: { ...f.cooldowns } })) });
        setStale(!host && !paused && client.frameAge() > 2400);
        checkpoint(frame);
        lastHud = now;
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => { cancelAnimationFrame(raf); unsubscribe(); stopInput(); };
  }, [client, matchId, stopInput]);

  useEffect(() => {
    const updateAxes = () => {
      const held = keys.current;
      input.current.x = Number(held.has('KeyD') || held.has('ArrowRight')) - Number(held.has('KeyA') || held.has('ArrowLeft'));
      input.current.y = Number(held.has('KeyS') || held.has('ArrowDown')) - Number(held.has('KeyW') || held.has('ArrowUp'));
      input.current.dash = held.has('ShiftLeft') || held.has('ShiftRight');
    };
    const down = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement) return;
      if (e.target instanceof HTMLButtonElement && (e.code === 'Space' || e.code === 'Enter')) return;
      if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space'].includes(e.code)) e.preventDefault();
      keys.current.add(e.code); updateAxes();
      const f = worldRef.current?.fighters.find(f => f.id === selfId);
      if (!e.repeat && f && (e.code.startsWith('Digit') || e.code === 'Space')) {
        const index = e.code === 'Space' ? 0 : Number(e.code.slice(5)) - 1;
        const option = abilityOptions(f)[index];
        if (option) requestAbility(option.ability.id);
      }
      if (!e.repeat && (e.code === 'KeyP' || e.code === 'Escape')) {
        if (isHost) client.pause(!client.getSnapshot().room?.paused);
        else setLeaveConfirm(true);
        stopInput();
      }
    };
    const up = (e: KeyboardEvent) => { keys.current.delete(e.code); updateAxes(); };
    const visibility = () => { if (document.hidden) { stopInput(); if (isHost) client.pause(true); } };
    window.addEventListener('keydown', down); window.addEventListener('keyup', up); window.addEventListener('blur', stopInput); document.addEventListener('visibilitychange', visibility);
    return () => { window.removeEventListener('keydown', down); window.removeEventListener('keyup', up); window.removeEventListener('blur', stopInput); document.removeEventListener('visibilitychange', visibility); };
  }, [client, selfId, isHost, requestAbility, stopInput]);

  useEffect(() => { soundManager.setMuted(!soundOn); return () => soundManager.setMuted(false); }, [soundOn]);
  const me = hud?.fighters.find(f => f.id === selfId);
  const options = me ? abilityOptions(me) : [];
  const teammates = hud?.fighters.filter(f => !f.ai) || [];
  const boss = hud?.fighters.find(f => f.boss);
  const cinematic = !!hud?.cinematic && !room.paused;
  const over = hud?.phase === 'finished';
  const win = over && (hud.winner === 'heroes' || hud.winner === selfId);
  const humanName = room.members.find(m => m.id === selfId)?.name || 'Игрок';

  return <div className={`network-battle ${cinematic ? 'cinematic-active' : ''}`}>
    <header className="battle-rail">
      <button className="icon-button" onClick={() => { stopInput(); setLeaveConfirm(true); }} aria-label="Выйти из боя"><ArrowLeft size={19} /></button>
      <span className="battle-mode-name"><Swords size={16} /><b>{MODE_INFO[room.config.mode].name}</b><small>{room.capacity === 2 ? 'DUO' : 'TRIO'}</small></span>
      {hud?.config.mode === 'endless' && <span className="battle-wave">ВОЛНА {hud.wave}<small>{hud.completedWaves} пройдено</small></span>}
      <div className="battle-connection"><i className="live-dot" /><span>{isHost ? 'HOST' : `${status.latency} ms`}</span></div>
      <button className={`icon-button ${!soundOn ? 'muted' : ''}`} onClick={() => setSoundOn(x => !x)} aria-label={soundOn ? 'Выключить звук' : 'Включить звук'}><Volume2 size={18} /></button>
      <button className="icon-button" onClick={() => { camera.current.overview = !camera.current.overview; setOverview(camera.current.overview); }} aria-label={overview ? 'Камера игрока' : 'Обзор арены'} title={overview ? 'Камера игрока' : 'Обзор арены'}><Maximize2 size={18} /></button>
      {isHost && <button className="icon-button" onClick={() => { client.pause(!room.paused); stopInput(); }} aria-label={room.paused ? 'Продолжить' : 'Пауза'}>{room.paused ? <Play size={17} /> : <Pause size={17} />}</button>}
    </header>

    <div className="battle-team-hud">{teammates.map(f => <div className={`battle-player-strip ${f.hp <= 0 ? 'down' : ''}`} key={f.id} style={{ '--slot-color': PLAYER_COLORS[f.slot] } as React.CSSProperties}>
      <span className="battle-player-number">{f.hp > 0 ? f.slot + 1 : <Skull size={14} />}</span><div><b>{f.name}{f.id === selfId && <small>ТЫ</small>}</b><div className="mini-hp-track"><i style={{ width: `${Math.max(0, f.hp / f.maxHp * 100)}%` }} /></div></div><span className="battle-player-hp">{hpText(f.hp)}<small> / {hpText(f.maxHp)}</small></span>{f.shield > 0 && <span className="battle-shield"><Shield size={12} />{f.shield}</span>}
    </div>)}</div>

    {boss && <div className="boss-health-hud"><div><Crown size={15} /><b>{getCharacterById(boss.characterId).name}</b><span>{Math.ceil(boss.hp).toLocaleString('ru-RU')} <small>/ {boss.maxHp.toLocaleString('ru-RU')} HP</small></span></div><div className="boss-health-track"><i style={{ width: `${boss.hp / boss.maxHp * 100}%` }} /></div></div>}

    <div className="network-arena-stage" ref={stageRef}>
      <canvas ref={canvasRef} aria-label="Общая арена пати" />
      {!hud && <div className="arena-message"><LoaderCircle size={29} className="spin" /><h3>Соединяем арену</h3><p>Получаем общее состояние боя от лидера...</p></div>}
      {stale && !over && <div className="stale-warning"><WifiOff size={16} />Лидер временно не отвечает. Ожидаем синхронизацию...</div>}
      {me && !me.hp && !over && <div className="spectator-message"><Radio size={16} />{room.config.mode === 'endless' && room.config.endless !== 'last' ? 'Ты вернёшься, если команда пройдёт волну' : 'Ты наблюдаешь за командой'}</div>}
      {room.paused && !over && <div className="battle-overlay"><div className="battle-modal"><span className="overline">КОМАНДА НА ПАУЗЕ</span><h2>Небольшая передышка</h2><p>{isHost ? 'Все бойцы, снаряды и таймеры остановлены.' : 'Лидер приостановил общий бой. Соединение сохранено.'}</p>{isHost && <button className="party-primary" onClick={() => client.pause(false)}><Play size={18} />Продолжить</button>}<button className="text-button" onClick={() => setLeaveConfirm(true)}>Покинуть пати</button></div></div>}
      {over && <div className="battle-overlay"><div className="battle-modal result-modal">
        <span className="result-emblem">{win ? <Trophy size={35} /> : <Shield size={35} />}</span>
        <span className="overline">{room.config.mode === 'endless' ? 'ЗАБЕГ ЗАВЕРШЁН' : 'ОБЩИЙ РЕЗУЛЬТАТ'}</span>
        <h2>{win ? 'Команда победила!' : hud.winner === 'draw' ? 'Ничья' : 'Ещё один шанс?'}</h2>
        <p>{room.config.mode === 'endless' ? `Пройдено волн: ${hud.completedWaves}. Прогресс сохранён у каждого участника.` : win ? 'Бой окончен. Награды начислены участникам команды.' : 'Пати остаётся с тобой. Соберитесь и попробуйте снова.'}</p>
        <div className="result-stats"><span><small>ТВОЙ УРОН</small><b>{Math.round(me?.damage || 0)}</b></span><span><small>ВРАГОВ ПОБЕЖДЕНО</small><b>{hud.teamKills || me?.kills || 0}</b></span><span><small>МОНЕТЫ</small><b className="gold">+{hud.completedWaves * (room.config.endless === 'last' ? 45 : 30) + (win ? 120 : 25)}</b></span></div>
        {isHost ? <button className="party-primary" onClick={client.returnToLobby}>Вернуться всей пати<ArrowRight size={18} /></button> : <span className="waiting-host"><LoaderCircle size={15} className="spin" />Лидер вернёт команду в лобби</span>}
        <button className="text-button" onClick={onLeave}>Выйти из пати</button>
      </div></div>}
    </div>

    <div className="network-control-deck">
      <div className="control-player"><span className="overline">{humanName}</span>{me && <CharacterName character={getCharacterById(me.characterId)} />}
        {me?.characterId === 'ultrakill' && <div className="ultra-charge"><span>{me.awakened ? 'ПРОБУЖДЁН' : `ЯРОСТЬ ${Math.floor(me.charge)}%`}</span><div><i style={{ width: `${me.awakened ? 100 : me.charge}%` }} /></div></div>}
        <span className="keyboard-hint">WASD · 1–8 · SHIFT</span>
      </div>
      <div className="ability-palette" role="group" aria-label="Способности твоего бойца" style={{ '--ability-count': Math.min(4, Math.max(1, options.length)) } as React.CSSProperties}>
        {options.map(({ ability, locked }, i) => {
          const cd = me?.cooldowns[ability.id] || 0;
          const disabled = !!locked || cd > 0 || !me?.hp || over || room.paused || cinematic || hud?.phase !== 'fighting';
          return <button className={`palette-ability ${locked ? 'locked' : ''} ${cd ? 'cooling' : ''}`} key={ability.id} disabled={disabled} title={locked || ability.description} onClick={() => { if (!disabled) requestAbility(ability.id); }} style={{ '--ability-color': ability.particleColor || '#baf66a', '--cooldown': `${Math.min(100, cd / ability.cooldown * 100)}%` } as React.CSSProperties}>
            <span className="palette-ability-key">{i + 1}</span><span className="palette-icon">{locked ? <Lock size={18} /> : ability.id.includes('shield') || ability.id.includes('parry') ? <Shield size={20} /> : <Zap size={20} />}</span><b>{ability.nameRu}</b><small>{locked || (cd > 0 ? `${cd.toFixed(1)} с` : `ГОТОВО · ${ability.cooldown} с`)}</small><i />
          </button>;
        })}
      </div>
      <div className="mobile-steering"><VirtualStick disabled={!!over || cinematic || !!room.paused} onMove={(x, y) => { input.current.x = x; input.current.y = y; }} /><HoldButton onHold={dash => { input.current.dash = dash; }} disabled={!!over || cinematic || !!room.paused} /></div>
    </div>

    {leaveConfirm && <div className="battle-overlay exit-overlay"><div className="battle-modal"><span className="overline">ВЫХОД ИЗ КОМАНДЫ</span><h2>{isHost ? 'Завершить пати?' : 'Покинуть бой?'}</h2><p>{isHost ? 'Ты ведёшь общий бой. Если выйдешь, соединение пати будет закрыто для всех.' : 'Твой боец покинет арену. Друзья смогут продолжить без тебя.'}</p><div className="confirm-actions"><button className="party-secondary" onClick={() => setLeaveConfirm(false)}><Check size={16} />Остаться</button><button className="party-danger" onClick={onLeave}>Выйти</button></div></div></div>}
  </div>;
}

function hpText(value: number) { return Number(value.toFixed(2)).toLocaleString('ru-RU'); }

function HoldButton({ onHold, disabled }: { onHold: (value: boolean) => void; disabled: boolean }) {
  return <button className="dash-control" disabled={disabled} onPointerDown={e => { e.preventDefault(); e.currentTarget.setPointerCapture(e.pointerId); onHold(true); }} onPointerUp={() => onHold(false)} onPointerCancel={() => onHold(false)} onLostPointerCapture={() => onHold(false)} onContextMenu={e => e.preventDefault()}><ChevronUp size={23} /><span>ТУРБО</span></button>;
}

function VirtualStick({ onMove, disabled }: { onMove: (x: number, y: number) => void; disabled: boolean }) {
  const element = useRef<HTMLDivElement>(null);
  const pointer = useRef<number | null>(null);
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const stop = () => { pointer.current = null; setPosition({ x: 0, y: 0 }); onMove(0, 0); };
  const move = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!element.current) return;
    const rect = element.current.getBoundingClientRect();
    const dx = e.clientX - rect.left - rect.width / 2, dy = e.clientY - rect.top - rect.height / 2;
    const max = rect.width * 0.31, mag = Math.max(max, Math.hypot(dx, dy));
    const x = dx / mag, y = dy / mag;
    setPosition({ x: x * max, y: y * max }); onMove(x, y);
  };
  useEffect(() => { if (disabled) stop(); }, [disabled]);
  return <div ref={element} role="group" aria-label="Джойстик перемещения" className="virtual-stick" onPointerDown={e => { if (disabled || pointer.current !== null) return; e.preventDefault(); pointer.current = e.pointerId; e.currentTarget.setPointerCapture(e.pointerId); move(e); }} onPointerMove={e => { if (pointer.current === e.pointerId) move(e); }} onPointerUp={stop} onPointerCancel={stop} onLostPointerCapture={stop} onContextMenu={e => e.preventDefault()}><i className="stick-cross-x" /><i className="stick-cross-y" /><span style={{ transform: `translate(${position.x}px,${position.y}px)` }} /></div>;
}