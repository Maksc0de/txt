import { useEffect, useMemo, useRef, useState } from 'react';
import { ArrowLeft, Crown, Heart } from 'lucide-react';
import type { Character } from '../../types/game';
import { drawCharacterAvatar } from '../../utils/characterRenderer';
import { soundManager } from '../../audio/soundManager';
import { bossHealth } from '../../game/raidRules';

// Локальный кооперативный Boss Raid: до трёх героев на одном экране.
interface LocalFighter {
  id: string;
  char: Character;
  name: string;
  x: number; y: number; vx: number; vy: number;
  hp: number; maxHp: number;
  radius: number;
  inv: number;
  skillCd: number;
  angle: number;
  hits: number;
}

interface Props {
  heroes: Character[];
  heroNames: string[];
  boss: Character;
  onExit: () => void;
}

const HERO_COLORS = ['#baf66a', '#7fb7ff', '#e7a6ff'];

export function LocalBossRaid({ heroes: heroesIn, heroNames, boss: bossIn, onExit }: Props) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const wrapRef = useRef<HTMLDivElement | null>(null);
  const teamRef = useRef<LocalFighter[]>([]);
  const bossRef = useRef<LocalFighter | null>(null);
  const moves = useRef<{ x: number; y: number }[]>(heroesIn.map(() => ({ x: 0, y: 0 })));
  const skills = useRef<boolean[]>(heroesIn.map(() => false));
  const [hpHud, setHpHud] = useState<{ bossHp: number; bossMax: number; team: number[] }>({ bossHp: 0, bossMax: 1, team: [] });
  const finished = useRef(false);
  const [result, setResult] = useState<null | 'win' | 'lose'>(null);

  const heroes = useMemo(() => heroesIn.map((c, i) => ({ ...c, name: heroNames[i] || c.name })), [heroesIn, heroNames]);

  useEffect(() => {
    const canvas = canvasRef.current;
    const wrap = wrapRef.current;
    if (!canvas || !wrap) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    let raf = 0;
    let last = performance.now();
    let resize = () => {
      const rect = wrap.getBoundingClientRect();
      canvas.width = rect.width || 600;
      canvas.height = rect.height || 600;
    };
    resize();
    window.addEventListener('resize', resize);

    const mk = (c: Character, name: string, x: number, y: number, hp: number, scale = 1): LocalFighter => ({
      id: Math.random().toString(36).slice(2), char: c, name, x, y, vx: 0, vy: 0,
      hp, maxHp: hp, radius: 34 * (c.isGiant ? Math.min(c.giantMultiplier || 1.5, 2) : 1) * scale, inv: 0, skillCd: 0, angle: 0, hits: 0,
    });

    const W = canvas.width;
    const H = canvas.height;
    const bossHp = bossHealth(bossIn.id, heroes.length);
    const bx = W * 0.68, by = H * 0.5;
    bossRef.current = mk(bossIn, bossIn.name, bx, by, bossHp, 1.8);
    // Герои стартуют в разных углах. В рейде у них удвоенный запас, как в соло.
    const spots = [
      { x: W * 0.24, y: H * 0.26 }, { x: W * 0.24, y: H * 0.74 }, { x: W * 0.4, y: H * 0.5 },
    ];
    teamRef.current = heroes.map((c, i) => {
      const spot = spots[i] || { x: W * 0.3, y: H * (0.3 + i * 0.15) };
      return mk(c, c.name, spot.x, spot.y, Math.min(60, Math.max(16, Math.round(c.maxHp * 2))));
    });
    setHpHud({ bossHp, bossMax: bossHp, team: teamRef.current.map(f => f.hp) });

    const loop = (t: number) => {
      const dt = Math.min((t - last) / 1000, 0.05);
      last = t;
      const w = canvas.width, h = canvas.height;
      ctx.clearRect(0, 0, w, h);
      ctx.fillStyle = '#0a0f16'; ctx.fillRect(0, 0, w, h);
      ctx.strokeStyle = 'rgba(255,255,255,.07)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      for (let x = 0; x < w; x += 40) { ctx.moveTo(x, 0); ctx.lineTo(x, h); }
      for (let y = 0; y < h; y += 40) { ctx.moveTo(0, y); ctx.lineTo(w, y); }
      ctx.stroke();
      ctx.strokeStyle = '#baf66a88'; ctx.lineWidth = 3;
      ctx.strokeRect(6, 6, w - 12, h - 12);
      ctx.fillStyle = '#ffffff08'; ctx.font = '700 30px system-ui'; ctx.textAlign = 'center';
      ctx.fillText('BOSS RAID', w / 2, h - 18);

      const b = bossRef.current!;
      const alive = teamRef.current.filter(f => f.hp > 0);

      // Герои: движение + кнопки
      teamRef.current.forEach((f, i) => {
        if (f.hp <= 0) return;
        const m = moves.current[i];
        const spd = 260;
        if (m.x || m.y) {
          const mag = Math.hypot(m.x, m.y) || 1;
          f.vx += (m.x / mag) * spd * dt * 6; f.vy += (m.y / mag) * spd * dt * 6;
        } else {
          f.vx *= 0.82; f.vy *= 0.82;
        }
        const vel = Math.hypot(f.vx, f.vy);
        const maxVel = 250;
        if (vel > maxVel) { f.vx *= maxVel / vel; f.vy *= maxVel / vel; }
        f.x += f.vx * dt; f.y += f.vy * dt;
        f.x = Math.max(24 + f.radius / 2, Math.min(w - 24 - f.radius / 2, f.x));
        f.y = Math.max(24 + f.radius / 2, Math.min(h - 24 - f.radius / 2, f.y));
        f.inv = Math.max(0, f.inv - dt);
        f.skillCd = Math.max(0, f.skillCd - dt);
        const dx = b.x - f.x, dy = b.y - f.y;
        f.angle = Math.atan2(dy, dx);
        if (skills.current[i] && f.skillCd <= 0 && !finished.current) {
          f.skillCd = (f.char.ability?.cooldown || 5) * 0.7;
          skills.current[i] = false;
          const dmg = Math.max(2, f.char.ability?.damage || 3) * (2 + Math.ceil(bossHp / 220));
          b.hp = Math.max(0, b.hp - dmg);
          b.inv = 0.35;
          f.inv = 0.2;
          soundManager.playHit(true);
          for (let k = 0; k < 14; k++) {
            const a = Math.random() * Math.PI * 2;
            ctx.fillStyle = f.char.glowColor;
            ctx.fillRect(f.x + Math.cos(a) * 30, f.y + Math.sin(a) * 30, 5, 5);
          }
        }
      });

      // Босс атакует ближайшего
      if (alive.length && !finished.current) {
        let target = alive[0];
        for (const f of alive) if (Math.hypot(b.x - f.x, b.y - f.y) < Math.hypot(b.x - target.x, b.y - target.y)) target = f;
        const dx = target.x - b.x, dy = target.y - b.y, d = Math.hypot(dx, dy) || 1;
        if (d > 130) { b.vx += (dx / d) * 40 * dt * 4; b.vy += (dy / d) * 40 * dt * 4; } else { b.vx *= 0.9; b.vy *= 0.9; }
        const vel = Math.hypot(b.vx, b.vy);
        if (vel > 60) { b.vx *= 60 / vel; b.vy *= 60 / vel; }
        b.x += b.vx * dt; b.y += b.vy * dt;
        b.x = Math.max(150, Math.min(w - 150, b.x)); b.y = Math.max(150, Math.min(h - 150, b.y));
        b.inv = Math.max(0, b.inv - dt);
        // кулаком/телом
        if (d < b.radius * 0.7 + target.radius + 20 && !b.inv && target.inv <= 0) {
          b.inv = 0.5;
          target.hp = Math.max(0, target.hp - 1);
          target.inv = 0.7;
          soundManager.playHit(true);
          for (let k = 0; k < 10; k++) { ctx.fillStyle = '#ff8a7a'; ctx.fillRect(target.x + (Math.random() - 0.5) * 30, target.y + (Math.random() - 0.5) * 30, 5, 5); }
        }
        // периодическая способность
        if (Math.random() < dt * 0.8 && !b.inv) {
          b.inv = 0.4;
          for (const f of alive) {
            if (Math.hypot(b.x - f.x, b.y - f.y) < 330) {
              f.hp = Math.max(0, f.hp - 1);
              f.inv = 0.5;
            }
          }
          ctx.strokeStyle = '#ffb86666'; ctx.lineWidth = 4;
          ctx.beginPath(); ctx.arc(b.x, b.y, 140, 0, Math.PI * 2); ctx.stroke();
        }
      }

      // контакт героя наносит урон боссу
      if (!finished.current) {
        for (const f of alive) {
          if (f.inv > 0) continue;
          const d = Math.hypot(b.x - f.x, b.y - f.y);
          if (d < b.radius + f.radius + 16) {
            const dmg = Math.max(2, Math.ceil(bossHp / 90));
            b.hp = Math.max(0, b.hp - dmg);
            f.inv = 0.45;
            soundManager.playHit(true);
          }
        }
      }

      // Рендер
      ctx.save(); ctx.translate(b.x, b.y); ctx.rotate(b.angle);
      drawCharacterAvatar(ctx, b.char, 0, 0, b.radius, 0, t / 600);
      ctx.restore();
      teamRef.current.forEach((f, i) => {
        if (f.hp <= 0) return;
        ctx.save(); ctx.translate(f.x, f.y); ctx.rotate(f.angle);
        drawCharacterAvatar(ctx, f.char, 0, 0, f.radius, 0, t / 500);
        ctx.restore();
        // цветное кольцо владельца
        ctx.strokeStyle = HERO_COLORS[i]; ctx.lineWidth = 2; ctx.globalAlpha = 0.6;
        ctx.beginPath(); ctx.arc(f.x, f.y, f.radius + 6, 0, Math.PI * 2); ctx.stroke(); ctx.globalAlpha = 1;
      });

      setHpHud(h => {
        const bossH = Math.max(0, Math.ceil(b.hp));
        const team = teamRef.current.map(x => Math.max(0, Math.ceil(x.hp)));
        if (h.bossHp === bossH && h.team.every((v, i) => v === team[i])) return h;
        return { bossHp: bossH, bossMax: b.maxHp, team };
      });

      // Победа/поражение
      if (!finished.current) {
        if (b.hp <= 0) { finished.current = true; setResult('win'); soundManager.playVictory(); }
        else if (alive.length === 0) { finished.current = true; setResult('lose'); soundManager.playDefeat(); }
      }

      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => { cancelAnimationFrame(raf); window.removeEventListener('resize', resize); };
  }, [heroes, bossIn]);

  return (
    <div className="w-full h-full bg-[#0b0f15] text-white flex flex-col overflow-hidden">
      <div className="flex items-center gap-3 px-3 py-2 bg-[#111720] border-b border-white/10 flex-shrink-0">
        <button onClick={onExit} className="w-9 h-9 flex items-center justify-center border border-white/15 rounded-lg text-slate-300 hover:text-white" aria-label="Выйти"><ArrowLeft size={18} /></button>
        <span className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-orange-300"><Crown size={16} /> Boss Raid · Локальная пати</span>
        <span className="ml-auto flex items-center gap-2 text-xs text-slate-400"><Heart size={14} className="text-rose-400" /> {hpHud.team.join(' / ')}</span>
      </div>
      <div className="px-4 pt-2 flex-shrink-0">
        <div className="flex items-center gap-2">
          <span className="text-sm font-bold text-orange-200 truncate">{bossIn.name}</span>
          <div className="flex-1 h-4 bg-[#161c27] rounded overflow-hidden border border-orange-500/40">
            <div className="h-full bg-gradient-to-r from-orange-600 to-amber-400 transition-all" style={{ width: `${(hpHud.bossHp / hpHud.bossMax) * 100}%` }} />
          </div>
          <span className="text-xs text-orange-200 tabular-nums whitespace-nowrap">{hpHud.bossHp.toLocaleString()} / {hpHud.bossMax.toLocaleString()}</span>
        </div>
        <p className="text-[10px] text-slate-500 mt-1">HP босса: ×{heroes.length === 3 ? 2.9 : heroes.length === 2 ? 1.9 : 1} за {heroes.length} игроков · Каждый бьёт и получает урон отдельно</p>
      </div>
      <div ref={wrapRef} className="relative flex-1 min-h-0">
        <canvas ref={canvasRef} className="w-full h-full" style={{ touchAction: 'none' }} />
        {result && (
          <div className="absolute inset-0 bg-black/70 flex items-center justify-center z-20">
            <div className="bg-[#141b26] border border-white/15 rounded-2xl p-6 text-center max-w-xs w-full">
              <div className="text-4xl mb-2">{result === 'win' ? '🏆' : '💀'}</div>
              <h3 className="text-xl font-black uppercase">{result === 'win' ? 'Босс повержен!' : 'Команда пала...'}</h3>
              <p className="text-xs text-slate-400 mt-2">{result === 'win' ? `Отличная командная работа против ${bossIn.name}!` : 'Попробуйте другую тактику и состав.'}</p>
              <div className="flex gap-2 mt-5">
                <button className="flex-1 py-2 rounded-xl bg-[#baf66a] text-black text-xs font-bold" onClick={onExit}>В меню</button>
              </div>
            </div>
          </div>
        )}
      </div>
      {/* Панели управления игроков */}
      <div className="flex flex-wrap items-end gap-2 px-2 py-2 bg-[#111720] border-t border-white/10 flex-shrink-0">
        {heroes.map((h, i) => (
          <div key={i} className="flex-1 min-w-[200px] bg-[#0b1018] border border-white/10 rounded-xl p-2 flex items-center gap-2" style={{ borderColor: HERO_COLORS[i] + '55' }}>
            <div className="w-7 h-7 rounded-md flex items-center justify-center text-xs font-black" style={{ background: HERO_COLORS[i], color: '#111' }}>{i + 1}</div>
            <div className="flex-1 min-w-0">
              <div className="text-[11px] font-bold truncate">{h.name}</div>
              <div className="text-[9px] text-slate-400">HP {hpHud.team[i] ?? '?'} · {h.ability?.nameRu || '—'}</div>
            </div>
            <div className="grid grid-cols-3 gap-0.5" style={{ touchAction: 'none' }}>
              <div /><DPadBtn dir="up" color={HERO_COLORS[i]} onHold={(v) => { if (v) moves.current[i] = { x: 0, y: -1 }; else if (moves.current[i].y === -1) moves.current[i] = { x: 0, y: 0 }; }} /><div />
              <DPadBtn dir="left" color={HERO_COLORS[i]} onHold={(v) => { if (v) moves.current[i] = { x: -1, y: 0 }; else if (moves.current[i].x === -1) moves.current[i] = { x: 0, y: 0 }; }} />
              <DPadBtn dir="down" color={HERO_COLORS[i]} onHold={(v) => { if (v) moves.current[i] = { x: 0, y: 1 }; else if (moves.current[i].y === 1) moves.current[i] = { x: 0, y: 0 }; }} />
              <DPadBtn dir="right" color={HERO_COLORS[i]} onHold={(v) => { if (v) moves.current[i] = { x: 1, y: 0 }; else if (moves.current[i].x === 1) moves.current[i] = { x: 0, y: 0 }; }} />
            </div>
            <button className="w-14 h-11 rounded-lg flex items-center justify-center text-[9px] font-bold"
              style={{ background: HERO_COLORS[i], color: '#111', touchAction: 'none' }}
              onPointerDown={(e) => { e.preventDefault(); e.currentTarget.setPointerCapture(e.pointerId); skills.current[i] = true; }}
              onPointerUp={() => { skills.current[i] = false; }}
            >{h.ability?.nameRu?.slice(0, 12) || 'СИЛА'}</button>
          </div>
        ))}
      </div>
    </div>
  );
}

function DPadBtn({ dir, color, onHold }: { dir: string; color: string; onHold: (v: boolean) => void }) {
  const glyph = dir === 'up' ? '▲' : dir === 'down' ? '▼' : dir === 'left' ? '◀' : '▶';
  return (
    <button
      style={{ touchAction: 'none', borderColor: color + '44', color }}
      className="w-8 h-8 bg-[#161d28] rounded border flex items-center justify-center text-xs"
      onPointerDown={(e) => { e.preventDefault(); e.currentTarget.setPointerCapture(e.pointerId); onHold(true); }}
      onPointerUp={() => onHold(false)} onPointerCancel={() => onHold(false)} onLostPointerCapture={() => onHold(false)}
      onContextMenu={(e) => e.preventDefault()}
    >{glyph}</button>
  );
}
