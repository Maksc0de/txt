import type { Character } from '../../types/game';

export function CharacterName({ character, className = '' }: { character: Character; className?: string }) {
  const special = character.id === 'ultrakill' ? 'ultra-name' : character.id === 'final' ? 'final-glitch'
    : character.id === 'glitch_secret' ? 'secret-glitch' : character.id === 'lighting_secret' ? 'secret-lighting'
    : character.id === 'stellar' ? 'stellar-name' : character.id === 'god_of_war' ? 'godofwar-name'
    : character.id === 'sword_glitcher' ? 'glitcher-name' : '';
  return <span className={`${special} ${className}`}>{character.name}</span>;
}