import { useEffect, useRef, useState } from 'react';
import { ArrowLeft, ArrowRight, Check, CheckCheck, Clock3, Copy, Crown, Globe2, Link2, LoaderCircle, LogOut, Plus, RefreshCw, Search, Share2, ShieldCheck, Signal, Users, X } from 'lucide-react';
import { ALL_CHARACTERS, getCharacterById } from '../../data/characters';
import { type PartyConfig, type PartyStatus, type Profile, INVITE_TTL, PLAYER_COLORS } from '../../network/protocol';
import type { PartyClient } from '../../network/PartyClient';
import { CharacterPreviewCanvas } from '../Selection/CharacterPreviewCanvas';
import { CharacterName } from './CharacterName';
import { BossSelect, ModalFrame, ModeSelect } from './MatchOptions';

interface Props {
  client: PartyClient;
  status: PartyStatus;
  capacity: 2 | 3;
  config: PartyConfig;
  profile: Profile;
  owned: string[];
  onProfile: (profile: Profile) => void;
  onCapacity: (size: 2 | 3) => void;
  onClose: () => void;
  onLeave: () => void;
}

export function PartyLobby({ client, status, capacity, config, profile, owned, onProfile, onCapacity, onClose, onLeave }: Props) {
  const [tab, setTab] = useState<'create' | 'join'>('create');
  const [code, setCode] = useState('');
  const [copied, setCopied] = useState(false);
  const [picker, setPicker] = useState(false);
  const [search, setSearch] = useState('');
  const [now, setNow] = useState(Date.now());
  const codeRef = useRef<HTMLInputElement>(null);
  const room = status.room;
  const host = status.role === 'host';
  const me = room?.members.find(m => m.id === status.selfId);
  const selected = getCharacterById(me?.characterId || profile.characterId);
  const slots = room?.capacity || capacity;
  const expiry = status.invitation?.expiresAt || room?.invitationExpiresAt || 0;
  const left = Math.min(180, Math.max(0, Math.ceil((expiry - now) / 1000)));
  const full = !!room && room.members.length === room.capacity;
  const everyoneReady = full && room.members.every(m => m.ready);
  const locked = status.connecting;

  useEffect(() => { const timer = setInterval(() => setNow(Date.now()), 250); return () => clearInterval(timer); }, []);
  useEffect(() => { if (!copied) return; const t = setTimeout(() => setCopied(false), 2000); return () => clearTimeout(t); }, [copied]);

  const changeProfile = (next: Profile) => {
    onProfile(next);
    if (room) client.setProfile(next);
  };
  const copy = async () => {
    if (!status.invitation || left <= 0) return;
    try { await navigator.clipboard.writeText(status.invitation.code); setCopied(true); }
    catch { codeRef.current?.focus(); codeRef.current?.select(); }
  };
  const share = async () => {
    if (!status.invitation || left <= 0) return;
    if (navigator.share) {
      try { await navigator.share({ title: 'Circle Arena: моя пати', text: `Вступай в мою пати Circle Arena. Код: ${status.invitation.code}. Выбери Дуо или Трио, затем «Войти по коду». Код действует 3 минуты.` }); }
      catch { /* Dismissing the native share sheet is not a connection failure. */ }
    } else await copy();
  };

  return <ModalFrame title="Сетевая пати" onClose={onClose} className="lobby-dialog">
    <header className="lobby-header">
      <div className="lobby-wordmark"><span className="arena-mark"><SwordsMark /></span><span>CIRCLE<span> ARENA</span></span></div>
      <span className="lobby-online"><i /><Globe2 size={13} /> СЕТЕВАЯ ПАТИ</span>
      <button className="icon-button" onClick={onClose} aria-label="Закрыть меню пати"><X size={20} /></button>
    </header>

    <div className="lobby-heading">
      <span className="overline">{room ? 'ОДНА КОМАНДА. ОДНА АРЕНА.' : 'ЛУЧШЕ ВМЕСТЕ'}</span>
      <h1>{room ? 'Команда собирается.' : <>Собери свою <span>пати.</span></>}</h1>
      <p>{room ? 'Выберите бойцов, подтвердите готовность и выходите на арену.' : 'Ты, друзья и общий бой. Каждый играет со своего устройства.'}</p>
    </div>

    {status.error && <div className="network-message error" role="alert"><Signal size={18} /><span>{status.error}</span><button onClick={client.clearMessage} aria-label="Скрыть ошибку"><X size={15} /></button></div>}
    {status.notice && <div className="network-message" role="status"><Signal size={18} /><span>{status.notice}</span></div>}

    <div className={`lobby-columns ${room ? 'connected' : ''}`}>
      <section className="lobby-connection">
        {!room ? <>
          <div className="connection-tabs" role="tablist" aria-label="Способ подключения">
            <button role="tab" aria-selected={tab === 'create'} className={tab === 'create' ? 'active' : ''} disabled={locked} onClick={() => { setTab('create'); client.clearMessage(); }}><Plus size={16} /> Создать пати</button>
            <button role="tab" aria-selected={tab === 'join'} className={tab === 'join' ? 'active' : ''} disabled={locked} onClick={() => { setTab('join'); client.clearMessage(); }}><Link2 size={16} /> Войти по коду</button>
          </div>
          <form onSubmit={e => { e.preventDefault(); if (locked) return; if (tab === 'create') client.create(capacity, profile, config); else client.join(code, profile); }} className="connection-form">
            <label className="field-label" htmlFor="party-name">ТВОЁ ИМЯ</label>
            <input id="party-name" className="party-input" value={profile.name} maxLength={20} placeholder="Как тебя зовут?" disabled={locked} onChange={e => onProfile({ ...profile, name: e.target.value })} autoComplete="nickname" />
            {tab === 'create' ? <>
              <span className="field-label">СОСТАВ КОМАНДЫ</span>
              <div className="party-size-picker">
                {([2, 3] as const).map(n => <button key={n} type="button" disabled={locked} className={capacity === n ? 'selected' : ''} onClick={() => onCapacity(n)}><Users size={18} /><span><b>{n === 2 ? 'Дуо' : 'Трио'}</b><small>{n} игрока</small></span>{capacity === n && <Check size={15} />}</button>)}
              </div>
              <p className="connection-description">Создай приглашение и передай код друзьям. Они появятся в этой команде после подтверждения.</p>
            </> : <>
              <label className="field-label" htmlFor="party-join-code">КОД ПАТИ</label>
              <input id="party-join-code" className="party-input join-code-input" value={code} onChange={e => setCode(e.target.value.toUpperCase())} placeholder="XXXX-XXXX-XXXX" maxLength={20} disabled={locked} autoCapitalize="characters" spellCheck={false} autoComplete="off" />
              <p className="connection-description">Попроси код у лидера команды. Если прошло 3 минуты, понадобится обновлённое приглашение.</p>
            </>}
            <button className="party-primary" type="submit" disabled={locked || !profile.name.trim() || (tab === 'join' && !code.trim())}>
              {locked ? <><LoaderCircle size={19} className="spin" /> Подключаемся...</> : <>{tab === 'create' ? 'Создать код пати' : 'Подтвердить и войти'}<ArrowRight size={18} /></>}
            </button>
            {locked && <button type="button" className="text-button" onClick={() => client.leave()}>Отменить подключение</button>}
          </form>
        </> : <>
          <div className="section-caption"><Link2 size={16} /><span>{host ? 'ПРИГЛАШЕНИЕ В КОМАНДУ' : 'ТЫ В КОМАНДЕ'}</span><i className="live-dot" /></div>
          {host ? <div className={`invitation ${left === 0 ? 'expired' : ''}`}>
            <label htmlFor="generated-party-code" className="field-label">ПЕРЕДАЙ ЭТОТ КОД ДРУГУ</label>
            <div className="invitation-code-row"><input id="generated-party-code" ref={codeRef} readOnly value={status.invitation?.code || ''} className="invitation-code" aria-label="Код приглашения" /><button className="icon-button" onClick={copy} disabled={left === 0} aria-label="Скопировать код">{copied ? <CheckCheck size={21} /> : <Copy size={20} />}</button></div>
            <div className="invitation-timer">
              <svg width="39" height="39" viewBox="0 0 40 40" aria-hidden="true"><circle cx="20" cy="20" r="17" fill="none" stroke="currentColor" opacity=".12" strokeWidth="2" /><circle cx="20" cy="20" r="17" fill="none" stroke="currentColor" strokeWidth="2" strokeDasharray="106.8" strokeDashoffset={106.8 * (1 - Math.min(1, left / (INVITE_TTL / 1000)))} transform="rotate(-90 20 20)" /></svg>
              <span><b>{left > 0 ? `${Math.floor(left / 60)}:${String(left % 60).padStart(2, '0')}` : 'Код истёк'}</b><small>{left > 0 ? 'осталось для входа' : 'создай новое приглашение'}</small></span>
              <button className="text-button" onClick={client.refreshCode} disabled={!status.signaling}><RefreshCw size={14} /> Обновить</button>
            </div>
            <button className="party-secondary share-button" onClick={share} disabled={left === 0}><Share2 size={16} /> {copied ? 'Код скопирован' : 'Поделиться приглашением'}</button>
          </div> : <div className="joined-state"><ShieldCheck size={42} /><h3>Подключение установлено</h3><p>Истечение кода не удалит тебя из пати. Ты останешься здесь, пока сам не выйдешь.</p></div>}
          <div className="lobby-rules">
            <ModeSelect value={room.config.mode} disabled={!host} onChange={mode => client.setConfig({ ...room.config, mode })} />
            {room.config.mode === 'boss_raid' && <BossSelect value={room.config.enemyId} players={slots} disabled={!host} onChange={enemyId => client.setConfig({ ...room.config, enemyId })} />}
            {room.config.mode === 'endless' && <label className="endless-variant">После волны<select value={room.config.endless} disabled={!host} onChange={e => client.setConfig({ ...room.config, endless: e.target.value as PartyConfig['endless'] })}><option value="standard">+2 HP и возвращение союзников</option><option value="duo">+1 HP и возвращение союзников</option><option value="last">Last: без лечения</option></select></label>}
            {!host && <p className="dialog-note">Режим и босса выбирает лидер.</p>}
          </div>
        </>}
      </section>

      <section className="lobby-team">
        <div className="team-section-head"><div><span className="overline">СОСТАВ ПАТИ</span><h2>{slots === 2 ? 'Вдвоём сильнее.' : 'Трое. Одна цель.'}</h2></div><span className="member-count">{room?.members.length || 1}<i> / {slots}</i></span></div>
        <div className={`team-slots count-${slots}`}>
          {Array.from({ length: slots }).map((_, i) => {
            const member = room?.members[i];
            const ownPreview = !room && i === 0;
            const filled = !!member || ownPreview;
            const isMe = member?.id === status.selfId || ownPreview;
            const character = filled ? getCharacterById(member?.characterId || profile.characterId) : null;
            return <div className={`team-slot ${filled ? 'filled' : 'empty'} ${member?.ready ? 'ready' : ''}`} key={i} style={{ '--slot-color': PLAYER_COLORS[member?.slot ?? i], animationDelay: `${i * 90}ms` } as React.CSSProperties}>
              <div className="slot-number">{String(i + 1).padStart(2, '0')}{((!!member && member.id === room?.hostId) || ownPreview) && <Crown size={13} />}</div>
              {character ? <>
                <div className="slot-portrait"><CharacterPreviewCanvas character={character} size={120} /></div>
                <b className="member-name">{member?.name || profile.name || 'Игрок'}{isMe && <small>ТЫ</small>}</b>
                <CharacterName character={character} className="slot-fighter-name" />
                {isMe ? <button type="button" className="slot-change" onClick={() => setPicker(true)} disabled={locked}>Сменить бойца<ChevronSmall /></button> : <span className="slot-change remote">Удалённый игрок</span>}
                <span className={`ready-label ${member?.ready ? 'yes' : ''}`}><i />{member?.ready ? 'Готов к бою' : room ? 'Выбирает снаряжение' : 'Твой боец'}</span>
              </> : <>
                <div className="empty-avatar"><Plus size={27} strokeWidth={1} /></div>
                <b>Место для друга</b><p>{room ? 'Отправь приглашение' : 'Присоединится по коду'}</p>
                <span className="waiting-dots"><i /><i /><i /></span>
              </>}
            </div>;
          })}
        </div>
        {!room && <div className="party-promise"><ShieldCheck size={19} /><div><b>Приглашение истекает. Дружба остаётся.</b><p>Код действует 3 минуты. Уже вошедшие участники остаются в команде даже после его обновления.</p></div></div>}
        {room && <div className="readiness-panel">
          <div className="readiness-caption"><span>{everyoneReady ? 'Все готовы. Пора на арену.' : !full ? `Ждём ещё ${slots - room.members.length} ${slots - room.members.length === 1 ? 'игрока' : 'игроков'}` : 'Подтвердите готовность'}</span><small>{room.members.filter(m => m.ready).length} / {slots} ГОТОВЫ</small></div>
          <div className="readiness-actions"><button className={me?.ready ? 'party-secondary ready-toggle' : 'party-primary ready-toggle'} onClick={() => client.setReady(!me?.ready)}><Check size={18} />{me?.ready ? 'Отменить готовность' : 'Я готов'}</button>
            {host && <button className="party-primary" disabled={!everyoneReady} onClick={client.startMatch}>Начать бой<ArrowRight size={19} /></button>}
          </div>
          {!host && <p className="dialog-note">Когда все будут готовы, лидер запустит общий бой.</p>}
          <p className="expiry-reminder"><Clock3 size={13} />{left > 0 ? 'Код нужен только для входа новых участников.' : 'Приглашение истекло, но состав команды сохранён.'}</p>
        </div>}
      </section>
    </div>
    <footer className="lobby-footer"><span><Globe2 size={14} /> WebRTC · интернет на каждом устройстве</span>{room ? <button className="leave-party" onClick={onLeave}><LogOut size={15} /> {host ? 'Распустить пати' : 'Выйти из пати'}</button> : <button className="text-button" onClick={onClose}><ArrowLeft size={14} /> Назад в меню</button>}</footer>

    {picker && <ModalFrame title="Твой боец" onClose={() => setPicker(false)} className="fighter-picker-dialog">
      <div className="dialog-top"><div><span className="overline">ТВОЯ КОЛЛЕКЦИЯ</span><h2>Кого берём в команду?</h2></div><button className="icon-button" onClick={() => setPicker(false)} aria-label="Закрыть"><X size={19} /></button></div>
      <label className="picker-search"><Search size={17} /><input autoFocus value={search} onChange={e => setSearch(e.target.value)} placeholder="Найти бойца" /></label>
      <div className="party-fighter-grid">
        {ALL_CHARACTERS.filter(c => owned.includes(c.id) && c.id !== 'volcanic_ash' && `${c.name} ${c.titleRu}`.toLocaleLowerCase().includes(search.toLocaleLowerCase())).map(c => <button className={c.id === selected.id ? 'selected' : ''} key={c.id} onClick={() => { changeProfile({ ...profile, characterId: c.id }); setPicker(false); }}>
          <CharacterPreviewCanvas character={c} size={74} /><CharacterName character={c} /><small>{c.maxHp} HP</small>{c.id === selected.id && <Check size={15} />}
        </button>)}
      </div>
    </ModalFrame>}
  </ModalFrame>;
}

function SwordsMark() { return <svg viewBox="0 0 24 24" width="22" height="22" fill="none" aria-hidden="true"><path d="M6 17 17 6M7 3l14 14-4 4L3 7V3h4Z" stroke="currentColor" strokeWidth="1.6" /><path d="m4 16 4 4m8-16 4 4" stroke="currentColor" strokeWidth="1.6" /></svg>; }
function ChevronSmall() { return <ArrowRight size={12} />; }