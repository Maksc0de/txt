import { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { Check, ChevronDown, Flame, Heart, Infinity as InfinityIcon, Shield, Swords, Target, X } from 'lucide-react';
import type { GameMode } from '../../types/game';
import { getCharacterById } from '../../data/characters';
import { MODE_INFO } from '../../network/protocol';
import { RAID_BOSSES, bossHealth, raidScale } from '../../game/raidRules';
import { CharacterPreviewCanvas } from '../Selection/CharacterPreviewCanvas';

export const MODE_ICONS = { standard: Swords, final_health: Heart, boss_raid: Flame, endless: InfinityIcon, two_player: Target, training: Shield };

export function ModalFrame({ children, onClose, title, className = '' }: {
  children: React.ReactNode; onClose: () => void; title: string; className?: string;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const closeRef = useRef(onClose);
  closeRef.current = onClose;
  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null;
    const el = ref.current;
    const focusables = () => el?.querySelectorAll<HTMLElement>('button:not(:disabled),input,select,[tabindex="0"]');
    focusables()?.[0]?.focus();
    const key = (e: KeyboardEvent) => {
      if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); closeRef.current(); }
      if (e.key === 'Tab') {
        const list = focusables();
        if (!list?.length) return;
        const first = list[0], last = list[list.length - 1];
        if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
        else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
      }
    };
    el?.addEventListener('keydown', key);
    return () => { el?.removeEventListener('keydown', key); previous?.focus(); };
  }, []);
  return createPortal(<div className="party-backdrop" onPointerDown={e => { if (e.target === e.currentTarget) onClose(); }}>
    <div ref={ref} role="dialog" aria-modal="true" aria-label={title} className={`party-dialog ${className}`}>{children}</div>
  </div>, document.body);
}

export function ModeSelect({ value, onChange, disabled = false }: { value: GameMode; onChange: (mode: GameMode) => void; disabled?: boolean }) {
  const [open, setOpen] = useState(false);
  const Icon = MODE_ICONS[value];
  return <>
    <button type="button" className="match-select" onClick={() => setOpen(true)} disabled={disabled} aria-label="Выбрать режим">
      <Icon size={20} /><span><small>РЕЖИМ ИГРЫ</small><b>{MODE_INFO[value].name}</b></span><ChevronDown size={16} />
    </button>
    {open && <ModalFrame title="Выбор режима" onClose={() => setOpen(false)} className="mode-dialog">
      <div className="dialog-top"><div><span className="overline">ПРАВИЛА АРЕНЫ</span><h2>Выбери свой режим</h2></div><button className="icon-button" onClick={() => setOpen(false)} aria-label="Закрыть"><X size={20} /></button></div>
      <div className="mode-list">
        {(Object.keys(MODE_INFO) as GameMode[]).map(mode => {
          const ItemIcon = MODE_ICONS[mode];
          return <button key={mode} className={`mode-option ${value === mode ? 'selected' : ''}`} onClick={() => { onChange(mode); setOpen(false); }}>
            <ItemIcon size={22} /><span><b>{MODE_INFO[mode].name}</b><small>{MODE_INFO[mode].description}</small></span>{value === mode && <Check size={18} />}
          </button>;
        })}
      </div>
      <p className="dialog-note">Любой режим доступен в соло, дуо и трио. В сетевом Versus участники сражаются друг против друга.</p>
    </ModalFrame>}
  </>;
}

export function BossSelect({ value, players, onChange, disabled = false }: { value: string; players: number; onChange: (id: string) => void; disabled?: boolean }) {
  const [open, setOpen] = useState(false);
  const boss = getCharacterById(value);
  return <>
    <button type="button" className="boss-select" onClick={() => setOpen(true)} disabled={disabled}>
      <Flame size={19} /><span><small>ЦЕЛЬ РЕЙДА</small><b>{boss.name}</b></span><em>{bossHealth(value, players).toLocaleString('ru-RU')} HP</em><ChevronDown size={15} />
    </button>
    {open && <ModalFrame title="Выбор босса" onClose={() => setOpen(false)} className="mode-dialog boss-dialog">
      <div className="dialog-top"><div><span className="overline">BOSS RAID</span><h2>Кому бросим вызов?</h2></div><button className="icon-button" onClick={() => setOpen(false)} aria-label="Закрыть"><X size={20} /></button></div>
      <p className="dialog-note">{players} {players === 1 ? 'игрок' : 'игрока'} в команде. Здоровье босса: x{raidScale(players)}.</p>
      <div className="boss-list">
        {RAID_BOSSES.map(b => <button key={b.id} className={`boss-option ${value === b.id ? 'selected' : ''}`} onClick={() => { onChange(b.id); setOpen(false); }}>
          <CharacterPreviewCanvas character={getCharacterById(b.id)} size={58} />
          <span><small>УРОВЕНЬ {b.tier}</small><b>{getCharacterById(b.id).name}</b><small>{b.title}</small></span>
          <em>{bossHealth(b.id, players).toLocaleString('ru-RU')}<small>HP</small></em>
          {value === b.id && <Check size={16} />}
        </button>)}
      </div>
    </ModalFrame>}
  </>;
}