import React, { useState, useMemo } from 'react';
import { Character, Rarity } from '../../types/game';
import { ALL_CHARACTERS, getCharacterById } from '../../data/characters';
import { CharacterPreviewCanvas } from './CharacterPreviewCanvas';
import { soundManager } from '../../audio/soundManager';
import { Search, Shield, Zap, Sparkles, Swords, ChevronLeft, Check, Lock, Coins, Eye, ShieldCheck } from 'lucide-react';

// Мини-компонент прогресс-бара квеста Годжо
const QuestProgress: React.FC<{ label: string; current: number; required: number }> = ({ label, current, required }) => {
  const done = current >= required;
  const pct = Math.min(100, (current / required) * 100);
  return (
    <div>
      <div className="flex items-center justify-between text-[11px]">
        <span className={done ? 'text-emerald-300 font-bold' : 'text-slate-300'}>
          {done ? '✓ ' : ''}{label}
        </span>
        <span className="font-mono text-slate-400">
          {Math.min(current, required)}/{required}
        </span>
      </div>
      <div className="w-full h-2 bg-slate-800 rounded-full mt-1 overflow-hidden">
        <div
          className={`h-full rounded-full transition-all ${done ? 'bg-emerald-400' : 'bg-purple-400'}`}
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  );
};

interface CharacterSelectProps {
  unlockedCharacterIds: string[];
  selectedPlayerCharId: string;
  selectedBotCharId: string;
  userCoins: number;
  onSelectPlayer: (id: string) => void;
  onSelectBot: (id: string) => void;
  onUnlockCharacter: (id: string, cost: number) => boolean;
  onBackToMenu: () => void;
  onGoToShop: () => void;
  /** Прогресс квестов Годжо */
  gojoQuest?: { damage: number; wins: number; crates: number; ascended: boolean };
  /** Прогресс мастери OVERKILL */
  overkillQuest?: { kills: number; wins: number; waves: number; mastery: boolean };
}

const CATEGORIES = [
  'Все',
  'Minecraft',
  'Undertale',
  'FNAF',
  'Analog Horror',
  'Subnautica',
  'Combat Masters',
  'Anime & Gods',
  'Glitch & Chaos',
  'Doors',
  'Vehicles & Mechs',
  'OS Wars',
  'Memes & Special'
];

const RARITY_COLORS: Record<Rarity, { bg: string; text: string; border: string }> = {
  starter: { bg: 'bg-emerald-950/80', text: 'text-emerald-400', border: 'border-emerald-500/40' },
  common: { bg: 'bg-slate-800/80', text: 'text-slate-300', border: 'border-slate-600/40' },
  rare: { bg: 'bg-blue-950/80', text: 'text-blue-400', border: 'border-blue-500/40' },
  epic: { bg: 'bg-purple-950/80', text: 'text-purple-400', border: 'border-purple-500/40' },
  legendary: { bg: 'bg-amber-950/80', text: 'text-amber-400', border: 'border-amber-500/40' },
  mythic: { bg: 'bg-rose-950/80', text: 'text-rose-400', border: 'border-rose-500/40' },
  godly: { bg: 'bg-yellow-950/90', text: 'text-yellow-300', border: 'border-yellow-400' },
  secret: { bg: 'bg-fuchsia-950/90', text: 'text-cyan-200', border: 'border-fuchsia-400' },
  boss: { bg: 'bg-orange-950/90', text: 'text-orange-300', border: 'border-orange-400' }
};

export const CharacterSelect: React.FC<CharacterSelectProps> = ({
  unlockedCharacterIds,
  selectedPlayerCharId,
  selectedBotCharId,
  userCoins,
  onSelectPlayer,
  onSelectBot,
  onUnlockCharacter,
  onBackToMenu,
  onGoToShop,
  gojoQuest,
  overkillQuest
}) => {
  const [activeCategory, setActiveCategory] = useState<string>('Все');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [filterUnlockedOnly, setFilterUnlockedOnly] = useState<boolean>(false);
  const [inspectCharId, setInspectCharId] = useState<string>(selectedPlayerCharId);
  // Цель выбора: ты или бот/2 игрок
  const [selectTarget, setSelectTarget] = useState<'player' | 'bot'>('player');
  // Двойной тап для выбора
  const lastTapRef = React.useRef<{ id: string; time: number }>({ id: '', time: 0 });

  const visibleRosterCount = ALL_CHARACTERS.filter(
    char => char.rarity !== 'secret' || unlockedCharacterIds.includes(char.id)
  ).length;
  const visibleOwnedCount = unlockedCharacterIds.filter(id => {
    const char = ALL_CHARACTERS.find(c => c.id === id);
    return char && (char.rarity !== 'secret' || unlockedCharacterIds.includes(char.id));
  }).length;

  const inspectedCharacter = useMemo(() => {
    return getCharacterById(inspectCharId);
  }, [inspectCharId]);

  const filteredCharacters = useMemo(() => {
    return ALL_CHARACTERS.filter(char => {
      // SECRET-персонажи полностью невидимы в инвентаре, пока игрок их не получил.
      if (char.rarity === 'secret' && !unlockedCharacterIds.includes(char.id)) return false;
      // Category filter
      if (activeCategory !== 'Все' && char.category !== activeCategory) {
        return false;
      }
      // Unlocked filter
      if (filterUnlockedOnly && !unlockedCharacterIds.includes(char.id)) {
        return false;
      }
      // Search query
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const matchesName = char.name.toLowerCase().includes(query);
        const matchesTitle = char.titleRu.toLowerCase().includes(query);
        const matchesAbility = char.ability.nameRu.toLowerCase().includes(query);
        return matchesName || matchesTitle || matchesAbility;
      }
      return true;
    });
  }, [activeCategory, filterUnlockedOnly, searchQuery, unlockedCharacterIds]);

  const isInspectedUnlocked = unlockedCharacterIds.includes(inspectedCharacter.id);

  const handleBuy = (char: Character) => {
    soundManager.playClick();
    if (userCoins >= char.price) {
      const ok = onUnlockCharacter(char.id, char.price);
      if (ok) {
        soundManager.playPowerup();
      }
    } else {
      onGoToShop();
    }
  };

  return (
    <div className="w-full h-full min-h-screen bg-slate-950 text-white flex flex-col select-none overflow-y-auto">
      {/* Header Bar */}
      <div className="sticky top-0 z-30 bg-slate-900/90 backdrop-blur-md border-b border-slate-800 px-4 py-3 flex items-center justify-between shadow-xl">
        <div className="flex items-center gap-3">
          <button
            onClick={() => {
              soundManager.playClick();
              onBackToMenu();
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-sm font-semibold transition-all cursor-pointer"
          >
            <ChevronLeft className="w-4 h-4" />
            В Меню
          </button>
          <div>
            <h1 className="text-lg font-black tracking-wider uppercase text-transparent bg-clip-text bg-gradient-to-r from-sky-400 to-indigo-400">
              Выбор Бойца ({visibleOwnedCount}/{visibleRosterCount})
            </h1>
          </div>
        </div>

        {/* Coins & Shop Quicklink */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 bg-amber-500/15 border border-amber-500/40 px-3.5 py-1.5 rounded-2xl">
            <Coins className="w-4 h-4 text-amber-400 animate-pulse" />
            <span className="font-extrabold text-amber-300 text-sm">{userCoins.toLocaleString()}</span>
          </div>
          <button
            onClick={() => {
              soundManager.playClick();
              onGoToShop();
            }}
            className="px-3.5 py-1.5 rounded-2xl bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 font-black text-xs uppercase tracking-wider shadow-md hover:brightness-110 cursor-pointer"
          >
            Магазин
          </button>
        </div>
      </div>

      {/* Main Grid & Details Section */}
      <div className="flex-1 max-w-7xl w-full mx-auto p-4 grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Filters & 71 Characters Grid */}
        <div className="lg:col-span-8 flex flex-col gap-4">
          {/* Search & Unlock Filter */}
          <div className="flex flex-wrap items-center gap-3">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder={`Поиск среди ${visibleRosterCount} бойцов...`}
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-sm text-white placeholder-slate-400 focus:outline-none focus:border-sky-500"
              />
            </div>
            <button
              onClick={() => {
                soundManager.playClick();
                setFilterUnlockedOnly(!filterUnlockedOnly);
              }}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer border ${
                filterUnlockedOnly
                  ? 'bg-sky-600 border-sky-400 text-white'
                  : 'bg-slate-900 border-slate-700 text-slate-300 hover:bg-slate-800'
              }`}
            >
              {filterUnlockedOnly ? '✓ Только открытые' : 'Все персонажи'}
            </button>
          </div>

          {/* Categories Tab Bar */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-thin">
            {CATEGORIES.map(cat => (
              <button
                key={cat}
                onClick={() => {
                  soundManager.playClick();
                  setActiveCategory(cat);
                }}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer border ${
                  activeCategory === cat
                    ? 'bg-gradient-to-r from-sky-500 to-blue-600 border-sky-400 text-white shadow-md'
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* ЦЕЛЬ ВЫБОРА: ты или бот/2 игрок — переключатель сверху */}
          <div className="flex items-center gap-2 bg-slate-900/90 border border-slate-700 p-1.5 rounded-2xl">
            <span className="text-[10px] font-black uppercase text-slate-400 pl-2 tracking-wider shrink-0">
              Выбираем для:
            </span>
            <button
              onClick={() => {
                soundManager.playClick();
                setSelectTarget('player');
              }}
              className={`flex-1 py-2 rounded-xl text-xs font-black uppercase transition-all cursor-pointer ${
                selectTarget === 'player'
                  ? 'bg-gradient-to-r from-sky-500 to-blue-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              ТЫ (Игрок 1)
            </button>
            <button
              onClick={() => {
                soundManager.playClick();
                setSelectTarget('bot');
              }}
              className={`flex-1 py-2 rounded-xl text-xs font-black uppercase transition-all cursor-pointer ${
                selectTarget === 'bot'
                  ? 'bg-gradient-to-r from-rose-500 to-pink-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Бот / Игрок 2
            </button>
          </div>
          {/* Подсказка: двойной тап */}
          <div className="px-3 py-2 rounded-xl bg-slate-800/60 border border-slate-700/60 text-[11px] text-slate-300 flex items-center gap-2">
            <Sparkles className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <span>
              <b className={selectTarget === 'player' ? 'text-sky-400' : 'text-rose-400'}>
                {selectTarget === 'player' ? 'ТЫ' : 'ПРОТИВНИК'}
              </b>
              {' '}— нажми на персонажа <b>2 раза</b>, чтобы выбрать мгновенно!
            </span>
          </div>

          {/* Roster Cards Grid */}
          <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 xl:grid-cols-6 gap-3 max-h-[68vh] overflow-y-auto pr-1">
            {filteredCharacters.map(char => {
              const isUnlocked = unlockedCharacterIds.includes(char.id);
              const isSelectedP1 = selectedPlayerCharId === char.id;
              const isSelectedBot = selectedBotCharId === char.id;
              const isInspected = inspectedCharacter.id === char.id;
              const rStyle = RARITY_COLORS[char.rarity] || RARITY_COLORS.common;

              return (
                <div
                  key={char.id}
                  onClick={() => {
                    const now = Date.now();
                    const isDoubleTap = lastTapRef.current.id === char.id && now - lastTapRef.current.time < 450;
                    lastTapRef.current = { id: char.id, time: now };

                    if (isDoubleTap && isUnlocked) {
                      // ДВОЙНОЙ ТАП — мгновенный выбор для текущей цели!
                      soundManager.playPowerup();
                      if (selectTarget === 'player') {
                        onSelectPlayer(char.id);
                      } else {
                        onSelectBot(char.id);
                      }
                      setInspectCharId(char.id);
                    } else {
                      soundManager.playClick();
                      setInspectCharId(char.id);
                    }
                  }}
                  className={`relative flex flex-col items-center p-2.5 rounded-2xl border transition-all cursor-pointer select-none group ${char.rarity === 'secret' ? 'secret-card' : ''} ${
                    isInspected
                      ? 'ring-2 ring-sky-400 bg-slate-800/95 scale-[1.02] shadow-lg shadow-sky-500/20'
                      : 'bg-slate-900/80 hover:bg-slate-850 border-slate-800'
                  }`}
                >
                  {/* Selected Badges */}
                  <div className="absolute top-1.5 left-1.5 flex gap-1 z-10">
                    {isSelectedP1 && (
                      <span className="px-1.5 py-0.5 rounded-md bg-sky-500 text-slate-950 font-black text-[9px] uppercase shadow">
                        P1
                      </span>
                    )}
                    {isSelectedBot && (
                      <span className="px-1.5 py-0.5 rounded-md bg-rose-500 text-white font-black text-[9px] uppercase shadow">
                        BOT
                      </span>
                    )}
                  </div>

                  {/* Character Avatar Icon / Canvas */}
                  <div className="relative my-1">
                    <div
                      className="w-14 h-14 rounded-full flex items-center justify-center font-bold text-2xl shadow-inner border-2 transition-transform group-hover:scale-105"
                      style={{
                        backgroundColor: char.avatarColor,
                        borderColor: char.glowColor
                      }}
                    >
                      {char.iconEmoji || '👤'}
                    </div>
                    {/* Lock overlay if locked */}
                    {!isUnlocked && (
                      <div className="absolute inset-0 rounded-full bg-slate-950/70 backdrop-blur-[1px] flex items-center justify-center">
                        <Lock className="w-5 h-5 text-amber-400" />
                      </div>
                    )}
                  </div>

                  {/* Name & Title */}
                  <div className="text-center w-full mt-1">
                    {char.id === 'glitch_secret' ? (
                      <div className="secret-glitch text-xs font-black uppercase tracking-tight">GLITCH</div>
                    ) : char.id === 'lighting_secret' ? (
                      <div className="secret-lighting text-xs font-black uppercase tracking-tight">LIGHTING</div>
                    ) : char.id === 'ultrakill' ? (
                      <div className="ultra-name text-xs font-black uppercase tracking-tight">ULTRAKILL</div>
                    ) : char.id === 'final' ? (
                      <div className="final-glitch text-xs font-black text-rose-400 uppercase tracking-tight">FINAL</div>
                    ) : char.id === 'stellar' ? (
                      <div className="stellar-name text-xs font-black uppercase tracking-tight">STELLAR</div>
                    ) : char.id === 'god_of_war' ? (
                      <div className="godofwar-name text-xs font-black uppercase tracking-tight">GOD OF WAR</div>
                    ) : char.id === 'sword_glitcher' ? (
                      <div className="glitcher-name text-xs font-black uppercase tracking-tight">SWORD GLITCHER</div>
                    ) : (
                      <div className="text-xs font-black truncate text-white uppercase tracking-tight">{char.name}</div>
                    )}
                    <span
                      className={`inline-block mt-0.5 px-1.5 py-0.2 rounded text-[9px] font-bold uppercase ${rStyle.bg} ${rStyle.text} border ${rStyle.border}`}
                    >
                      {char.rarity}
                    </span>
                  </div>

                  {/* Price or Giant badge */}
                  <div className="mt-1.5 text-[10px] font-semibold text-slate-400 flex items-center gap-1">
                    {char.isGiant && <span className="text-cyan-400">🌌 Гигант</span>}
                    {!isUnlocked && (
                      <span className="text-amber-400 font-bold flex items-center gap-0.5">
                        <Coins className="w-3 h-3" />
                        {char.price.toLocaleString()}
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column: Character Inspector & Stats Card */}
        <div className="lg:col-span-4 bg-slate-900/90 border border-slate-800 rounded-3xl p-5 flex flex-col justify-between shadow-2xl">
          <div className="flex flex-col gap-4">
            {/* Top Info & Rarity */}
            <div className="flex items-start justify-between">
              <div>
                <span className="text-[10px] font-bold uppercase text-slate-400 tracking-wider">
                  #{inspectedCharacter.num} • {inspectedCharacter.category}
                </span>
                {inspectedCharacter.id === 'glitch_secret' ? (
                  <h2 className="secret-glitch text-xl font-black tracking-wide uppercase mt-0.5">GLITCH</h2>
                ) : inspectedCharacter.id === 'lighting_secret' ? (
                  <h2 className="secret-lighting text-xl font-black tracking-wide uppercase mt-0.5">LIGHTING</h2>
                ) : inspectedCharacter.id === 'ultrakill' ? (
                  <h2 className="ultra-name text-2xl font-black tracking-widest uppercase mt-0.5">ULTRAKILL</h2>
                ) : inspectedCharacter.id === 'final' ? (
                  <h2 className="final-glitch-big text-xl font-black text-rose-400 tracking-wide uppercase mt-0.5 final-scanlines px-2 py-0.5 rounded">
                    FINAL
                  </h2>
                ) : inspectedCharacter.id === 'stellar' ? (
                  <h2 className="stellar-name text-xl font-black tracking-wide uppercase mt-0.5">STELLAR</h2>
                ) : inspectedCharacter.id === 'god_of_war' ? (
                  <h2 className="godofwar-name text-xl font-black tracking-wide uppercase mt-0.5">GOD OF WAR</h2>
                ) : inspectedCharacter.id === 'sword_glitcher' ? (
                  <h2 className="glitcher-name text-xl font-black tracking-wide uppercase mt-0.5">SWORD GLITCHER</h2>
                ) : (
                  <h2 className="text-xl font-black text-white tracking-wide uppercase mt-0.5">
                    {inspectedCharacter.name}
                  </h2>
                )}
                <div className="text-xs text-slate-300">{inspectedCharacter.titleRu}</div>
              </div>
              <span
                className={`px-2.5 py-1 rounded-xl text-xs font-black uppercase tracking-wider ${
                  RARITY_COLORS[inspectedCharacter.rarity]?.bg
                } ${RARITY_COLORS[inspectedCharacter.rarity]?.text} border ${
                  RARITY_COLORS[inspectedCharacter.rarity]?.border
                }`}
              >
                {inspectedCharacter.rarity}
              </span>
            </div>

            {/* Live Interactive Rotating Canvas Preview */}
            <div className="w-full flex items-center justify-center bg-slate-950/80 rounded-2xl border border-slate-800 p-2 shadow-inner">
              <CharacterPreviewCanvas character={inspectedCharacter} size={150} />
            </div>

            {/* Combat Stats Bars */}
            <div className="space-y-2 bg-slate-950/60 p-3 rounded-2xl border border-slate-800/80 text-xs">
              <div className="flex items-center justify-between text-slate-300">
                <span className="flex items-center gap-1.5">
                  <Shield className="w-3.5 h-3.5 text-rose-400" /> Здоровье (HP)
                </span>
                <span className="font-bold text-rose-400">{inspectedCharacter.maxHp} HP</span>
              </div>
              <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                <div
                  className="bg-rose-500 h-full rounded-full"
                  style={{ width: `${Math.min(100, (inspectedCharacter.maxHp / 30) * 100)}%` }}
                />
              </div>

              <div className="flex items-center justify-between text-slate-300 mt-2">
                <span className="flex items-center gap-1.5">
                  <Zap className="w-3.5 h-3.5 text-amber-400" /> Скорость
                </span>
                <span className="font-bold text-amber-400">
                  {((inspectedCharacter.baseSpeed + (inspectedCharacter.speedBonus || 0) * 0.1) * (inspectedCharacter.speedMultiplier || 1)).toFixed(1)}
                  {inspectedCharacter.speedMultiplier ? ` (x${inspectedCharacter.speedMultiplier})` : inspectedCharacter.speedBonus ? ` (+${inspectedCharacter.speedBonus} БАФФ)` : ''}
                </span>
              </div>
              <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                <div
                  className="bg-amber-500 h-full rounded-full"
                  style={{
                    width: `${Math.min(100, (((inspectedCharacter.baseSpeed + (inspectedCharacter.speedBonus || 0) * 0.1) * (inspectedCharacter.speedMultiplier || 1)) / 18) * 100)}%`
                  }}
                />
              </div>

              <div className="flex items-center justify-between text-slate-300 mt-2">
                <span className="flex items-center gap-1.5">
                  <Swords className="w-3.5 h-3.5 text-sky-400" /> Дистанция оружия
                </span>
                <span className="font-bold text-sky-400">{inspectedCharacter.weaponReach} px</span>
              </div>
              <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                <div
                  className="bg-sky-500 h-full rounded-full"
                  style={{ width: `${Math.min(100, (inspectedCharacter.weaponReach / 55) * 100)}%` }}
                />
              </div>
            </div>

            {/* Special Ability Card */}
            <div className="bg-gradient-to-br from-slate-950 to-indigo-950/40 border border-indigo-500/30 p-3.5 rounded-2xl">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-cyan-400" />
                  <span className="text-xs font-black text-cyan-300 uppercase tracking-wide">
                    {inspectedCharacter.ability.nameRu}
                  </span>
                </div>
                <span className="text-[11px] font-bold text-slate-400">
                  КД: {inspectedCharacter.ability.cooldown}с
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-1.5 leading-relaxed">
                {inspectedCharacter.ability.description}
              </p>
              <div className="mt-2 text-[11px] text-slate-400 italic">
                Пассивка: {inspectedCharacter.passiveDesc}
              </div>

              {/* Дополнительные способности в цепочке */}
              {inspectedCharacter.extraAbilities && inspectedCharacter.extraAbilities.length > 0 && (
                <div className="mt-2.5 pt-2.5 border-t border-indigo-500/20 space-y-1.5">
                  <div className="text-[10px] font-black text-amber-300 uppercase tracking-wider">
                    Следующие в цепочке:
                  </div>
                  {inspectedCharacter.extraAbilities.map(ab => {
                    const isLockedGojo =
                      ((ab.id === 'hollow_purple' || ab.id === 'infinity_void') && !gojoQuest?.ascended) ||
                      (ab.id === 'overkill_mastery' && !overkillQuest?.mastery);
                    return (
                      <div
                        key={ab.id}
                        className={`flex items-center justify-between text-[11px] px-2 py-1.5 rounded-lg ${
                          isLockedGojo ? 'bg-rose-950/40 border border-rose-500/20' : 'bg-slate-900/60 border border-slate-800'
                        }`}
                      >
                        <div className="flex items-center gap-1.5">
                          {isLockedGojo ? (
                            <Lock className="w-3 h-3 text-rose-400" />
                          ) : (
                            <Sparkles className="w-3 h-3 text-emerald-400" />
                          )}
                          <span className={isLockedGojo ? 'text-rose-300' : 'text-slate-200'}>{ab.nameRu}</span>
                        </div>
                        <span className="text-slate-500">{ab.cooldown}с</span>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* ПАНЕЛЬ КВЕСТОВ ГОДЖО (3 сложных квеста для пробуждения ульты) */}
            {inspectedCharacter.id === 'gojo' && gojoQuest && (
              <div className={`border rounded-2xl p-4 transition-all ${
                gojoQuest.ascended
                  ? 'bg-purple-950/50 border-purple-500/50 shadow-lg shadow-purple-500/20'
                  : 'bg-slate-950/70 border-purple-500/30'
              }`}>
                <div className="flex items-center gap-2 mb-2.5">
                  <Eye className="w-4 h-4 text-purple-400" />
                  <span className="text-xs font-black uppercase text-purple-300 tracking-wider">
                    Пробуждение Годжо — Hollow Purple + Infinity Void
                  </span>
                </div>
                {gojoQuest.ascended ? (
                  <div className="text-xs text-emerald-300 font-bold flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4" />
                    ПРОБУЖДЁН! Ульты разблокированы и циклируются в бою!
                  </div>
                ) : (
                  <div className="space-y-2.5">
                    <QuestProgress label="Нанеси 300 урона за Годжо" current={gojoQuest.damage} required={300} />
                    <QuestProgress label="Одержи 5 побед за Годжо" current={gojoQuest.wins} required={5} />
                    <QuestProgress label="Открой 3 ящика" current={gojoQuest.crates} required={3} />
                  </div>
                )}
              </div>
            )}

            {/* ПАНЕЛЬ МАСТЕРИ OVERKILL (3 очень сложных квеста, копятся между играми) */}
            {inspectedCharacter.id === 'overkill_glove' && overkillQuest && (
              <div className={`border rounded-2xl p-4 transition-all ${
                overkillQuest.mastery
                  ? 'bg-orange-950/50 border-amber-400/60 shadow-lg shadow-amber-500/20'
                  : 'bg-slate-950/70 border-amber-500/30'
              }`}>
                <div className="flex items-center gap-2 mb-2.5">
                  <Zap className="w-4 h-4 text-amber-400" />
                  <span className="text-xs font-black uppercase text-amber-300 tracking-wider">
                    Мастери OVERKILL — Магмовый Апокалипсис
                  </span>
                </div>
                {overkillQuest.mastery ? (
                  <div className="text-xs text-emerald-300 font-bold flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4" />
                    МАСТЕРИ ПОЛУЧЕНО! Апокалипсис доступен в цепочке способностей!
                  </div>
                ) : (
                  <div className="space-y-2.5">
                    <QuestProgress label="Убей 1000 врагов (суммарно)" current={overkillQuest.kills} required={1000} />
                    <QuestProgress label="Выиграй 99 боёв" current={overkillQuest.wins} required={99} />
                    <QuestProgress label="Пройди 1000 волн Endless (копятся между играми)" current={overkillQuest.waves} required={1000} />
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Action Buttons: Select P1 / Select Bot / Buy */}
          <div className="flex flex-col gap-2 mt-4 pt-4 border-t border-slate-800">
            {isInspectedUnlocked ? (
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => {
                    soundManager.playClick();
                    onSelectPlayer(inspectedCharacter.id);
                  }}
                  className={`py-3 px-3 rounded-2xl font-black text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-lg active:scale-95 ${
                    selectedPlayerCharId === inspectedCharacter.id
                      ? 'bg-emerald-600 border border-emerald-400 text-white'
                      : 'bg-sky-600 hover:bg-sky-500 border border-sky-400 text-white shadow-sky-500/20'
                  }`}
                >
                  <Check className="w-4 h-4" />
                  {selectedPlayerCharId === inspectedCharacter.id ? 'ВЫБРАН (P1)' : 'ВЫБРАТЬ (P1)'}
                </button>

                <button
                  onClick={() => {
                    soundManager.playClick();
                    onSelectBot(inspectedCharacter.id);
                  }}
                  className={`py-3 px-3 rounded-2xl font-black text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-lg active:scale-95 ${
                    selectedBotCharId === inspectedCharacter.id
                      ? 'bg-rose-600 border border-rose-400 text-white'
                      : 'bg-slate-800 hover:bg-slate-700 border border-slate-600 text-slate-200'
                  }`}
                >
                  {selectedBotCharId === inspectedCharacter.id ? 'ВЫБРАН (БОТ)' : 'ВЫБРАТЬ ДЛЯ БОТА'}
                </button>
              </div>
            ) : (
              <button
                onClick={() => handleBuy(inspectedCharacter)}
                className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 text-slate-950 font-black text-sm uppercase tracking-wider shadow-lg shadow-amber-500/20 flex items-center justify-center gap-2 hover:brightness-110 active:scale-95 cursor-pointer"
              >
                <Coins className="w-5 h-5" />
                Купить за {inspectedCharacter.price.toLocaleString()} монет
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
