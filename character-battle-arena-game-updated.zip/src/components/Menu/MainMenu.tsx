import { useState } from 'react';
import { Character, GameMode, PlayerProgress } from '../../types/game';
import { CharacterPreviewCanvas } from '../Selection/CharacterPreviewCanvas';
import { ALL_CHARACTERS } from '../../data/characters';
import { soundManager } from '../../audio/soundManager';
import { Play, Users, ShoppingBag, Package, Settings, Flame, ShieldAlert, Swords, Trophy, Coins, Zap, Crown } from 'lucide-react';

interface MainMenuProps {
  save: PlayerProgress;
  selectedPlayerChar: Character;
  selectedBotChar: Character;
  currentMode: GameMode;
  endlessSubmode?: 'standard' | 'duo' | 'last';
  onChangeEndlessSubmode?: (mode: 'standard' | 'duo' | 'last') => void;
  onChangeMode: (mode: GameMode) => void;
  onChangeBoss: (id: string) => void;
  onStartGame: () => void;
  onOpenCharacterSelect: () => void;
  onOpenShop: () => void;
  onOpenCrates: () => void;
  onOpenSettings: () => void;
  teamSize: 1 | 2;
  onTeamSize: (size: 1 | 2) => void;
  onLocalRaid?: (players: 1 | 2) => void;
}

// Подборка разблокированных боссов для выбора в рейде.
export function MainMenu({ save, selectedPlayerChar, selectedBotChar, currentMode, endlessSubmode = 'standard',
  onChangeEndlessSubmode, onChangeMode, onChangeBoss, onStartGame, onOpenCharacterSelect, onOpenShop,
  onOpenCrates, onOpenSettings, teamSize, onTeamSize, onLocalRaid }: MainMenuProps) {
  const [showModeModal, setShowModeModal] = useState(false);
  const [showBossModal, setShowBossModal] = useState(false);
  const winRate = save.matchesPlayed > 0 ? Math.round((save.wins / save.matchesPlayed) * 100) : 0;
  const bosses = ALL_CHARACTERS.filter(c => c.rarity === 'boss' && save.unlockedBosses.includes(c.id));
  const visibleCount = ALL_CHARACTERS.filter(c => c.id !== 'volcanic_ash' && (c.rarity !== 'secret' || save.unlockedCharacters.includes(c.id))).length;

  const RaidBossPicker = () => (
    <div className={`${showBossModal ? 'fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4' : ''}`} onClick={() => setShowBossModal(false)}>
      <div className={showBossModal ? 'bg-slate-900 border border-orange-500/30 rounded-3xl p-5 w-full max-w-md flex flex-col gap-3 shadow-2xl max-h-[86vh] overflow-y-auto' : ''} onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-black uppercase tracking-wide text-orange-300 flex items-center gap-2"><Crown size={16} /> Выбери босса рейда</h3>
          {showBossModal && <button onClick={() => setShowBossModal(false)} className="w-8 h-8 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-black cursor-pointer">✕</button>}
        </div>
        {bosses.length === 0 && <p className="text-xs text-slate-400">Пока нет побеждённых боссов. Начни с доступного босса в рейде и победи его.</p>}
        <div className="flex flex-col gap-2">
          {bosses.map(b => (
            <button key={b.id} onClick={() => { soundManager.playClick(); onChangeBoss(b.id); setShowBossModal(false); }}
              className={`flex items-center gap-3 p-3 rounded-2xl border transition-all cursor-pointer text-left ${selectedBotChar.id === b.id ? 'bg-orange-950/60 border-orange-400 ring-2 ring-orange-500/20' : 'bg-slate-950/60 border-slate-800 hover:border-orange-600/50'}`}>
              <CharacterPreviewCanvas character={b} size={62} />
              <div className="min-w-0"><div className="text-xs font-black uppercase text-white">{b.name}</div><div className="text-[10px] text-slate-400">{b.titleRu}</div></div>
              <span className="ml-auto text-[10px] font-bold text-orange-300">{b.maxHp} HP</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );

  return (
    <div className="w-full h-full min-h-screen bg-slate-950 text-white flex flex-col justify-between p-4 sm:p-6 select-none overflow-y-auto relative">
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#1e293b15_1px,transparent_1px),linear-gradient(to_bottom,#1e293b15_1px,transparent_1px)] bg-[size:3rem_3rem] pointer-events-none" />

      {/* Top Header */}
      <div className="relative z-10 max-w-5xl w-full mx-auto flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-cyan-500 to-indigo-600 flex items-center justify-center font-black text-2xl shadow-lg shadow-cyan-500/20 border border-cyan-400/40 animate-pulse">⚔️</div>
          <div>
            <h1 className="text-xl sm:text-2xl font-black uppercase tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-sky-300 to-indigo-400">CIRCLE ARENA BRAWL</h1>
            <p className="text-[11px] text-slate-400 font-bold uppercase tracking-widest">{visibleCount} Боец • Физические Дуэли • Способности</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <div onClick={() => { soundManager.playClick(); onOpenShop(); }} className="flex items-center gap-2 bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/40 px-3.5 py-2 rounded-2xl transition-all cursor-pointer shadow-inner">
            <Coins className="w-4 h-4 text-amber-400 animate-pulse" /><span className="font-extrabold text-amber-300 text-sm">{save.coins.toLocaleString('ru-RU')}</span>
          </div>
          <button onClick={() => { soundManager.playClick(); onOpenSettings(); }} className="w-10 h-10 rounded-2xl bg-slate-900 border border-slate-700 hover:border-slate-500 text-slate-300 flex items-center justify-center transition-all cursor-pointer shadow-lg hover:text-white"><Settings className="w-5 h-5" /></button>
        </div>
      </div>

      {/* Center match preview & start */}
      <div className="relative z-10 max-w-5xl w-full mx-auto my-auto py-6 flex flex-col items-center gap-6">
        <button onClick={() => { soundManager.playClick(); setShowModeModal(true); }}
          className="px-4 py-2 rounded-2xl bg-slate-900/90 border border-sky-500/30 hover:border-sky-400 text-xs font-black uppercase tracking-wider text-sky-300 flex items-center gap-2 transition-all cursor-pointer shadow-lg hover:scale-105 active:scale-95">
          {currentMode === 'standard' && <Swords className="w-4 h-4 text-sky-400" />}
          {currentMode === 'final_health' && <Flame className="w-4 h-4 text-rose-400" />}
          {currentMode === 'boss_raid' && <ShieldAlert className="w-4 h-4 text-amber-400" />}
          {currentMode === 'two_player' && <Users className="w-4 h-4 text-emerald-400" />}
          {currentMode === 'endless' && <Flame className="w-4 h-4 text-amber-400" />}
          <span>РЕЖИМ: {currentMode === 'standard' ? 'СТАНДАРТ (7 HP + СФЕРЫ)' : currentMode === 'final_health' ? 'FINAL HEALTH (1 HP)' : currentMode === 'boss_raid' ? 'BOSS RAID' : currentMode === 'endless' ? `ENDLESS (${endlessSubmode === 'duo' ? 'ДУО' : endlessSubmode === 'last' ? 'ЛАСТ' : 'СТАНДАРТ'})` : '2 ИГРОКА (LOCAL 1v1)'}</span>
          <span className="text-slate-500">▼</span>
        </button>

        {/* Matchup card */}
        <div className="w-full max-w-3xl bg-slate-900/80 border border-slate-800 rounded-3xl p-6 shadow-2xl backdrop-blur-sm grid grid-cols-1 md:grid-cols-3 gap-6 items-center">
          <div onClick={() => { soundManager.playClick(); onOpenCharacterSelect(); }} className="flex flex-col items-center text-center p-3 rounded-2xl bg-slate-950/70 border border-sky-500/30 hover:border-sky-400 transition-all cursor-pointer group hover:scale-[1.02]">
            <span className="text-[10px] font-black uppercase tracking-wider text-sky-400 mb-1">ТВОЙ БОЕЦ (ИГРОК 1)</span>
            <div className="bg-slate-900/60 p-2 rounded-2xl border border-slate-800 my-1 group-hover:shadow-lg group-hover:shadow-sky-500/20 transition-all"><CharacterPreviewCanvas character={selectedPlayerChar} size={110} /></div>
            <div className="text-base font-black text-white uppercase mt-1">{selectedPlayerChar.name}</div>
            <div className="text-[11px] text-slate-400">{selectedPlayerChar.titleRu}</div>
            <div className="mt-2 text-[10px] font-bold text-sky-300 bg-sky-950/80 border border-sky-500/30 px-2 py-0.5 rounded-lg">✨ {selectedPlayerChar.ability.nameRu}</div>
          </div>

          <div className="flex flex-col items-center justify-center text-center gap-3">
            <div className="w-14 h-14 rounded-full bg-gradient-to-tr from-rose-600 to-amber-500 flex items-center justify-center font-black text-xl text-white shadow-xl shadow-rose-600/30 border border-amber-400 animate-pulse">VS</div>
            <button onClick={() => { soundManager.playClick(); if (currentMode === 'boss_raid' && onLocalRaid && teamSize > 1) onLocalRaid(teamSize); else onStartGame(); }}
              className="w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500 hover:brightness-110 text-slate-950 font-black text-base uppercase tracking-wider shadow-xl shadow-emerald-500/30 flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-95 hover:scale-105">
              <Play className="w-5 h-5 fill-current" />{currentMode === 'boss_raid' && teamSize > 1 ? 'НАЧАТЬ РЕЙД (ЛОКАЛЬНО)' : 'В БОЙ!'}
            </button>
          </div>

          <div onClick={() => { soundManager.playClick(); if (currentMode === 'boss_raid') setShowBossModal(true); else onOpenCharacterSelect(); }} className="flex flex-col items-center text-center p-3 rounded-2xl bg-slate-950/70 border border-rose-500/30 hover:border-rose-400 transition-all cursor-pointer group hover:scale-[1.02]">
            <span className="text-[10px] font-black uppercase tracking-wider text-rose-400 mb-1">{currentMode === 'boss_raid' ? 'БОСС РЕЙДА' : 'ПРОТИВНИК (БОТ)'}</span>
            <div className="bg-slate-900/60 p-2 rounded-2xl border border-slate-800 my-1 group-hover:shadow-lg group-hover:shadow-rose-500/20 transition-all"><CharacterPreviewCanvas character={selectedBotChar} size={110} /></div>
            <div className="text-base font-black text-white uppercase mt-1">{selectedBotChar.name}</div>
            <div className="text-[11px] text-slate-400">{selectedBotChar.titleRu}</div>
            <div className="mt-2 text-[10px] font-bold text-rose-300 bg-rose-950/80 border border-rose-500/30 px-2 py-0.5 rounded-lg">✨ {selectedBotChar.ability.nameRu}</div>
          </div>
        </div>

        {/* Team format */}
        <div className="w-full max-w-3xl flex flex-wrap items-center justify-center gap-3">
          <div className="flex items-center gap-2 bg-slate-900/80 border border-slate-700 rounded-2xl p-1.5">
            <span className="text-[11px] font-black uppercase text-slate-400 px-2">ФОРМАТ:</span>
            {([1, 2] as const).map(size => (
              <button key={size} onClick={() => { soundManager.playClick(); onTeamSize(size); }}
                className={`px-4 py-2 rounded-xl text-xs font-black uppercase transition-all cursor-pointer ${teamSize === size ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950' : 'text-slate-400 hover:text-white'}`}>
                {size === 1 ? 'Соло' : 'Дуо'}
              </button>
            ))}
          </div>
          {currentMode === 'boss_raid' && teamSize > 1 && <p className="text-[10px] text-orange-300/80">HP босса ×1.9 за двух игроков · играем вдвоём на этом экране</p>}
        </div>

        {/* Bottom nav */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 w-full max-w-3xl">
          <button onClick={() => { soundManager.playClick(); onOpenCharacterSelect(); }} className="p-3.5 rounded-2xl bg-slate-900/90 hover:bg-slate-800 border border-slate-700 hover:border-sky-400 flex flex-col items-center text-center transition-all cursor-pointer shadow-lg active:scale-95 group">
            <div className="w-9 h-9 rounded-xl bg-sky-500/20 text-sky-400 flex items-center justify-center mb-1 group-hover:scale-110 transition-transform"><Users className="w-5 h-5" /></div>
            <span className="text-xs font-black uppercase text-white tracking-wide">Выбор Бойца</span><span className="text-[10px] text-slate-400">{visibleCount} Персонажей</span>
          </button>
          <button onClick={() => { soundManager.playClick(); onOpenShop(); }} className="p-3.5 rounded-2xl bg-slate-900/90 hover:bg-slate-800 border border-slate-700 hover:border-amber-400 flex flex-col items-center text-center transition-all cursor-pointer shadow-lg active:scale-95 group">
            <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center mb-1 group-hover:scale-110 transition-transform"><ShoppingBag className="w-5 h-5" /></div>
            <span className="text-xs font-black uppercase text-white tracking-wide">Магазин</span><span className="text-[10px] text-slate-400">Бандлы & Бойцы</span>
          </button>
          <button onClick={() => { soundManager.playClick(); onOpenCrates(); }} className="p-3.5 rounded-2xl bg-slate-900/90 hover:bg-slate-800 border border-slate-700 hover:border-indigo-400 flex flex-col items-center text-center transition-all cursor-pointer shadow-lg active:scale-95 group">
            <div className="w-9 h-9 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center mb-1 group-hover:scale-110 transition-transform"><Package className="w-5 h-5" /></div>
            <span className="text-xs font-black uppercase text-white tracking-wide">Ящики</span><span className="text-[10px] text-slate-400">3 Вида Лутбоксов</span>
          </button>
          <button onClick={() => { soundManager.playClick(); onOpenSettings(); }} className="p-3.5 rounded-2xl bg-slate-900/90 hover:bg-slate-800 border border-slate-700 hover:border-slate-500 flex flex-col items-center text-center transition-all cursor-pointer shadow-lg active:scale-95 group">
            <div className="w-9 h-9 rounded-xl bg-slate-800 text-slate-300 flex items-center justify-center mb-1 group-hover:scale-110 transition-transform"><Settings className="w-5 h-5" /></div>
            <span className="text-xs font-black uppercase text-white tracking-wide">Настройки</span><span className="text-[10px] text-slate-400">Коды & Сброс</span>
          </button>
        </div>
      </div>

      {/* Stats footer */}
      <div className="relative z-10 max-w-5xl w-full mx-auto flex flex-wrap items-center justify-between text-xs text-slate-400 bg-slate-900/60 border border-slate-800/80 px-4 py-2.5 rounded-2xl">
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-1 text-slate-300"><Trophy className="w-3.5 h-3.5 text-amber-400" /> Победы: <b>{save.wins}</b> / {save.matchesPlayed} ({winRate}%)</span>
          <span className="flex items-center gap-1 text-slate-300"><Zap className="w-3.5 h-3.5 text-cyan-400" /> Серия: <b>{save.currentWinStreak}</b> (Рекорд: {save.highestWinStreak})</span>
          <span className="flex items-center gap-1 text-slate-300"><Crown className="w-3.5 h-3.5 text-orange-400" /> Боссы: <b>{save.unlockedBosses.length}</b></span>
        </div>
        <div className="text-[11px] text-slate-500">Разблокировано: <b className="text-slate-300">{save.unlockedCharacters.length}</b> / {visibleCount}</div>
      </div>

      {/* Mode modal */}
      {showModeModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4" onClick={() => setShowModeModal(false)}>
          <div className="bg-slate-900 border border-slate-700 rounded-3xl p-5 sm:p-6 w-full max-w-md flex flex-col gap-3 shadow-2xl max-h-[86vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between sticky top-0 -mx-1 bg-slate-900/95 backdrop-blur px-1 py-1 z-10">
              <h2 className="text-lg font-black uppercase text-white tracking-wide">Выберите Режим Игры</h2>
              <button onClick={() => setShowModeModal(false)} className="w-8 h-8 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-black text-sm cursor-pointer">✕</button>
            </div>
            {/* standard */}
            <div onClick={() => { soundManager.playClick(); onChangeMode('standard'); setShowModeModal(false); }} className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-start gap-3 ${currentMode === 'standard' ? 'bg-sky-950/60 border-sky-400 ring-2 ring-sky-500/20' : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'}`}>
              <div className="w-10 h-10 rounded-xl bg-sky-500/20 text-sky-400 flex items-center justify-center shrink-0"><Swords className="w-5 h-5" /></div>
              <div><div className="text-sm font-black uppercase text-white">Стандартная Дуэль (7 HP)</div><p className="text-xs text-slate-300 mt-0.5">Классический бой до 7 HP. Сферы щита, шипов (+1 урон), ускорения и лечения!</p></div>
            </div>
            {/* final health */}
            <div onClick={() => { soundManager.playClick(); onChangeMode('final_health'); setShowModeModal(false); }} className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-start gap-3 ${currentMode === 'final_health' ? 'bg-rose-950/60 border-rose-400 ring-2 ring-rose-500/20' : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'}`}>
              <div className="w-10 h-10 rounded-xl bg-rose-500/20 text-rose-400 flex items-center justify-center shrink-0"><Flame className="w-5 h-5" /></div>
              <div><div className="text-sm font-black uppercase text-rose-300">Final Health (1 HP)</div><p className="text-xs text-slate-300 mt-0.5">Внезапная смерть! У обоих бойцов ровно 1 HP. Одно точное попадание решает всё!</p></div>
            </div>
            {/* boss raid */}
            <div onClick={() => { soundManager.playClick(); onChangeMode('boss_raid'); setShowModeModal(false); }} className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-start gap-3 ${currentMode === 'boss_raid' ? 'bg-amber-950/60 border-amber-400 ring-2 ring-amber-500/20' : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'}`}>
              <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0"><ShieldAlert className="w-5 h-5" /></div>
              <div><div className="text-sm font-black uppercase text-amber-300">Boss Raid</div><p className="text-xs text-slate-300 mt-0.5">Победи босса и получи его в свой ростер! HP босса: ×1 в соло, ×1.9 в дуо. Доступен в соло и локальном дуо.</p></div>
            </div>
            {/* two player */}
            <div onClick={() => { soundManager.playClick(); onChangeMode('two_player'); setShowModeModal(false); }} className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-start gap-3 relative overflow-hidden ${currentMode === 'two_player' ? 'bg-emerald-950/60 border-emerald-400 ring-2 ring-emerald-500/20' : 'bg-slate-950/60 border-slate-800 hover:border-emerald-600/50'}`}>
              <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0 animate-pulse"><Users className="w-5 h-5" /></div>
              <div className="relative z-10"><div className="text-sm font-black uppercase text-emerald-300">Мультиплеер: Друг Рядом!</div><p className="text-xs text-slate-300 mt-0.5">Играйте вдвоём на одном устройстве! Твои кнопки снизу — кнопки друга сверху (экран перевёрнут к нему). На ПК: WASD+Пробел против IJKL+Enter.</p></div>
              <div className="absolute inset-y-0 left-1/2 w-px bg-gradient-to-b from-transparent via-emerald-500/30 to-transparent pointer-events-none" />
            </div>
            {/* endless */}
            <div className={`p-4 rounded-2xl border transition-all flex flex-col gap-2 relative overflow-hidden ${currentMode === 'endless' ? 'bg-amber-950/60 border-amber-400 ring-2 ring-amber-500/20' : 'bg-slate-950/60 border-slate-800 hover:border-amber-600/50'}`}>
              <div className="flex items-start gap-3 cursor-pointer" onClick={() => { soundManager.playClick(); onChangeMode('endless'); setShowModeModal(false); }}>
                <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0"><Flame className="w-5 h-5" /></div>
                <div className="relative z-10 flex-1"><div className="text-sm font-black uppercase text-amber-300">Endless: Бесконечная Битва</div><p className="text-xs text-slate-300 mt-0.5">Волны противников! Каждый убитый — очко и монеты. Сколько волн выдержишь?</p></div>
              </div>
              <div className="flex gap-1.5 pl-13" onClick={e => e.stopPropagation()}>
                {([{ id: 'standard', name: 'Стандарт (+2 HP/волна)', icon: '⚔️' }, { id: 'duo', name: 'Дуо (+1 HP + тени)', icon: '👥' }, { id: 'last', name: 'Ласт (×1.5 монеты)', icon: '💀' }] as const).map(sub => (
                  <button key={sub.id} onClick={() => { soundManager.playClick(); onChangeEndlessSubmode?.(sub.id); onChangeMode('endless'); setShowModeModal(false); }}
                    className={`flex-1 py-1.5 px-2 rounded-xl text-[10px] font-bold border transition-all cursor-pointer flex items-center justify-center gap-1 ${endlessSubmode === sub.id && currentMode === 'endless' ? 'bg-amber-500 text-slate-950 border-amber-300' : 'bg-slate-900/70 text-slate-300 border-slate-700 hover:border-amber-500/50'}`}>
                    <span>{sub.icon}</span><span>{sub.name}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      <RaidBossPicker />
    </div>
  );
}
