import { Character, FighterEntity } from '../types/game';

export const drawCharacterAvatar = (
  ctx: CanvasRenderingContext2D,
  char: Character,
  x: number,
  y: number,
  radius: number,
  angle: number = 0,
  weaponAngle: number = 0,
  fighterState?: Partial<FighterEntity>
) => {
  ctx.save();
  ctx.translate(x, y);

  const isTransformed = fighterState?.isTransformed || false;
  const currentRadius = isTransformed ? radius * 1.5 : radius;

  // 1. Draw Under-glow / Shadows
  const glow = ctx.createRadialGradient(0, 0, currentRadius * 0.4, 0, 0, currentRadius * 1.8);
  glow.addColorStop(0, char.glowColor + 'aa');
  glow.addColorStop(1, 'transparent');
  ctx.fillStyle = glow;
  ctx.beginPath();
  ctx.arc(0, 0, currentRadius * 1.8, 0, Math.PI * 2);
  ctx.fill();

  // SECRET GLITCH: RGB-разрывы и повреждённые прямоугольные кадры вокруг тела.
  if (char.id === 'glitch_secret') {
    ctx.save();
    ctx.globalCompositeOperation = 'screen';
    for (let i = 0; i < 9; i++) {
      const a = weaponAngle * (1.2 + (i % 3) * 0.15) + i * 2.399;
      const d = currentRadius * (1.05 + (i % 4) * 0.22);
      ctx.fillStyle = i % 2 === 0 ? '#00f5ff99' : '#ff147899';
      ctx.fillRect(Math.cos(a) * d - 7, Math.sin(a) * d - 2, 14 + (i % 3) * 5, 4);
    }
    ctx.restore();
  }

  // SECRET LIGHTING: ветвящиеся электрические разряды во время движения.
  if (char.id === 'lighting_secret') {
    ctx.save();
    ctx.strokeStyle = '#67e8f9';
    ctx.shadowColor = '#67e8f9';
    ctx.shadowBlur = 14;
    ctx.lineWidth = 2.2;
    for (let bolt = 0; bolt < 7; bolt++) {
      const a = weaponAngle * 2.4 + (bolt * Math.PI * 2) / 7;
      ctx.beginPath();
      ctx.moveTo(Math.cos(a) * currentRadius * 0.65, Math.sin(a) * currentRadius * 0.65);
      for (let j = 1; j <= 4; j++) {
        const d = currentRadius * (0.65 + j * 0.38);
        const jitter = Math.sin(weaponAngle * 9 + bolt * 4 + j * 2.1) * currentRadius * 0.18;
        ctx.lineTo(Math.cos(a) * d + Math.sin(a) * jitter, Math.sin(a) * d - Math.cos(a) * jitter);
      }
      ctx.stroke();
    }
    ctx.restore();
  }

  // ULTRAKILL: после пробуждения появляются радужные крылья и переливающаяся аура.
  if (char.id === 'ultrakill') {
    const awakened = char.weaponType === 'sword';
    if (awakened) {
      const hue = (weaponAngle * 90) % 360;
      ctx.save();
      ctx.rotate(angle);
      ctx.strokeStyle = `hsl(${hue}, 100%, 68%)`;
      ctx.shadowColor = `hsl(${(hue + 120) % 360}, 100%, 62%)`;
      ctx.shadowBlur = 20;
      ctx.lineWidth = 3;
      for (const side of [-1, 1]) {
        for (let f = 0; f < 4; f++) {
          ctx.beginPath();
          ctx.moveTo(-currentRadius * 0.2, side * currentRadius * 0.3);
          ctx.quadraticCurveTo(
            -currentRadius * (1.5 + f * 0.35), side * currentRadius * (0.6 + f * 0.3),
            -currentRadius * (0.8 + f * 0.45), side * currentRadius * (1.7 + f * 0.28)
          );
          ctx.stroke();
        }
      }
      ctx.restore();
      // Переливающееся кольцо решимости.
      ctx.save();
      ctx.strokeStyle = `hsla(${(hue + 200) % 360}, 100%, 70%, 0.75)`;
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.arc(0, 0, currentRadius * 1.35 + Math.sin(weaponAngle * 4) * 3, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
    }
  }

  // У Артёма Сахарок живёт рядом как настоящий питомец и бежит следом.
  if (char.id === 'artem_sugarok' && !fighterState?.sugarokForm) {
    const petA = angle + Math.PI + Math.sin(weaponAngle * 2.2) * 0.38;
    const petD = currentRadius * 2.15;
    const px = Math.cos(petA) * petD;
    const py = Math.sin(petA) * petD;
    const pr = currentRadius * 0.42;
    ctx.save();
    ctx.translate(px, py);
    ctx.rotate(angle);
    ctx.fillStyle = '#20242d';
    ctx.shadowColor = '#fbbf24';
    ctx.shadowBlur = 10;
    ctx.beginPath();
    ctx.ellipse(0, 0, pr * 1.25, pr * 0.86, 0, 0, Math.PI * 2);
    ctx.fill();
    // Уши
    ctx.beginPath();
    ctx.moveTo(pr * 0.6, -pr * 0.62);
    ctx.lineTo(pr * 0.95, -pr * 1.1);
    ctx.lineTo(pr * 1.06, -pr * 0.42);
    ctx.closePath();
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(pr * 0.6, pr * 0.62);
    ctx.lineTo(pr * 0.95, pr * 1.1);
    ctx.lineTo(pr * 1.06, pr * 0.42);
    ctx.closePath();
    ctx.fill();
    // Глаза Сахарка
    ctx.fillStyle = '#fbbf24';
    ctx.beginPath();
    ctx.arc(pr * 0.72, -pr * 0.27, pr * 0.13, 0, Math.PI * 2);
    ctx.arc(pr * 0.72, pr * 0.27, pr * 0.13, 0, Math.PI * 2);
    ctx.fill();
    // Хвост
    ctx.strokeStyle = '#20242d';
    ctx.lineWidth = pr * 0.3;
    ctx.beginPath();
    ctx.moveTo(-pr, 0);
    ctx.quadraticCurveTo(-pr * 1.8, -pr * 1.1, -pr * 1.3, -pr * 1.75);
    ctx.stroke();
    ctx.restore();
  }

  // 2. Specialized model rendering for Boss Dave (Giant gloves behind him!)
  if (char.modelType === 'boss_dave') {
    // Draw 2 massive floating white boss gloves behind Dave
    const gloveDist = currentRadius * 1.35;
    const gloveRadius = currentRadius * 0.7;
    
    // Left Glove
    ctx.save();
    ctx.translate(-gloveDist, -currentRadius * 0.3);
    ctx.rotate(angle - 0.2);
    ctx.fillStyle = '#f8fafc';
    ctx.shadowColor = '#ffffff';
    ctx.shadowBlur = 15;
    ctx.beginPath();
    ctx.ellipse(0, 0, gloveRadius * 1.1, gloveRadius * 0.8, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.lineWidth = 3;
    ctx.strokeStyle = '#94a3b8';
    ctx.stroke();
    // Thumb / fingers
    ctx.fillStyle = '#e2e8f0';
    ctx.beginPath();
    ctx.arc(-gloveRadius * 0.5, -gloveRadius * 0.3, gloveRadius * 0.35, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    // Right Glove
    ctx.save();
    ctx.translate(gloveDist, -currentRadius * 0.3);
    ctx.rotate(angle + 0.2);
    ctx.fillStyle = '#f8fafc';
    ctx.shadowColor = '#ffffff';
    ctx.shadowBlur = 15;
    ctx.beginPath();
    ctx.ellipse(0, 0, gloveRadius * 1.1, gloveRadius * 0.8, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.lineWidth = 3;
    ctx.strokeStyle = '#94a3b8';
    ctx.stroke();
    ctx.fillStyle = '#e2e8f0';
    ctx.beginPath();
    ctx.arc(gloveRadius * 0.5, -gloveRadius * 0.3, gloveRadius * 0.35, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  // Figure из DOORS: длинные мясистые конечности и рёбра босса.
  if (char.id === 'figure_doors') {
    ctx.save();
    ctx.rotate(angle);
    ctx.strokeStyle = '#7f1d1d';
    ctx.shadowColor = '#ef4444';
    ctx.shadowBlur = 9;
    ctx.lineCap = 'round';
    ctx.lineWidth = currentRadius * 0.34;
    const limbWave = Math.sin(weaponAngle * 2.5) * currentRadius * 0.28;
    for (const side of [-1, 1]) {
      ctx.beginPath();
      ctx.moveTo(0, side * currentRadius * 0.45);
      ctx.quadraticCurveTo(-currentRadius * 0.5 + limbWave, side * currentRadius * 1.25, currentRadius * 0.35, side * currentRadius * 1.9);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(-currentRadius * 0.55, side * currentRadius * 0.35);
      ctx.quadraticCurveTo(-currentRadius * 1.1, side * currentRadius * 0.85, -currentRadius * 0.85 - limbWave, side * currentRadius * 1.5);
      ctx.stroke();
    }
    // Светящиеся рёбра.
    ctx.strokeStyle = '#fca5a5aa';
    ctx.lineWidth = 2;
    for (let rib = -2; rib <= 2; rib++) {
      ctx.beginPath();
      ctx.arc(-currentRadius * 0.15 + rib * currentRadius * 0.12, 0, currentRadius * (0.55 - Math.abs(rib) * 0.05), -1.1, 1.1);
      ctx.stroke();
    }
    ctx.restore();
  }

  // 3. Specialized Model: Segmented Leviathans (super long serpentine bodies)
  if (char.modelType === 'segmented_leviathan') {
    // Generate a LONG serpentine tail based on segmentLength (Gargantua = 14, Leviathan = 8)
    const segCount = char.segmentLength || 6;
    const perp = angle + Math.PI / 2; // perpendicular for the swim wave
    // weaponAngle drives the sinusoidal swimming motion
    const segments = fighterState?.segments || Array.from({ length: segCount }).map((_, i) => {
      const t = i + 1;
      // distance from head grows with each segment
      const dist = currentRadius * (0.75 * t);
      // swim wave amplitude grows toward the tail
      const wave = Math.sin(weaponAngle * 2 - t * 0.6) * currentRadius * 0.35 * (1 + t * 0.05);
      // taper the radius toward the tail tip
      const taper = Math.max(0.18, 0.95 - t * (0.8 / segCount));
      return {
        x: -Math.cos(angle) * dist + Math.cos(perp) * wave,
        y: -Math.sin(angle) * dist + Math.sin(perp) * wave,
        radius: currentRadius * taper
      };
    });

    segments.forEach((seg, idx) => {
      ctx.save();
      ctx.translate(seg.x, seg.y);
      ctx.fillStyle = idx % 2 === 0 ? char.avatarColor : (char.secondaryColor || '#000000');
      ctx.shadowColor = char.glowColor;
      ctx.shadowBlur = 8;
      ctx.beginPath();
      ctx.arc(0, 0, seg.radius, 0, Math.PI * 2);
      ctx.fill();
      ctx.lineWidth = 2;
      ctx.strokeStyle = char.glowColor;
      ctx.stroke();

      // Bioluminescent dots
      ctx.fillStyle = char.glowColor;
      ctx.beginPath();
      ctx.arc(0, 0, seg.radius * 0.3, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    });

    // Leviathan Mandibles / Horns
    ctx.save();
    ctx.rotate(angle);
    ctx.fillStyle = char.secondaryColor || '#ef4444';
    ctx.beginPath();
    ctx.moveTo(currentRadius * 0.8, -currentRadius * 0.6);
    ctx.lineTo(currentRadius * 1.6, -currentRadius * 0.9);
    ctx.lineTo(currentRadius * 1.2, -currentRadius * 0.2);
    ctx.closePath();
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(currentRadius * 0.8, currentRadius * 0.6);
    ctx.lineTo(currentRadius * 1.6, currentRadius * 0.9);
    ctx.lineTo(currentRadius * 1.2, currentRadius * 0.2);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  }

  // Volcanic Ash boss: чёрная глыба с оранжево-латунными рунными узорами и магмой.
  if (char.modelType === 'volcanic_ash') {
    ctx.save();
    const now = performance.now() / 1000;
    // Рваная чёрная глыба-пепел.
    ctx.fillStyle = '#08070c';
    ctx.shadowColor = '#ff7b1c';
    ctx.shadowBlur = 24;
    ctx.beginPath();
    const edges = 14;
    for (let i = 0; i < edges; i++) {
      const a = (i / edges) * Math.PI * 2;
      const rr = currentRadius * (0.92 + Math.sin(now * 2 + i * 7.3) * 0.08);
      const ex = Math.cos(a) * rr;
      const ey = Math.sin(a) * rr;
      if (i === 0) ctx.moveTo(ex, ey);
      else ctx.lineTo(ex, ey);
    }
    ctx.closePath();
    ctx.fill();
    ctx.strokeStyle = '#ff9d3d44';
    ctx.lineWidth = 2;
    ctx.stroke();

    // Тлеющие зоны лавы и потоки магмы.
    for (let i = 0; i < 9; i++) {
      const la = (i / 9) * Math.PI * 2 + Math.sin(now * 0.6 + i) * 0.3;
      const lr = currentRadius * (0.2 + (i % 5) * 0.08);
      const lx = Math.cos(la) * lr;
      const ly = Math.sin(la) * lr;
      const r = currentRadius * (0.06 + Math.sin(now * 3 + i * 2.1) * 0.02);
      const g = ctx.createRadialGradient(lx, ly, 0, lx, ly, r * 4);
      g.addColorStop(0, '#ffb300');
      g.addColorStop(0.4, '#ff7b1c');
      g.addColorStop(1, 'rgba(255,123,28,0)');
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(lx, ly, r * 4, 0, Math.PI * 2);
      ctx.fill();
    }

    // Плавно пульсирующие руны оранжевого неона по контуру.
    for (let i = 0; i < 12; i++) {
      const a = now * 0.8 + (i / 12) * Math.PI * 2;
      const rr = currentRadius * 1.0;
      const rx = Math.cos(a) * rr;
      const ry = Math.sin(a) * rr;
      ctx.save();
      ctx.translate(rx, ry);
      ctx.rotate(a);
      ctx.globalAlpha = 0.5 + Math.sin(now * 4 + i * 1.7) * 0.3;
      ctx.strokeStyle = '#ffd166';
      ctx.shadowColor = '#ff7b1c';
      ctx.shadowBlur = 10;
      ctx.lineWidth = 2;
      for (let k = 0; k < 3; k++) {
        ctx.moveTo(-6, 0);
        ctx.lineTo(6, 0);
        ctx.translate(8, 0);
      }
      ctx.stroke();
      ctx.restore();
    }

    // Глаза-угольки.
    ctx.fillStyle = '#ffcf6b';
    ctx.shadowColor = '#ff7b1c';
    ctx.shadowBlur = 22;
    ctx.beginPath();
    ctx.ellipse(currentRadius * 0.34, -currentRadius * 0.24, currentRadius * 0.12, currentRadius * 0.05, 0, 0, Math.PI * 2);
    ctx.ellipse(currentRadius * 0.34, currentRadius * 0.24, currentRadius * 0.12, currentRadius * 0.05, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  // 4. Ender Dragon: полноценная крылатая модель вместо кружка.
  else if (char.modelType === 'dragon') {
    ctx.save();
    ctx.rotate(angle);
    const flap = Math.sin(weaponAngle * 3.2) * currentRadius * 0.28;

    // Длинный хвост позади.
    ctx.strokeStyle = '#100719';
    ctx.shadowColor = char.glowColor;
    ctx.shadowBlur = 10;
    ctx.lineCap = 'round';
    ctx.lineWidth = currentRadius * 0.48;
    ctx.beginPath();
    ctx.moveTo(-currentRadius * 0.7, 0);
    ctx.bezierCurveTo(-currentRadius * 1.7, -currentRadius * 0.4, -currentRadius * 2.25, currentRadius * 0.55, -currentRadius * 3.0, 0);
    ctx.stroke();

    // Огромные перепончатые крылья.
    const drawWing = (side: number) => {
      ctx.save();
      ctx.scale(1, side);
      const wing = ctx.createLinearGradient(0, 0, 0, currentRadius * 2.2);
      wing.addColorStop(0, '#241331');
      wing.addColorStop(1, '#6b21a8');
      ctx.fillStyle = wing;
      ctx.strokeStyle = '#d946ef';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(-currentRadius * 0.25, currentRadius * 0.25);
      ctx.lineTo(-currentRadius * 0.75, currentRadius * 1.75 + flap);
      ctx.lineTo(currentRadius * 0.2, currentRadius * 1.25 + flap * 0.6);
      ctx.lineTo(currentRadius * 0.45, currentRadius * 2.1 + flap);
      ctx.lineTo(currentRadius * 0.9, currentRadius * 0.55);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      // Кости крыла.
      ctx.strokeStyle = '#a855f7aa';
      ctx.beginPath();
      ctx.moveTo(-currentRadius * 0.2, currentRadius * 0.3);
      ctx.lineTo(-currentRadius * 0.75, currentRadius * 1.75 + flap);
      ctx.moveTo(-currentRadius * 0.2, currentRadius * 0.3);
      ctx.lineTo(currentRadius * 0.45, currentRadius * 2.1 + flap);
      ctx.stroke();
      ctx.restore();
    };
    drawWing(1);
    drawWing(-1);

    // Туловище и шея.
    const body = ctx.createLinearGradient(-currentRadius, 0, currentRadius, 0);
    body.addColorStop(0, '#090510');
    body.addColorStop(0.55, '#21112d');
    body.addColorStop(1, '#3b1458');
    ctx.fillStyle = body;
    ctx.strokeStyle = '#a855f7';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.ellipse(-currentRadius * 0.1, 0, currentRadius * 1.2, currentRadius * 0.62, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = '#180b22';
    ctx.beginPath();
    ctx.ellipse(currentRadius * 0.92, 0, currentRadius * 0.72, currentRadius * 0.42, 0, 0, Math.PI * 2);
    ctx.fill();

    // Голова, морда и рога.
    ctx.fillStyle = '#12071b';
    ctx.beginPath();
    ctx.ellipse(currentRadius * 1.48, 0, currentRadius * 0.72, currentRadius * 0.55, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = '#21112d';
    ctx.beginPath();
    ctx.roundRect(currentRadius * 1.55, -currentRadius * 0.34, currentRadius * 0.85, currentRadius * 0.68, currentRadius * 0.15);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = '#a855f7';
    for (const side of [-1, 1]) {
      ctx.beginPath();
      ctx.moveTo(currentRadius * 1.25, side * currentRadius * 0.38);
      ctx.lineTo(currentRadius * 0.75, side * currentRadius * 0.85);
      ctx.lineTo(currentRadius * 1.58, side * currentRadius * 0.52);
      ctx.closePath();
      ctx.fill();
    }
    // Фиолетовые глаза и ноздри.
    ctx.fillStyle = '#f0abfc';
    ctx.shadowColor = '#d946ef';
    ctx.shadowBlur = 14;
    ctx.beginPath();
    ctx.arc(currentRadius * 1.72, -currentRadius * 0.31, currentRadius * 0.11, 0, Math.PI * 2);
    ctx.arc(currentRadius * 1.72, currentRadius * 0.31, currentRadius * 0.11, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#d946ef';
    ctx.beginPath();
    ctx.arc(currentRadius * 2.2, -currentRadius * 0.18, currentRadius * 0.06, 0, Math.PI * 2);
    ctx.arc(currentRadius * 2.2, currentRadius * 0.18, currentRadius * 0.06, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  // 5. Specialized Model: Bus / Vehicles
  else if (char.modelType === 'bus') {
    ctx.save();
    ctx.rotate(angle);
    ctx.fillStyle = char.avatarColor;
    ctx.shadowColor = char.glowColor;
    ctx.shadowBlur = 10;
    // Rounded bus rectangle body
    const bw = currentRadius * 2.2;
    const bh = currentRadius * 1.4;
    ctx.beginPath();
    ctx.roundRect(-bw / 2, -bh / 2, bw, bh, 8);
    ctx.fill();
    ctx.lineWidth = 3;
    ctx.strokeStyle = char.glowColor;
    ctx.stroke();

    // Windows
    ctx.fillStyle = '#38bdf8';
    for (let i = 0; i < 3; i++) {
      ctx.fillRect(-bw * 0.35 + i * (bw * 0.28), -bh * 0.38, bw * 0.2, bh * 0.25);
    }
    // Headlights
    ctx.fillStyle = '#fef08a';
    ctx.beginPath();
    ctx.arc(bw / 2 - 2, -bh * 0.25, 4, 0, Math.PI * 2);
    ctx.arc(bw / 2 - 2, bh * 0.25, 4, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  } else {
    // 5. Standard circular / core body
    ctx.save();
    ctx.rotate(angle);

    // Main circle body gradient
    const grad = ctx.createRadialGradient(-currentRadius * 0.3, -currentRadius * 0.3, currentRadius * 0.1, 0, 0, currentRadius);
    grad.addColorStop(0, '#ffffff');
    grad.addColorStop(0.3, char.avatarColor);
    grad.addColorStop(1, char.secondaryColor || '#000000');

    ctx.fillStyle = grad;
    ctx.shadowColor = char.glowColor;
    ctx.shadowBlur = isTransformed ? 25 : 12;
    ctx.beginPath();
    ctx.arc(0, 0, currentRadius, 0, Math.PI * 2);
    ctx.fill();

    // Inner border ring
    ctx.lineWidth = isTransformed ? 5 : 3;
    ctx.strokeStyle = char.glowColor;
    ctx.stroke();

    // Character Face / Core details
    drawFaceDetails(ctx, char, currentRadius, isTransformed);

    ctx.restore();
  }

  // 6. Draw Orbiting / Attached Weapons & Spikes. У дракона оружие уже часть модели.
  if (char.modelType !== 'dragon' && char.modelType !== 'volcanic_ash') {
    drawWeaponsAndAttachments(ctx, char, currentRadius, weaponAngle, fighterState);
  }

  // 7. Active Buff Effects (Shield Bubble / Spikes Aura)
  if (fighterState?.hasShield) {
    ctx.save();
    ctx.strokeStyle = '#38bdf8';
    ctx.shadowColor = '#38bdf8';
    ctx.shadowBlur = 18;
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.arc(0, 0, currentRadius * 1.45, 0, Math.PI * 2);
    ctx.stroke();
    // Inner shimmer
    ctx.fillStyle = '#38bdf822';
    ctx.fill();
    ctx.restore();
  }

  if (fighterState?.hasSpikesBuff) {
    ctx.save();
    ctx.strokeStyle = '#ef4444';
    ctx.lineWidth = 3;
    const numBuffSpikes = 8;
    for (let s = 0; s < numBuffSpikes; s++) {
      const a = (s * Math.PI * 2) / numBuffSpikes + weaponAngle * 1.5;
      const sx = Math.cos(a) * (currentRadius * 1.35);
      const sy = Math.sin(a) * (currentRadius * 1.35);
      ctx.fillStyle = '#ef4444';
      ctx.beginPath();
      ctx.arc(sx, sy, 4, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();
  }

  ctx.restore();
};

const drawFaceDetails = (
  ctx: CanvasRenderingContext2D,
  char: Character,
  radius: number,
  isTransformed: boolean
) => {
  // Custom faces based on Character ID or Theme
  if (char.id === 'sans') {
    // Sans: Left eye glowing blue/cyan, right eye dark, smile
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(radius * 0.35, -radius * 0.25, radius * 0.22, 0, Math.PI * 2);
    ctx.arc(radius * 0.35, radius * 0.25, radius * 0.22, 0, Math.PI * 2);
    ctx.fill();
    // Left glowing cyan iris
    ctx.fillStyle = '#00ffff';
    ctx.shadowColor = '#00ffff';
    ctx.shadowBlur = 10;
    ctx.beginPath();
    ctx.arc(radius * 0.35, -radius * 0.25, radius * 0.12, 0, Math.PI * 2);
    ctx.fill();
    // Smile
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(radius * 0.45, 0, radius * 0.2, -Math.PI / 2, Math.PI / 2);
    ctx.stroke();
  } else if (char.id === 'gojo') {
    // Gojo: Blindfold or bright six eyes
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(radius * 0.1, -radius * 0.6, radius * 0.35, radius * 1.2);
    // Glowing cyan slit
    ctx.fillStyle = '#60a5fa';
    ctx.shadowColor = '#60a5fa';
    ctx.shadowBlur = 12;
    ctx.fillRect(radius * 0.2, -radius * 0.4, radius * 0.15, radius * 0.8);
  } else if (char.id === 'steve') {
    // Steve: Pixelated blue eyes + beard
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(radius * 0.25, -radius * 0.4, radius * 0.25, radius * 0.25);
    ctx.fillRect(radius * 0.25, radius * 0.15, radius * 0.25, radius * 0.25);
    ctx.fillStyle = '#2563eb';
    ctx.fillRect(radius * 0.35, -radius * 0.35, radius * 0.15, radius * 0.15);
    ctx.fillRect(radius * 0.35, radius * 0.2, radius * 0.15, radius * 0.15);
  } else if (char.id === 'amogus_sus') {
    // Amogus: Light blue horizontal visor
    ctx.fillStyle = '#38bdf8';
    ctx.shadowColor = '#38bdf8';
    ctx.shadowBlur = 8;
    ctx.beginPath();
    ctx.roundRect(radius * 0.1, -radius * 0.45, radius * 0.55, radius * 0.9, 6);
    ctx.fill();
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 2;
    ctx.stroke();
  } else if (char.id === 'the_boiled_one' || char.id === 'the_locust' || char.id === 'figure_doors') {
    // Analog horror horrifying mouth/eyes
    ctx.fillStyle = '#000000';
    ctx.beginPath();
    ctx.ellipse(radius * 0.3, 0, radius * 0.4, radius * 0.6, 0, 0, Math.PI * 2);
    ctx.fill();
    // Needle teeth
    ctx.fillStyle = '#ffffff';
    for (let t = -4; t <= 4; t++) {
      ctx.beginPath();
      ctx.moveTo(radius * 0.3, t * (radius * 0.1));
      ctx.lineTo(radius * 0.55, t * (radius * 0.1) + 2);
      ctx.lineTo(radius * 0.3, t * (radius * 0.1) + 4);
      ctx.fill();
    }
  } else if (char.id === 'overkill_glove') {
    // Overkill: Fiery cracks and blazing center
    ctx.fillStyle = '#ffcc00';
    ctx.shadowColor = '#ff3300';
    ctx.shadowBlur = 15;
    ctx.beginPath();
    ctx.arc(0, 0, radius * 0.5, 0, Math.PI * 2);
    ctx.fill();
    // Fire flames
    ctx.fillStyle = '#ff2200';
    ctx.beginPath();
    ctx.arc(radius * 0.2, -radius * 0.2, radius * 0.25, 0, Math.PI * 2);
    ctx.arc(radius * 0.2, radius * 0.2, radius * 0.25, 0, Math.PI * 2);
    ctx.fill();
  } else if (char.id === 'robot_user' && isTransformed) {
    // Giant Mecha Robot visor
    ctx.fillStyle = '#ef4444';
    ctx.shadowColor = '#ef4444';
    ctx.shadowBlur = 15;
    ctx.fillRect(radius * 0.2, -radius * 0.5, radius * 0.3, radius * 1.0);
  } else if (char.id === 'grumble') {
    // Grumble (DOORS): огромная пасть и светящиеся оранжевые глаза-sentry
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(radius * 0.3, -radius * 0.32, radius * 0.17, 0, Math.PI * 2);
    ctx.arc(radius * 0.3, radius * 0.32, radius * 0.17, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#f97316';
    ctx.shadowColor = '#f97316';
    ctx.shadowBlur = 14;
    ctx.beginPath();
    ctx.arc(radius * 0.38, -radius * 0.32, radius * 0.09, 0, Math.PI * 2);
    ctx.arc(radius * 0.38, radius * 0.32, radius * 0.09, 0, Math.PI * 2);
    ctx.fill();
    // Пасть с зубами
    ctx.strokeStyle = '#fed7aa';
    ctx.lineWidth = radius * 0.07;
    ctx.beginPath();
    ctx.arc(radius * 0.52, 0, radius * 0.26, -Math.PI * 0.45, Math.PI * 0.45);
    ctx.stroke();
  } else if (char.id === 'mathematichka') {
    // Математичка: очки на носу + строгий взгляд
    ctx.strokeStyle = '#f5f3ff';
    ctx.lineWidth = 2.5;
    // оправа очков
    ctx.beginPath();
    ctx.arc(radius * 0.32, -radius * 0.28, radius * 0.16, 0, Math.PI * 2);
    ctx.arc(radius * 0.32, radius * 0.28, radius * 0.16, 0, Math.PI * 2);
    ctx.moveTo(radius * 0.46, 0);
    ctx.lineTo(radius * 0.46, 0.001);
    ctx.stroke();
    // строгие глаза
    ctx.fillStyle = '#c084fc';
    ctx.beginPath();
    ctx.arc(radius * 0.34, -radius * 0.28, radius * 0.07, 0, Math.PI * 2);
    ctx.arc(radius * 0.34, radius * 0.28, radius * 0.07, 0, Math.PI * 2);
    ctx.fill();
    // указка-линейка во лбу
    ctx.fillStyle = '#fbbf24';
    ctx.save();
    ctx.rotate(-0.5);
    ctx.fillRect(-radius * 0.5, -radius * 0.72, radius * 1.0, radius * 0.09);
    ctx.restore();
  } else if (char.name === 'SUGAROK') {
    // Вторая форма: сам Сахарок с кошачьими глазами, ушами и клыками.
    ctx.fillStyle = '#20242d';
    ctx.beginPath();
    ctx.moveTo(-radius * 0.15, -radius * 0.55);
    ctx.lineTo(radius * 0.15, -radius * 1.05);
    ctx.lineTo(radius * 0.35, -radius * 0.48);
    ctx.closePath();
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(-radius * 0.15, radius * 0.55);
    ctx.lineTo(radius * 0.15, radius * 1.05);
    ctx.lineTo(radius * 0.35, radius * 0.48);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = '#fbbf24';
    ctx.shadowColor = '#fbbf24';
    ctx.shadowBlur = 12;
    ctx.beginPath();
    ctx.ellipse(radius * 0.38, -radius * 0.28, radius * 0.18, radius * 0.1, 0, 0, Math.PI * 2);
    ctx.ellipse(radius * 0.38, radius * 0.28, radius * 0.18, radius * 0.1, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#111827';
    ctx.fillRect(radius * 0.35, -radius * 0.38, radius * 0.04, radius * 0.2);
    ctx.fillRect(radius * 0.35, radius * 0.18, radius * 0.04, radius * 0.2);
  } else if (char.id === 'artem_sugarok') {
    // При жизни Артём — простой кружок с улыбкой; станет Saharaком через secondLife
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(radius * 0.35, -radius * 0.28, radius * 0.19, 0, Math.PI * 2);
    ctx.arc(radius * 0.35, radius * 0.28, radius * 0.19, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#92400e';
    ctx.beginPath();
    ctx.arc(radius * 0.42, -radius * 0.28, radius * 0.1, 0, Math.PI * 2);
    ctx.arc(radius * 0.42, radius * 0.28, radius * 0.1, 0, Math.PI * 2);
    ctx.fill();
    // Улыбка
    ctx.strokeStyle = '#fcd34d';
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.arc(radius * 0.45, 0, radius * 0.2, -Math.PI / 2, Math.PI / 2);
    ctx.stroke();
  } else if (char.id === 'robot_update') {
    // ROBOT UPDATE EDITION: двойной плазменный визор с яркими шрамами-кодами
    const grad = ctx.createLinearGradient(0, -radius, 0, radius);
    grad.addColorStop(0, '#22d3ee');
    grad.addColorStop(1, '#155e75');
    ctx.fillStyle = grad;
    ctx.shadowColor = '#22d3ee';
    ctx.shadowBlur = 18;
    // Два прямоугольных визора
    ctx.fillRect(radius * 0.18, -radius * 0.5, radius * 0.34, radius * 0.34);
    ctx.fillRect(radius * 0.18, radius * 0.16, radius * 0.34, radius * 0.34);
    // Плазменные точки прицела
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(radius * 0.35, -radius * 0.33, radius * 0.09, 0, Math.PI * 2);
    ctx.arc(radius * 0.35, radius * 0.33, radius * 0.09, 0, Math.PI * 2);
    ctx.fill();
    // светящаяся полоса реактора посередине
    ctx.fillStyle = '#a5f3fc';
    ctx.fillRect(radius * 0.06, -radius * 0.6, radius * 0.07, radius * 1.2);
  } else if (char.id === 'clock_man') {
    // Clock Man: Золотой циферблат с тикающими стрелками времени
    ctx.strokeStyle = '#fbbf24';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(0, 0, radius * 0.65, 0, Math.PI * 2);
    ctx.stroke();
    // Деления часов
    for (let h = 0; h < 12; h++) {
      const ha = (h * Math.PI * 2) / 12;
      ctx.fillStyle = '#fde047';
      ctx.beginPath();
      ctx.arc(Math.cos(ha) * radius * 0.52, Math.sin(ha) * radius * 0.52, 2, 0, Math.PI * 2);
      ctx.fill();
    }
    // Стрелки
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(radius * 0.35, -radius * 0.2);
    ctx.moveTo(0, 0);
    ctx.lineTo(-radius * 0.15, -radius * 0.38);
    ctx.stroke();
  } else if (char.id === 'katana_user') {
    // Katana User: Повязка самурая и острый взгляд с алой аурой
    ctx.fillStyle = '#e11d48';
    ctx.fillRect(-radius * 0.7, -radius * 0.5, radius * 1.4, radius * 0.28);
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(radius * 0.35, -radius * 0.2, radius * 0.15, 0, Math.PI * 2);
    ctx.arc(radius * 0.35, radius * 0.2, radius * 0.15, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#e11d48';
    ctx.beginPath();
    ctx.arc(radius * 0.42, -radius * 0.2, radius * 0.08, 0, Math.PI * 2);
    ctx.arc(radius * 0.42, radius * 0.2, radius * 0.08, 0, Math.PI * 2);
    ctx.fill();
  } else if (char.id === 'glitch_secret') {
    // Раздробленное RGB-лицо секретной ошибки.
    ctx.fillStyle = '#00f5ff';
    ctx.shadowColor = '#00f5ff';
    ctx.shadowBlur = 13;
    ctx.fillRect(radius * 0.08, -radius * 0.55, radius * 0.58, radius * 0.22);
    ctx.fillStyle = '#ff1478';
    ctx.fillRect(radius * 0.18, radius * 0.22, radius * 0.55, radius * 0.24);
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(-radius * 0.15, -radius * 0.08);
    ctx.lineTo(radius * 0.75, radius * 0.04);
    ctx.stroke();
  } else if (char.id === 'lighting_secret') {
    // Ядро живой молнии.
    ctx.fillStyle = '#ffffff';
    ctx.shadowColor = '#67e8f9';
    ctx.shadowBlur = 22;
    ctx.beginPath();
    ctx.moveTo(radius * 0.05, -radius * 0.72);
    ctx.lineTo(radius * 0.62, -radius * 0.12);
    ctx.lineTo(radius * 0.28, -radius * 0.08);
    ctx.lineTo(radius * 0.7, radius * 0.7);
    ctx.lineTo(radius * 0.02, radius * 0.12);
    ctx.lineTo(radius * 0.34, radius * 0.06);
    ctx.closePath();
    ctx.fill();
  } else {
    // General styled arcade eyes (обновлённые: зрачки следят за направлением движения + рот)
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(radius * 0.35, -radius * 0.3, radius * 0.2, 0, Math.PI * 2);
    ctx.arc(radius * 0.35, radius * 0.3, radius * 0.2, 0, Math.PI * 2);
    ctx.fill();

    // Pupils (смотрят вперёд по направлению)
    ctx.fillStyle = char.glowColor;
    ctx.beginPath();
    ctx.arc(radius * 0.42, -radius * 0.3, radius * 0.1, 0, Math.PI * 2);
    ctx.arc(radius * 0.42, radius * 0.3, radius * 0.1, 0, Math.PI * 2);
    ctx.fill();

    // Glossy eye shine
    ctx.fillStyle = '#ffffffaa';
    ctx.beginPath();
    ctx.arc(radius * 0.39, -radius * 0.35, radius * 0.05, 0, Math.PI * 2);
    ctx.arc(radius * 0.39, radius * 0.25, radius * 0.05, 0, Math.PI * 2);
    ctx.fill();

    // Героический рот
    ctx.strokeStyle = '#ffffffcc';
    ctx.lineWidth = Math.max(1.5, radius * 0.05);
    ctx.beginPath();
    if (isTransformed) {
      // опасная ухмылка при трансформации
      ctx.moveTo(radius * 0.4, radius * 0.04);
      ctx.quadraticCurveTo(radius * 0.58, 0, radius * 0.4, -radius * 0.04);
    } else {
      // обычная дуга
      ctx.arc(radius * 0.48, 0, radius * 0.16, -Math.PI / 2.4, Math.PI / 2.4);
    }
    ctx.stroke();
  }
};

const drawWeaponsAndAttachments = (
  ctx: CanvasRenderingContext2D,
  char: Character,
  radius: number,
  weaponAngle: number,
  fighterState?: Partial<FighterEntity>
) => {
  const count = char.weaponCount || 1;
  const reach = (char.weaponReach || 30) + (char.isGiant ? 10 : 0);
  const color = char.weaponColor || '#ffffff';

  // 1. Orbiting Swords Ring (Sword Master / Dual User / Steve)
  if (char.weaponType === 'sword' || char.weaponType === 'swords_ring') {
    for (let i = 0; i < count; i++) {
      const angle = weaponAngle + (i * Math.PI * 2) / count;
      const wx = Math.cos(angle) * (radius + reach * 0.6);
      const wy = Math.sin(angle) * (radius + reach * 0.6);

      ctx.save();
      ctx.translate(wx, wy);
      ctx.rotate(angle + Math.PI / 2);

      // Sword Blade
      ctx.fillStyle = color;
      ctx.shadowColor = char.glowColor;
      ctx.shadowBlur = 8;
      ctx.beginPath();
      ctx.moveTo(0, -reach * 0.5);
      ctx.lineTo(5, reach * 0.3);
      ctx.lineTo(-5, reach * 0.3);
      ctx.closePath();
      ctx.fill();

      // Guard & Hilt
      ctx.fillStyle = '#f59e0b';
      ctx.fillRect(-8, reach * 0.3, 16, 4);
      ctx.fillStyle = '#78350f';
      ctx.fillRect(-3, reach * 0.3 + 4, 6, 8);

      ctx.restore();
    }
  }

  // 2. Overkill Fiery Lava Spikes
  else if (char.weaponType === 'overkill_fist') {
    for (let i = 0; i < 6; i++) {
      const angle = weaponAngle * 1.8 + (i * Math.PI * 2) / 6;
      const wx = Math.cos(angle) * (radius + reach * 0.7);
      const wy = Math.sin(angle) * (radius + reach * 0.7);

      ctx.save();
      ctx.translate(wx, wy);
      ctx.rotate(angle + Math.PI / 2);

      ctx.fillStyle = '#ffdd00';
      ctx.shadowColor = '#ff2200';
      ctx.shadowBlur = 18;
      ctx.beginPath();
      ctx.moveTo(0, -reach * 0.6);
      ctx.lineTo(8, reach * 0.3);
      ctx.lineTo(-8, reach * 0.3);
      ctx.closePath();
      ctx.fill();

      ctx.restore();
    }
  }

  // 3. Kagune Tentacles (1000-7 / Seek / Void User)
  else if (char.weaponType === 'tentacles') {
    for (let i = 0; i < count; i++) {
      const angle = weaponAngle * 0.8 + (i * Math.PI * 2) / count;
      const wave = Math.sin(weaponAngle * 3 + i) * 12;

      ctx.save();
      ctx.strokeStyle = color;
      ctx.shadowColor = char.glowColor;
      ctx.shadowBlur = 12;
      ctx.lineWidth = 6;
      ctx.beginPath();
      ctx.moveTo(Math.cos(angle) * radius, Math.sin(angle) * radius);
      const cpX = Math.cos(angle) * (radius + reach * 0.7) + Math.sin(angle) * wave;
      const cpY = Math.sin(angle) * (radius + reach * 0.7) - Math.cos(angle) * wave;
      const endX = Math.cos(angle) * (radius + reach * 1.2);
      const endY = Math.sin(angle) * (radius + reach * 1.2);
      ctx.quadraticCurveTo(cpX, cpY, endX, endY);
      ctx.stroke();

      // Sharp tip
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(endX, endY, 5, 0, Math.PI * 2);
      ctx.fill();

      ctx.restore();
    }
  }

  // 4. Robot Arm / Mecha Blaster (Robot User)
  else if (char.weaponType === 'robot_arm') {
    const isTrans = fighterState?.isTransformed || false;
    const numArms = isTrans ? 4 : count;

    for (let i = 0; i < numArms; i++) {
      const angle = weaponAngle + (i * Math.PI * 2) / numArms;
      const armLength = radius + (isTrans ? reach * 1.5 : reach * 0.8);
      const wx = Math.cos(angle) * armLength;
      const wy = Math.sin(angle) * armLength;

      ctx.save();
      ctx.translate(wx, wy);
      ctx.rotate(angle);

      // Steel arm segment
      ctx.fillStyle = '#475569';
      ctx.strokeStyle = char.glowColor;
      ctx.lineWidth = 2;
      ctx.strokeRect(-12, -6, 24, 12);
      ctx.fillRect(-12, -6, 24, 12);

      // Energy fist / cannon tip
      ctx.fillStyle = isTrans ? '#ef4444' : '#38bdf8';
      ctx.shadowColor = isTrans ? '#ef4444' : '#38bdf8';
      ctx.shadowBlur = 12;
      ctx.beginPath();
      ctx.arc(10, 0, isTrans ? 10 : 7, 0, Math.PI * 2);
      ctx.fill();

      ctx.restore();
    }
  }

  // 5. Guns / Sniper / RPG Barrels
  else if (char.weaponType === 'guns' || char.weaponType === 'sniper' || char.weaponType === 'rpg' || char.weaponType === 'blaster') {
    for (let i = 0; i < count; i++) {
      const angle = weaponAngle + (i * Math.PI * 2) / count;
      const wx = Math.cos(angle) * (radius + reach * 0.5);
      const wy = Math.sin(angle) * (radius + reach * 0.5);

      ctx.save();
      ctx.translate(wx, wy);
      ctx.rotate(angle);

      ctx.fillStyle = '#334155';
      ctx.fillRect(0, -5, reach * 0.6, 10);
      ctx.fillStyle = color;
      ctx.fillRect(reach * 0.5, -6, 4, 12);

      // Sniper laser aiming line
      if (char.weaponType === 'sniper') {
        ctx.strokeStyle = '#ef444488';
        ctx.lineWidth = 1.5;
        ctx.setLineDash([4, 4]);
        ctx.beginPath();
        ctx.moveTo(reach * 0.6, 0);
        ctx.lineTo(reach * 4.0, 0);
        ctx.stroke();
      }

      ctx.restore();
    }
  }

  // 6. Generic Spikes / Claws / Knives / Magic Orbs
  else {
    for (let i = 0; i < count; i++) {
      const angle = weaponAngle + (i * Math.PI * 2) / count;
      const wx = Math.cos(angle) * (radius + reach * 0.5);
      const wy = Math.sin(angle) * (radius + reach * 0.5);

      ctx.save();
      ctx.translate(wx, wy);
      ctx.rotate(angle + Math.PI / 2);

      ctx.fillStyle = color;
      ctx.shadowColor = char.glowColor;
      ctx.shadowBlur = 8;
      ctx.beginPath();
      ctx.moveTo(0, -12);
      ctx.lineTo(6, 6);
      ctx.lineTo(-6, 6);
      ctx.closePath();
      ctx.fill();

      ctx.restore();
    }
  }
};
