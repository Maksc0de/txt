# Circle Arena Multiplayer

## Architecture

- `src/network/PartyClient.ts`: PeerJS/WebRTC signaling, authenticated-by-invite membership, readiness, input transport, and host snapshots.
- `src/network/protocol.ts`: invitation parsing and expiry. An invitation is valid for exactly 180,000 milliseconds, checked by the host when admitting a new connection.
- `src/network/battleEngine.ts`: host-authoritative combat with separate entities and cooldowns for every participant. Guests cannot submit another player's input.
- `src/components/Arena/NetworkBattle.tsx`: the connected, reachable battle screen. The former unused `BossCoop.tsx` prototype has been removed.
- `src/components/Party/PartyLobby.tsx`: create/join, copy/share/refresh code, character choice, readiness and leaving.
- `src/game/raidRules.ts`: shared boss health rules. Duo uses x1.9; trio uses x2.9. Volcanic Ash has 1,500 / 2,850 / 4,350 HP.

Solo and the pre-existing same-device Versus use the existing arena. Choosing Duo or Trio opens the online party flow on every mode. Online Standard, Final Health, Boss Raid, Endless and Training are cooperative; online Versus is a free-for-all among party members.

Only invitations expire. Expiry and refreshing the token do not destroy the Peer instance, its data channels, or accepted membership. Refreshing invalidates the previous token. Admission is closed during combat and at capacity. Starting requires the full selected party size and everyone's ready state.

The host runs the simulation at 60 fixed steps per second and sends snapshots at up to 20 Hz. Movement input repeats every 40 ms; ability requests have monotonically increasing action IDs. Guests smooth rendered positions. Stale movement expires after 450 ms. Disconnects are detected by channel events and heartbeats; a departing guest's fighter does not transfer to another player. The host leaving dissolves the party. There is no host migration.

Network progression is checkpointed on each device. Run IDs make kill, wave, damage and reward updates idempotent, including after disconnects. Training never grants rewards.

## Deployment

Use HTTPS (or localhost), an up-to-date browser, and internet access on every device. The default PeerJS Cloud service provides signaling without a project API key. Keep the host's game visible: backgrounding its browser pauses the shared simulation. This implementation is not an offline, LAN-discovery, or server-authoritative account service.

Real connectivity depends on the external signaling service, WebRTC support and the devices' networks. PeerJS 1.5.5 includes public STUN and PeerJS TURN endpoints in its defaults; their availability is outside this application's control. A production deployment should supply its own PeerServer and TURN credentials via the Peer options in `PartyClient.createPeer`, and move progression/ownership verification to a trusted account backend if anti-cheat is needed. No private credentials are bundled in the app.

## Manual Acceptance Checks

The production build is verified with the provided build tool. Physical multi-device connectivity is not verified in this environment. Run these checks with two or three browsers/devices on the deployed HTTPS URL:

1. Choose Duo, create a party, and join from device B with its code. Both screens should show both players, their selected characters and readiness.
2. Wait over three minutes. Existing members should remain; a new join using that code must fail. Refresh the code on the host, then verify the old token fails and the new token succeeds in a non-full lobby.
3. Use Trio and admit two guests. A fourth guest must be rejected. A guest can leave; their slot becomes free. If the host leaves, guests get an explicit closed-party message.
4. Mark every participant ready and start. Move independently on each device, and activate each visible ability. Only the requesting player's fighter should respond. Pause/resume from the host and verify every device pauses together.
5. Choose Boss Raid and Volcanic Ash: expect 2,850 HP in Duo and 4,350 HP in Trio. The boss must fight the entire team. The raid ends only when the boss dies or every connected hero is defeated.
6. Clear several Endless waves. Verify new enemies spawn after every intermission, all devices advance together and accumulated waves survive leaving/rejoining a later run.
7. Verify Final Health has exactly 1 HP and no second-life bypass; Training does not grant rewards; online Versus ends with the last surviving party member.
8. Use ULTRAKILL: initial cooldowns 3 / 3.5 / 3 seconds, awakened cooldowns 1.8 / 4 / 6 seconds. Charge, shield and transformation belong to that fighter, not the whole party.
9. Background the host during a cinematic and return: the pause controls must be visible and resume must work. Test guest network loss and host closing the tab; no disconnected fighter should keep moving indefinitely.
10. Test portrait and landscape phones: the invitation modal scrolls, all four available abilities fit the portrait palette, and the joystick resets on release, cancellation, blur and pause.